

var leveTime,leveTime1,leveTime2,leveTime3,leveTime4,speed=500;

$(function(){
	
	$(".nav_li").hover(function(){

		var dis_id = $(this).attr("alt");

		$(".nav_li").each(function(){
			var h_img = $(this).find("img").attr("h");
			var o_img = $(this).find("img").attr("o");
			var cur_img = $(this).find("img").attr("src");
			if(cur_img != o_img) $(this).find("img").attr("src",o_img);
		});

	//	if(dis_id != "viewHideSecondSWF"){
			var h_img = $(this).find("img").attr("h");
			var o_img = $(this).find("img").attr("o");
			var cur_img = $(this).find("img").attr("src");
			if(cur_img != h_img) $(this).find("img").attr("src",h_img);		
		//}


		
		$("#"+dis_id).show();
		$("#"+dis_id).hover(function(){
			$("#"+dis_id).show();
		},function(){
			$("#"+dis_id).hide();
		});
	},function(){
		//alert(3);
		var dis_id = $(this).attr("alt");
		$("#"+dis_id).hide();
	});
	
//	$("div#nav ul li a[href=about.html]").hover(
//	  function () {
//			$("#nav_sub1").show().slideDown("slow");
//	  },
//	  function () {
//			clearTimeout(leveTime1);
//			leveTime1 = setTimeout('hideSWF()',speed);
//	  }
//	);
//	
//	$("div#nav ul li a[href=newslist_1256111095687_0.html]").hover(
//	  function () {
//			$("#nav_sub2").show().slideDown("slow");
//	  },
//	  function () {
//			clearTimeout(leveTime2);
//			leveTime2 =setTimeout('hideSWF()',speed);
//	  }
//	);
//	
//	
//	$("div#nav ul li a[href=models.asp]").hover(
//	  function () {
//			$("#viewHideSecondSWF").show().slideDown("slow");
//	  },
//	  function () {
//			clearTimeout(leveTime);
//			leveTime=setTimeout('hideSWF()',speed);
//	  }
//	);
//	
//	$("div#nav ul li a[href=buy_1256108601890_0.html]").hover(
//	  function () {
//			$("#nav_sub3").show().slideDown("slow");
//	  },
//	  function () {
//			clearTimeout(leveTime3);
//			leveTime3=setTimeout('hideSWF()',speed);
//	  }
//	);
//	
//	$("div#nav ul li a[href=concept.html]").hover(
//	  function () {
//			$("#nav_sub4").show().slideDown("slow");
//	  },
//	  function () {
//			clearTimeout(leveTime4);
//			leveTime4=setTimeout('hideSWF()',speed);
//	  }
//	);

});

function cancleTime2(n){
	clearTimeout(eval("leveTime" + n));
	var oSrc = $("#img" + n).attr("src");
	var currSrc = $("#img" + n).attr("o");
	var hoverSrc = $("#img" + n).attr("h");
	if(hoverSrc!=oSrc){
		$("#img" + n).attr("src",hoverSrc);
	}
}

function resetart2(n){
	clearTimeout(eval("leveTime" + n));
	eval("leveTime" + n + " = setTimeout('hideSWF()',speed)");
	var oSrc = $("#img" + n).attr("src");
	var currSrc = $("#img" + n).attr("o");
	var hoverSrc = $("#img" + n).attr("h");
	$("#img" + n).attr("src",currSrc);
}

function cancleTime(){
	clearTimeout(leveTime);
}
function resetart(){
	clearTimeout(leveTime);
	leveTime=setTimeout('hideSWF()',speed);
}

function changeViewPicBoxs(tid,title){

	$("#viewPicBox_buy").attr("src","");
	var _Date = Date();
	$("#viewPicBox_buy").attr("src","images/reservation/0000"+tid+"b.jpg?d=" + _Date);
  $("#brand").attr("innerHTML",title);
  $("#Car").attr("value",title);
}

function hideSWF(){
	$("#viewHideSecondSWF").hide();
	$(".subNavBox").hide();
}

function randNums(maxN){
	return Math.floor(Math.random() * maxN);
}