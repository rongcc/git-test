package org.zkoss.zkdemo.test2;

import org.zkoss.zk.ui.util.GenericForwardComposer;

public class B2446682 extends GenericForwardComposer {
	public void onClick$$testButton() {
	}
}
