/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dadao.erp.ta;

import dadao.erp.dto.DBConnect;
import dadao.erp.dto.Ta;
import dadao.erp.dto.TaItem;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;
import org.apache.commons.dbcp.BasicDataSource;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;

/**
 *
 * @author zhourongchao
 */
public class Ta2InvStoreService {

    Dao dao;
    BasicDataSource ds = null;

    public Ta2InvStoreService() {

        try {
            DBConnect db = new dadao.erp.dto.DBConnect();
            ds = db.getDataSource();
            dao = new NutDao(ds);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void storeCreate(Ta order) {
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            //更新出入库列表
            String sqlStr = "insert into inventory(part_no,description,order_no,location,qty, "
                    + " units, status,input_date,input_name,remark) "
                    + "values(?,?,?,?,?, ?,?,?,?,?)";
            pStmt = conn.prepareStatement(sqlStr);
            for (int i = 0; i < order.getItemList().size(); i++) {
                TaItem oItem = (TaItem) order.getItemList().get(i);
                //
                pStmt.setString(1, oItem.getPartNo());
                pStmt.setString(2, "");
                pStmt.setString(3, oItem.getTaNo());
                pStmt.setString(4, "");
                pStmt.setDouble(5, oItem.getQty());

                pStmt.setString(6, oItem.getUnits());
                pStmt.setInt(7, 1);
                pStmt.setDate(8, new java.sql.Date(order.getInputDate().getTime()));
                pStmt.setString(9, order.getInputName());
                pStmt.setString(10, order.getRemark());
                int iSum = pStmt.executeUpdate();
                System.out.print("--" + iSum);
            }
            //更新库存数
            this.updateStoreQty(order.getTaNo());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void storeDestroy(String orderNo) {
        //更新出入库列表
        if (orderNo == null) {
            return;
        }
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            //
            String sqlStr = "update inventory set status='0' where order_no=?";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, orderNo);
            pStmt.executeUpdate();
            //更新库存数
            this.updateStoreQty(orderNo);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
    }

    public void storeEdit(Ta order) {
        //inv.editOrderInv(order);
        //store.updateStoreQty(order.getOrderNo());
        this.storeDestroy(order.getTaNo());
        this.storeCreate(order);
    }

    /**
     * update the real_qty
     */
    public void updateStoreQty(String orderNo) {
        if (orderNo == null) {
            return;
        }
        //
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            String sqlStr = "select distinct part_no from inventory where order_no=? ";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, orderNo);
            rs = pStmt.executeQuery();
            sqlStr = "update store set real_qty=stock_qty+?"
                    + " where status!=0 and part_no=?";
            while (rs.next()) {
                //
                String sqlStr2 = "select sum(qty) from inventory where status<>0 and part_no= ?";
                PreparedStatement pStmt2 = conn.prepareStatement(sqlStr2);
                pStmt2.setString(1, rs.getString("part_no"));
                ResultSet rs2 = pStmt2.executeQuery();
                //
                double sumInvQty = 0;
                while (rs2.next()) {
                    if (rs2.getString(1) != null) {
                        sumInvQty = rs2.getDouble(1);
                    }
                }
                pStmt = conn.prepareStatement(sqlStr);
                pStmt.setDouble(1, sumInvQty);
                pStmt.setString(2, rs.getString("part_no"));
                pStmt.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
    }
}
