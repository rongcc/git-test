/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dadao.erp.ta;

import dadao.erp.dto.Ta;
import dadao.erp.dto.TaItem;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.List;
import javax.sql.DataSource;
import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.nutz.dao.Sqls;
import org.nutz.dao.impl.NutDao;
import org.nutz.dao.sql.Sql;

/**
 *
 * @author zhourongchao
 */
public class TaService {

    public TaItem fetchTaItem(DataSource ds, String codeType, String code) {
        TaItem cd = null;
        try {
            Dao dao = new NutDao(ds);
            cd = dao.fetchx(TaItem.class, codeType, code);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cd;
    }

    public List findItemList(DataSource ds, String orderNo) {
        List al = null;
        try {
            Dao dao = new NutDao(ds);
            al = dao.query(TaItem.class, Cnd.where("ta_no", "=", orderNo).asc("item_no"), null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return al;
    }

    public int deleteTaItem(DataSource ds, TaItem cd) {
        int di = 0;
        try {
            Dao dao = new NutDao(ds);
            dao.deletex(TaItem.class, cd.getTaNo(), cd.getItemNo());
            di = 1;
        } catch (Exception e) {
            di = -3;
            e.printStackTrace();
        }
        return di;
    }

    public String create(DataSource ds, Ta order) {
        //
        if (order == null) {
            return null;
        }
        if (order.getTaNo() == null || order.getTaNo().equals("") || order.getItemList().size() < 1) {
            return "-1";
        }
        //
        String orderNo = "";
        try {
            Dao dao = new NutDao(ds);
            Ta po = dao.insert(order);
            orderNo = po.getTaNo();
            List itemList = po.getItemList();
            for (int i = 0; i < itemList.size(); i++) {
                TaItem item = (TaItem) itemList.get(i);
                dao.insert(item);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return orderNo;
    }

    public Ta findOrder(DataSource ds, String orderNo) {
        Ta order = null;
        try {
            Dao dao = new NutDao(ds);
            order = dao.fetch(Ta.class, orderNo);
            order.setItemList(this.findItemList(ds, order.getTaNo()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return order;
    }

    public String edit(DataSource ds, Ta order) {
        //
        if (order == null) {
            return null;
        }
        if (order.getTaNo() == null || order.getTaNo().equals("") || order.getItemList().size() < 1) {
            return "-1";
        }
        //
        String orderNo = "";
        try {
            Dao dao = new NutDao(ds);
            //更新主体
            int upi = dao.update(order);
            //清除条目
            Sql sql = Sqls.create("delete from ta_item where ta_no=@ta_no");
            sql.params().set("ta_no", order.getTaNo());
            dao.execute(sql);
            //重新插入条目
            List itemList = order.getItemList();
            for (int i = 0; i < itemList.size(); i++) {
                TaItem pItem = (TaItem) itemList.get(i);
                dao.insert(pItem);
            }
            //更新主体成功即返回编码
            if (upi == 1) {
                orderNo = order.getTaNo();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return orderNo;
    }

    public int destroy(DataSource ds, Ta order) {
        //
        if (order == null) {
            return -2;
        }
        if (order.getTaNo() == null || order.getTaNo().equals("")) {
            return -1;
        }
        //
        int dt = 0;
        try {
            Dao dao = new NutDao(ds);
            Sql sql = Sqls.create("update ta set status = '-1' where ta_no=@ta_no");
            sql.params().set("ta_no", order.getTaNo());
            dao.execute(sql);
            dt = 1;
        } catch (Exception e) {
            dt = -3;
            e.printStackTrace();
        }
        return dt;
    }

    /**
     * 删除,包括各明细条目
     * @param ds
     * @param orderNo
     * @return
     */
    public int delete(DataSource ds, String orderNo) {
        //
        if (orderNo == null || orderNo.equals("")) {
            return -1;
        }
        //
        int dt = 0;
        try {
            Dao dao = new NutDao(ds);
            dao.delete(Ta.class, orderNo);
            Sql sql = Sqls.create("delete from ta where ta_no=@ta_no");
            sql.params().set("ta_no", orderNo);
            dao.execute(sql);
            sql = Sqls.create("delete from ta_item where ta_no=@ta_no");
            sql.params().set("ta_no", orderNo);
            dao.execute(sql);
            dt = 1;
        } catch (Exception e) {
            dt = -3;
            e.printStackTrace();
        }
        return dt;
    }

    /**
     * get the next order no.
     */
    public String getNextNo(DataSource ds) {
        String nextNo = "";
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            StringBuffer sb = new StringBuffer();
            Calendar rightNow = Calendar.getInstance();
            int y = rightNow.get(Calendar.YEAR);
            conn = ds.getConnection();
            //先取原表
            String sqlStr = "select max(ta_no) from ta";
            pStmt = conn.prepareStatement(sqlStr);
            rs = pStmt.executeQuery();
            String no = null;
            if (rs.next()) {
                no = rs.getString(1);
            }
            //根据查询结果运算
            if (no != null && no.length() == 10) {
                int lastYear = 2000 + Integer.parseInt(no.substring(2, 4));
                if (y > lastYear) {
                    nextNo = sb.append("TA").append(String.valueOf(y).substring(2)).append("000001").toString();
                } else {
                    int ino = Integer.parseInt(no.substring(4));
                    nextNo = sb.append("TA").append(String.valueOf(y).substring(2)).append(String.valueOf(1000001 + ino).substring(1)).toString();
                }
            } else {
                nextNo = sb.append("TA").append(String.valueOf(y).substring(2)).append("000001").toString();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return nextNo;
    }
}
