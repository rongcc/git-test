/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dadao.erp.dto;

import java.util.Date;
import java.util.List;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Name;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("ta")
public class Ta {

    @Column("ta_no")
    @Name
    private String taNo;
    @Column("do_man")
    private String doMan;
    @Column("do_date")
    private Date doDate;
    @Column("status")
    private int status;
    @Column("remark")
    private String remark;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;
    @Column("edit_date")
    private Date editDate;
    @Column("edit_name")
    private String editName;
    @Column("post_date")
    private Date postDate;
    @Column("post_name")
    private String postName;
    @Column("io")
    private int io;
    @Column("type")
    private String type;
    private List itemList;

    /**
     * @return the taNo
     */
    public String getTaNo() {
        return taNo;
    }

    /**
     * @param taNo the taNo to set
     */
    public void setTaNo(String taNo) {
        this.taNo = taNo;
    }

    /**
     * @return the doMan
     */
    public String getDoMan() {
        return doMan;
    }

    /**
     * @param doMan the doMan to set
     */
    public void setDoMan(String doMan) {
        this.doMan = doMan;
    }

    /**
     * @return the doDate
     */
    public Date getDoDate() {
        return doDate;
    }

    /**
     * @param doDate the doDate to set
     */
    public void setDoDate(Date doDate) {
        this.doDate = doDate;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * @param remark the remark to set
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    /**
     * @return the editDate
     */
    public Date getEditDate() {
        return editDate;
    }

    /**
     * @param editDate the editDate to set
     */
    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }

    /**
     * @return the editName
     */
    public String getEditName() {
        return editName;
    }

    /**
     * @param editName the editName to set
     */
    public void setEditName(String editName) {
        this.editName = editName;
    }

    /**
     * @return the postDate
     */
    public Date getPostDate() {
        return postDate;
    }

    /**
     * @param postDate the postDate to set
     */
    public void setPostDate(Date postDate) {
        this.postDate = postDate;
    }

    /**
     * @return the postName
     */
    public String getPostName() {
        return postName;
    }

    /**
     * @param postName the postName to set
     */
    public void setPostName(String postName) {
        this.postName = postName;
    }

 

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return the itemList
     */
    public List getItemList() {
        return itemList;
    }

    /**
     * @param itemList the itemList to set
     */
    public void setItemList(List itemList) {
        this.itemList = itemList;
    }

    /**
     * @return the io
     */
    public int getIo() {
        return io;
    }

    /**
     * @param io the io to set
     */
    public void setIo(int io) {
        this.io = io;
    }
}
