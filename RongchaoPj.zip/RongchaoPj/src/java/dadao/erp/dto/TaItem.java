/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dadao.erp.dto;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.PK;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("ta_item")
@PK({"taNo", "itemNo"})
public class TaItem {

    @Column("ta_no")
    private String taNo;
    @Column("item_no")
    private int itemNo;
    @Column("part_no")
    private String partNo;
    @Column("qty")
    private double qty;
    @Column("units")
    private String units;
    @Column("use")
    private String use;
    @Column("form_no")
    private String formNo;

    /**
     * @return the taNo
     */
    public String getTaNo() {
        return taNo;
    }

    /**
     * @param taNo the taNo to set
     */
    public void setTaNo(String taNo) {
        this.taNo = taNo;
    }

    /**
     * @return the itemNo
     */
    public int getItemNo() {
        return itemNo;
    }

    /**
     * @param itemNo the itemNo to set
     */
    public void setItemNo(int itemNo) {
        this.itemNo = itemNo;
    }

    /**
     * @return the partNo
     */
    public String getPartNo() {
        return partNo;
    }

    /**
     * @param partNo the partNo to set
     */
    public void setPartNo(String partNo) {
        this.partNo = partNo;
    }

    /**
     * @return the qty
     */
    public double getQty() {
        return qty;
    }

    /**
     * @param qty the qty to set
     */
    public void setQty(double qty) {
        this.qty = qty;
    }

    /**
     * @return the units
     */
    public String getUnits() {
        return units;
    }

    /**
     * @param units the units to set
     */
    public void setUnits(String units) {
        this.units = units;
    }

    /**
     * @return the use
     */
    public String getUse() {
        return use;
    }

    /**
     * @param use the use to set
     */
    public void setUse(String use) {
        this.use = use;
    }

    /**
     * @return the formNo
     */
    public String getFormNo() {
        return formNo;
    }

    /**
     * @param formNo the formNo to set
     */
    public void setFormNo(String formNo) {
        this.formNo = formNo;
    }
}
