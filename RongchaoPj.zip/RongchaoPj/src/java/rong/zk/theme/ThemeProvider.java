/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.zk.theme;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import org.zkoss.zk.ui.Execution;
import org.zkoss.zk.ui.Executions;

/**
 *
 * @author zhourongchao
 */
public class ThemeProvider implements org.zkoss.zk.ui.util.ThemeProvider {

    private String themeName;

    public ThemeProvider() {
        this.themeName = "breeze";
    }

    @SuppressWarnings("unchecked")
    /**
     * 动态加载主题方法，返回加载的dsp文件
     */
    public Collection getThemeURIs(Execution exec, List uris) {
        String themeStyle = getThemeName();
        try {
            //test.properties文件保存我们的主题信息path和name的对应键值对。
            //path和theme表中的path对应，name和newzk3.jar中的主题名字对应。
            InputStream is = getClass().getResourceAsStream("theme.properties");
            if (is == null) {
                throw new RuntimeException("Cannot find theme.properties");
            }
            Properties prop = new Properties();
            prop.load(is);
            //
            System.out.println(prop+"--p");
            Enumeration enums = prop.propertyNames();
            while (enums.hasMoreElements()) {
                //得到path
                String key = (String) enums.nextElement();
                //得到name
                String value = prop.getProperty(key);
                if (key.equals(themeStyle)) {
                    themeStyle = value;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        //路径的获得
        List newUris = new ArrayList();
        for (Iterator it = uris.iterator(); it.hasNext();) {
            String uri = (String) it.next();
            if (uri.startsWith("~./")) {
                uri = "~./" + themeStyle + "/" + uri.substring(3);
            }
            System.out.println(uri+"--0");
            newUris.add(uri);
        }
        return newUris;
    }

    /**
     * getThemeName()方法，得到themeName
     */
    public String getThemeName() {
        HttpServletRequest req = (HttpServletRequest) Executions.getCurrent().getNativeRequest();
        Cookie[] cookies = req.getCookies();
        if (cookies != null && cookies.length != 0) {
            for (int i = 0; i < cookies.length; i++) {
                //ThemeStyle为前台我们选择主题时传入的cookie名
                if (cookies[i].getName().equals("ThemeStyle")) {
                    themeName = cookies[i].getValue();
                }
            }
        }
        return themeName;
    }

    public int getWCSCacheControl(Execution exec, String uri) {
        return 8760; //safe to cache
    }

    public String beforeWCS(Execution exec, String uri) {
        final String[] dec = Aide.decodeURI(uri);
        if (dec != null) {
            if ("lg".equals(dec[1])) {
                exec.setAttribute("fontSizeM", "15px");
                exec.setAttribute("fontSizeMS", "13px");
                exec.setAttribute("fontSizeS", "13px");
                exec.setAttribute("fontSizeXS", "12px");
            } else if ("sm".equals(dec[1])) {
                exec.setAttribute("fontSizeM", "10px");
                exec.setAttribute("fontSizeMS", "9px");
                exec.setAttribute("fontSizeS", "9px");
                exec.setAttribute("fontSizeXS", "8px");
            }
            return dec[0];
        }
        return uri;
    }

    public String beforeWidgetCSS(Execution exec, String uri) {
        return uri;
    }
}
