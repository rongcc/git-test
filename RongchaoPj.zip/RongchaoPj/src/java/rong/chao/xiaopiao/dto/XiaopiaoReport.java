/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.xiaopiao.dto;

import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author zhourongchao
 */
public class XiaopiaoReport {

    public XiaopiaoReport() {
    }
    private String line1;
    private String line2;
    private String line3;
    private String line4;
    private String line5;
    private String line6;
    private String line7;
    private String line8;
    private String line9;
    private String line10;
    //
    private Integer id;
    private int soNo;
    private String partItem;
    private String partName;
    private BigDecimal qty;
    private BigDecimal price;
    private BigDecimal jine;
    private BigDecimal hejiJine;
    private BigDecimal shishouJine;
    private BigDecimal zhaolingJine;
    private Date inputDate;
    private Date inputName;
    private int status;

    /**
     * @return the line1
     */
    public String getLine1() {
        return line1;
    }

    /**
     * @param line1 the line1 to set
     */
    public void setLine1(String line1) {
        this.line1 = line1;
    }

    /**
     * @return the line2
     */
    public String getLine2() {
        return line2;
    }

    /**
     * @param line2 the line2 to set
     */
    public void setLine2(String line2) {
        this.line2 = line2;
    }

    /**
     * @return the line3
     */
    public String getLine3() {
        return line3;
    }

    /**
     * @param line3 the line3 to set
     */
    public void setLine3(String line3) {
        this.line3 = line3;
    }

    /**
     * @return the line4
     */
    public String getLine4() {
        return line4;
    }

    /**
     * @param line4 the line4 to set
     */
    public void setLine4(String line4) {
        this.line4 = line4;
    }

    /**
     * @return the line5
     */
    public String getLine5() {
        return line5;
    }

    /**
     * @param line5 the line5 to set
     */
    public void setLine5(String line5) {
        this.line5 = line5;
    }

    /**
     * @return the line6
     */
    public String getLine6() {
        return line6;
    }

    /**
     * @param line6 the line6 to set
     */
    public void setLine6(String line6) {
        this.line6 = line6;
    }

    /**
     * @return the line7
     */
    public String getLine7() {
        return line7;
    }

    /**
     * @param line7 the line7 to set
     */
    public void setLine7(String line7) {
        this.line7 = line7;
    }

    /**
     * @return the line8
     */
    public String getLine8() {
        return line8;
    }

    /**
     * @param line8 the line8 to set
     */
    public void setLine8(String line8) {
        this.line8 = line8;
    }

    /**
     * @return the line9
     */
    public String getLine9() {
        return line9;
    }

    /**
     * @param line9 the line9 to set
     */
    public void setLine9(String line9) {
        this.line9 = line9;
    }

    /**
     * @return the line10
     */
    public String getLine10() {
        return line10;
    }

    /**
     * @param line10 the line10 to set
     */
    public void setLine10(String line10) {
        this.line10 = line10;
    }

    /**
     * @return the id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return the soNo
     */
    public int getSoNo() {
        return soNo;
    }

    /**
     * @param soNo the soNo to set
     */
    public void setSoNo(int soNo) {
        this.soNo = soNo;
    }

    /**
     * @return the partItem
     */
    public String getPartItem() {
        return partItem;
    }

    /**
     * @param partItem the partItem to set
     */
    public void setPartItem(String partItem) {
        this.partItem = partItem;
    }

    /**
     * @return the partName
     */
    public String getPartName() {
        return partName;
    }

    /**
     * @param partName the partName to set
     */
    public void setPartName(String partName) {
        this.partName = partName;
    }

    /**
     * @return the qty
     */
    public BigDecimal getQty() {
        return qty;
    }

    /**
     * @param qty the qty to set
     */
    public void setQty(BigDecimal qty) {
        this.qty = qty;
    }

    /**
     * @return the price
     */
    public BigDecimal getPrice() {
        return price;
    }

    /**
     * @param price the price to set
     */
    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    /**
     * @return the jine
     */
    public BigDecimal getJine() {
        return jine;
    }

    /**
     * @param jine the jine to set
     */
    public void setJine(BigDecimal jine) {
        this.jine = jine;
    }

    /**
     * @return the hejiJine
     */
    public BigDecimal getHejiJine() {
        return hejiJine;
    }

    /**
     * @param hejiJine the hejiJine to set
     */
    public void setHejiJine(BigDecimal hejiJine) {
        this.hejiJine = hejiJine;
    }

    /**
     * @return the shishouJine
     */
    public BigDecimal getShishouJine() {
        return shishouJine;
    }

    /**
     * @param shishouJine the shishouJine to set
     */
    public void setShishouJine(BigDecimal shishouJine) {
        this.shishouJine = shishouJine;
    }

    /**
     * @return the zhaolingJine
     */
    public BigDecimal getZhaolingJine() {
        return zhaolingJine;
    }

    /**
     * @param zhaolingJine the zhaolingJine to set
     */
    public void setZhaolingJine(BigDecimal zhaolingJine) {
        this.zhaolingJine = zhaolingJine;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public Date getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(Date inputName) {
        this.inputName = inputName;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }
}
