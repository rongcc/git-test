/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package rong.chao.xiaopiao.dto;

import java.math.BigDecimal;
import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */

@Table("xd_xiaopiao")
public class XdXiaopiao {

    @Column("id")
    @Id
    private Integer id;
    @Column("so_no")
    private int soNo;
    @Column("part_item")
    private String partItem;
    @Column("part_name")
    private String partName;
    @Column("qty")
    private BigDecimal qty;
    @Column("price")
    private BigDecimal price;
    @Column("jine")
    private BigDecimal jine;
    @Column("heji_jine")
    private BigDecimal hejiJine;
    @Column("shishou_jine")
    private BigDecimal shishouJine;
    @Column("zhaoling_jine")
    private BigDecimal zhaolingJine;
    @Column("input_date")
    private Date inputDate;

    /**
     * @return the id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return the soNo
     */
    public int getSoNo() {
        return soNo;
    }

    /**
     * @param soNo the soNo to set
     */
    public void setSoNo(int soNo) {
        this.soNo = soNo;
    }

    /**
     * @return the partItem
     */
    public String getPartItem() {
        return partItem;
    }

    /**
     * @param partItem the partItem to set
     */
    public void setPartItem(String partItem) {
        this.partItem = partItem;
    }

    /**
     * @return the partName
     */
    public String getPartName() {
        return partName;
    }

    /**
     * @param partName the partName to set
     */
    public void setPartName(String partName) {
        this.partName = partName;
    }

    /**
     * @return the qty
     */
    public BigDecimal getQty() {
        return qty;
    }

    /**
     * @param qty the qty to set
     */
    public void setQty(BigDecimal qty) {
        this.qty = qty;
    }

    /**
     * @return the price
     */
    public BigDecimal getPrice() {
        return price;
    }

    /**
     * @param price the price to set
     */
    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    /**
     * @return the jine
     */
    public BigDecimal getJine() {
        return jine;
    }

    /**
     * @param jine the jine to set
     */
    public void setJine(BigDecimal jine) {
        this.jine = jine;
    }

    /**
     * @return the hejiJine
     */
    public BigDecimal getHejiJine() {
        return hejiJine;
    }

    /**
     * @param hejiJine the hejiJine to set
     */
    public void setHejiJine(BigDecimal hejiJine) {
        this.hejiJine = hejiJine;
    }

    /**
     * @return the shishouJine
     */
    public BigDecimal getShishouJine() {
        return shishouJine;
    }

    /**
     * @param shishouJine the shishouJine to set
     */
    public void setShishouJine(BigDecimal shishouJine) {
        this.shishouJine = shishouJine;
    }

    /**
     * @return the zhaolingJine
     */
    public BigDecimal getZhaolingJine() {
        return zhaolingJine;
    }

    /**
     * @param zhaolingJine the zhaolingJine to set
     */
    public void setZhaolingJine(BigDecimal zhaolingJine) {
        this.zhaolingJine = zhaolingJine;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }
}
