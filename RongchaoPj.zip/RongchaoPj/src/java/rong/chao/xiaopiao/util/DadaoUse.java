/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.xiaopiao.util;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 *
 * @author zhourongchao
 */
public class DadaoUse {

    private static DadaoUse me;

    static {
        try {
            me = new DadaoUse();
        } catch (Exception se) {
            throw new RuntimeException(se);
        }
    }

    /** Creates a new instance of DadaoUse */
    private DadaoUse() {
    }

    public static DadaoUse getInstance() {
        return me;
    }

    /**
     * 获得现在的日期时间
     * @return
     */
    public Date getNow() {
        Date now = null;
        Calendar rightNow = Calendar.getInstance();
        now = rightNow.getTime();
        // now=new Date();
        return now;
    }

    /**
     * Get today and time as a String E.g. "2006/8/26 17:24:23"
     */
    public String getDateTime() {
        Calendar rightNow = Calendar.getInstance();
        int y = rightNow.get(Calendar.YEAR);
        int m = rightNow.get(Calendar.MONTH);
        int d = rightNow.get(Calendar.DAY_OF_MONTH);
        int h = rightNow.get(Calendar.HOUR_OF_DAY);
        int minute = rightNow.get(Calendar.MINUTE);
        int s = rightNow.get(Calendar.SECOND);
        StringBuffer sb = new StringBuffer();
        return sb.append(y).append("/").append(m + 1).append("/").append(d).append(" ").append(h).append(":").append(minute).append(":").append(s).toString();
    }

    /**
     * Get today as a String E.g. "2006/8/26"
     */
    public String getToday() {
        //TODO implement getToday
        Calendar rightNow = Calendar.getInstance();
        int y = rightNow.get(Calendar.YEAR);
        int m = rightNow.get(Calendar.MONTH);
        int d = rightNow.get(Calendar.DAY_OF_MONTH);
        StringBuffer sb = new StringBuffer();
        return sb.append(y).append("/").append(m + 1).append("/").append(d).toString();
    }

    /**
     * Get today as a String E.g. "2006-8-26"
     */
    public String getFormatToday() {
        Date now = new Date();
        DateFormat df = DateFormat.getDateInstance();
        return df.format(now);
    }

    public String formatRiQiDate(Date dt) {
        DateFormat df = DateFormat.getDateInstance(DateFormat.DEFAULT);
        return df.format(dt);
    }

    public String formatRiQiShiJianDate(Date dt) {
        java.text.DateFormat format1 = new java.text.SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        return format1.format(dt);
    }
}
