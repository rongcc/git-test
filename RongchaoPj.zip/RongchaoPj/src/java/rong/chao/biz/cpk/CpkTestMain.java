/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.biz.cpk;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author zhourongchao
 */
public class CpkTestMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        List al = new ArrayList();
        double To = 10;
        double SU = 11;
        double SL = 9;
        double subgroup[] = {10.50, 9.70, 9.90, 10.00, 10.30, 10.20 ,9.80 ,10.30 ,10.00 ,10.00 ,10.10 ,9.70 ,10.00 ,9.70 ,10.20};
        
        System.out.println("第1组:");
        Cpk cpk = new Cpk(subgroup, To, SU, SL);
        al.add(cpk);
        System.out.println("规格中心:"+cpk.To);
        System.out.println("规格上限："+cpk.SU);
        System.out.println("规格下限："+cpk.SL);
        System.out.println("抽样个数："+cpk.n);
        System.out.println("最大数:"+cpk.max);
        System.out.println("最小数："+cpk.min);
        System.out.println("极差："+cpk.R);
        System.out.println("公差："+cpk.T);
        System.out.println("均值："+cpk.Xbar);
        System.out.println("标准偏差："+cpk.sigma);
        System.out.println("准确度指标："+cpk.Ca);
        System.out.println("精密度指标："+cpk.Cp);
        System.out.println("综合评价指数："+cpk.Cpk);
        
        double subgroup2[] = {10.50, 9.70, 9.90, 10.00, 10.30, 10.20 ,9.80 ,10.30 ,10.10 ,10.40 ,10.10 ,9.70 ,10.00 ,9.70 ,10.20};
        
        System.out.println("第2组:");
        cpk = new Cpk(subgroup2, To, SU, SL);
        //al.add(cpk);
        System.out.println("规格中心:"+cpk.To);
        System.out.println("规格上限："+cpk.SU);
        System.out.println("规格下限："+cpk.SL);
        System.out.println("抽样个数："+cpk.n);
        System.out.println("最大数:"+cpk.max);
        System.out.println("最小数："+cpk.min);
        System.out.println("极差："+cpk.R);
        System.out.println("公差："+cpk.T);
        System.out.println("均值："+cpk.Xbar);
        System.out.println("标准偏差："+cpk.sigma);
        System.out.println("准确度指标："+cpk.Ca);
        System.out.println("精密度指标："+cpk.Cp);
        System.out.println("综合评价指数："+cpk.Cpk);
        
        double subgroup3[] = {10.50, 9.60, 9.80, 10.00, 10.30, 10.20 ,9.80 ,10.30 ,10.10 ,10.40 ,10.10 ,9.70 ,10.00 ,9.70 ,10.20};
        
        System.out.println("第3组:");
        cpk = new Cpk(subgroup3, To, SU, SL);
        //al.add(cpk);
        System.out.println("规格中心:"+cpk.To);
        System.out.println("规格上限："+cpk.SU);
        System.out.println("规格下限："+cpk.SL);
        System.out.println("抽样个数："+cpk.n);
        System.out.println("最大数:"+cpk.max);
        System.out.println("最小数："+cpk.min);
        System.out.println("极差："+cpk.R);
        System.out.println("公差："+cpk.T);
        System.out.println("均值："+cpk.Xbar);
        System.out.println("标准偏差："+cpk.sigma);
        System.out.println("准确度指标："+cpk.Ca);
        System.out.println("精密度指标："+cpk.Cp);
        System.out.println("综合评价指数："+cpk.Cpk);
        
        
        Ppk ppk = new Ppk(al);
        System.out.println("长期:");
        System.out.println("综合评价指数："+ppk.Ppk);
    }
}
