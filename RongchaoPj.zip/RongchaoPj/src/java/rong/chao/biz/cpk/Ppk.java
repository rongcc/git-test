/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.biz.cpk;

import java.util.List;

/**
 *
 * @author ZhouRongChao
 */
public class Ppk {

    /**
     * 组间标准差s
     */
    public double s;
    /**
     * 包含各抽样数组的Cpk对象列表
     */
    public List group;
    /**
     * 组间最大数
     */
    public double max;
    /**
     * 组间最小数
     */
    public double min;
    /**
     * 各组极差的均值
     */
    public double Rbar;
    /**
     * 各组均值的均值
     */
    public double Xbarbar;
    /**
     * 各组总共抽样个数
     */
    public int n;
    /**
     * 规格中心
     */
    public double To;
    /**
     * 规格上限
     */
    public double SU;
    /**
     * 规格下限
     */
    public double SL;
    /**
     * 公差
     */
    public double T;
    /**
     * 长期准确度指标
     */
    public double Ca;
    /**
     * 长期精密度指标，制程能力。
     */
    public double Pp;
    /**
     * 长期综合评价指数
     */
    public double Ppk;

    /**
     * 构造PPK
     *
     * @param group 包含各抽样数组的Cpk对象列表。
     */
    public Ppk(List group) {
        this.group = group;
        Cpk subCpk = (Cpk) group.get(0);
        this.To = subCpk.To;
        this.SU = subCpk.SU;
        this.SL = subCpk.SL;
        this.T = SU - SL;
        this.max = max(group);
        this.min = min(group);
        this.n = getN(group);
        this.Rbar = getRbar(group);
        this.Xbarbar = getXbarbar(group);
        this.Ca = Math.abs(Xbarbar - To) / (T / 2);
        this.s = stdev(group);
        this.Pp = T / (6 * s);
        this.Ppk = Pp * (1 - Ca);
    }

    /**
     * 计算Rbar的值。
     *
     * @param group
     * @return
     */
    private double getRbar(List group) {
        double aval = 0;
        for (int i = 0; i < group.size(); i++) {
            Cpk subCpk = (Cpk) group.get(i);
            aval += subCpk.R;
        }
        return aval / group.size();
    }

    /**
     * 计算Xbarbar的值。
     *
     * @param group
     * @return
     */
    private double getXbarbar(List group) {
        double aval = 0;
        for (int i = 0; i < group.size(); i++) {
            Cpk subCpk = (Cpk) group.get(i);
            aval += subCpk.Xbar;
        }
        return aval / group.size();
    }

    private int getN(List group) {
        int sn = 0;
        for (int g = 0; g < group.size(); g++) {
            Cpk cpk = (Cpk) group.get(g);
            double[] subgroup = cpk.subgroup;
            for (int i = 0; i < subgroup.length; i++) {
                sn++;
            }
        }
        return sn;
    }

    /**
     * 组间最大值。
     *
     * @param group
     * @return
     */
    private double max(List group) {
        double mval = 0;
        for (int g = 0; g < group.size(); g++) {
            Cpk cpk = (Cpk) group.get(g);
            double[] subgroup = cpk.subgroup;
            for (int i = 0; i < subgroup.length; i++) {
                mval = Math.max(mval, subgroup[i]);
            }
        }
        return mval;
    }

    /**
     * 组间最小值。
     *
     * @param subgroup
     * @return
     */
    private double min(List group) {
        Cpk cpk = (Cpk) group.get(0);
        double[] subgroup = cpk.subgroup;
        double mval = subgroup[0];
        for (int g = 0; g < group.size(); g++) {
            cpk = (Cpk) group.get(g);
            subgroup = cpk.subgroup;
            for (int i = 0; i < subgroup.length; i++) {
                mval = Math.min(mval, subgroup[i]);
            }
        }
        return mval;
    }

    /**
     * 估算样本（总体中的样本）的标准偏差。标准偏差反映相对于组间平均值的离散程度。
     *
     * @param group
     * @return
     */
    private double stdev(List group) {
        double rval = 0;
        int sn = 0;
        for (int g = 0; g < group.size(); g++) {
            Cpk cpk = (Cpk) group.get(g);
            double[] subgroup = cpk.subgroup;
            for (int i = 0; i < subgroup.length; i++) {
                rval += Math.pow((subgroup[i] - this.Xbarbar), 2);
                sn++;
            }
        }
        rval /= sn - 1;
        rval = Math.sqrt(rval);
        return rval;
    }
}