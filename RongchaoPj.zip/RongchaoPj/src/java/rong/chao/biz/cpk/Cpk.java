/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.biz.cpk;

/**
 *
 * @author zhourongchao
 */
public class Cpk {

    /**
     * 标准差σ
     */
    public double sigma;
    /**
     * 抽样数组
     */
    public double subgroup[];
    /**
     * 最大数
     */
    public double max;
    /**
     * 最小数
     */
    public double min;
    /**
     * 极差
     */
    public double R;
    /**
     * 均值
     */
    public double Xbar;
    /**
     * 抽样个数
     */
    public int n;
    /**
     * 规格中心
     */
    public double To;
    /**
     * 规格上限
     */
    public double SU;
    /**
     * 规格下限
     */
    public double SL;
    /**
     * 公差
     */
    public double T;
    /**
     * 准确度指标
     */
    public double Ca;
    /**
     * 精密度指标，制程能力。
     */
    public double Cp;
    /**
     * 综合评价指数
     */
    public double Cpk;

    /**
     * 构造CPK。
     *
     * @param subgroup 抽样数组；
     * @param To 规格中心；
     * @param SU 规格上限；
     * @param SL 规格下限；
     */
    public Cpk(double[] subgroup, double To, double SU, double SL) {
        this.subgroup = subgroup;
        this.To = To;
        this.SU = SU;
        this.SL = SL;
        this.n = subgroup.length;
        this.max = max(subgroup);
        this.min = min(subgroup);
        this.R = max - min;
        this.Xbar = average(subgroup);
        this.T = SU - SL;
        this.sigma = stdevp(subgroup);
        this.Ca = Math.abs(Xbar - To) / (T / 2);
        this.Cp = T / (6 * sigma);
        this.Cpk = Cp * (1 - Ca);
    }

    /**
     * 最大值。
     *
     * @param subgroup
     * @return
     */
    private double max(double[] subgroup) {
        double mval = 0;
        for (int i = 0; i < subgroup.length; i++) {
            mval = Math.max(mval, subgroup[i]);
        }
        return mval;
    }

    /**
     * 最小值。
     *
     * @param subgroup
     * @return
     */
    private double min(double[] subgroup) {
        double mval = subgroup[0];
        for (int i = 0; i < subgroup.length; i++) {
            mval = Math.min(mval, subgroup[i]);
        }
        return mval;
    }

    /**
     * 计算数组均值。
     *
     * @param subgroup
     * @return
     */
    private double average(double[] subgroup) {
        double aval = 0;
        for (int i = 0; i < subgroup.length; i++) {
            aval += subgroup[i];
        }
        return aval / subgroup.length;
    }

    /**
     * 估算样本(整个样本总体）的标准偏差。标准偏差反映相对于平均值的离散程度。
     *
     * @param subgroup
     * @return
     */
    private double stdevp(double[] subgroup) {
        double rval = 0;
        double avg = average(subgroup);
        for (int i = 0; i < subgroup.length; i++) {
            rval += Math.pow((subgroup[i] - avg), 2);
        }
        rval /= subgroup.length;
        rval = Math.sqrt(rval);
        return rval;
    }
}
