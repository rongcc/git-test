/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.biz.cpk;

/**
 *
 * @author ZhouRongChao
 */
public class Subgroup extends Cpk {

    public Subgroup(double[] subgroup, double To, double SU, double SL) {
        super(subgroup, To, SU, SL);
    }
}
