/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.biz;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Vector;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author ZhouRongChao
 */
public class Drawline extends JFrame {

    private Draw dr;
    private JButton b1;
    private Color cc;

    public Drawline() {
        b1 = new JButton("change");
        b1.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                cc = JColorChooser.showDialog(Drawline.this, "please a color",
                        cc);
                dr.setColor(cc);
            }
        });
        dr = new Draw();
        dr.setBackground(Color.white);
        Container c = getContentPane();
        c.setLayout(new FlowLayout());
        c.add(dr);
        c.add(b1);
        setSize(600, 500);
        show();
    }

    public static void main(String args[]) {
        Drawline dl = new Drawline();
        dl.addWindowListener(new WindowAdapter() {

            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
}

class Line {

    public int x0, y0, x1, y1;
    public Color color;// Save the color
}

class Draw extends JPanel {

    Vector lines = new Vector();
    Line cur;
    Color changeColor;

    public Draw() {
        setPreferredSize(new Dimension(500, 500));
        addMouseListener(new MouseAdapter() {

            public void mousePressed(MouseEvent e) {
                // if(cur == null)
                cur = new Line();
                cur.x0 = e.getX();
                cur.y0 = e.getY();
                cur.color = changeColor;
            }

            public void mouseReleased(MouseEvent e) {
                cur.x1 = e.getX();
                cur.y1 = e.getY();
                lines.add(cur);
                cur = null;
            }
        });
        addMouseMotionListener(new MouseMotionAdapter() {

            public void mouseDragged(MouseEvent e) {
                cur.x1 = e.getX();
                cur.y1 = e.getY();
                repaint();
            }
        });
    }

    public void setColor(Color c) {
        changeColor = c;
    }

    public void paint(Graphics g) {
        super.paint(g);
        Color oldColor = g.getColor();
        for (int i = 0; i < lines.size(); i++) {
            Line tmp = (Line) lines.elementAt(i);
            if (tmp.color != null) {
                g.setColor(tmp.color);
            }
            g.drawLine(tmp.x0, tmp.y0, tmp.x1, tmp.y1);
        }
        if (cur != null) {
            if (cur.color != null) {
                g.setColor(cur.color);
            }
            g.drawLine(cur.x0, cur.y0, cur.x1, cur.y1);
        }
        g.setColor(oldColor);
    }
}
