/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.biz.pj.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author ZhouRongChao
 */
@Table("pj_aoa_path")
public class AoaPath {

    @Column("id")
    @Id
    private Integer id;
    @Column("d")
    private String d;
    @Column("works")
    private String works;
    @Column("arrows")
    private String arrows;
    @Column("y")
    private Double y;
    @Column("critical_path")
    private Boolean criticalPath;
    @Column("center_path")
    private Boolean centerPath;
    @Column("step2c")
    private Integer step2c;
    @Column("time2c")
    private Date time2c;

    /**
     * @return the id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return the d
     */
    public String getD() {
        return d;
    }

    /**
     * @param d the d to set
     */
    public void setD(String d) {
        this.d = d;
    }

    /**
     * @return the works
     */
    public String getWorks() {
        return works;
    }

    /**
     * @param works the works to set
     */
    public void setWorks(String works) {
        this.works = works;
    }

    /**
     * @return the arrows
     */
    public String getArrows() {
        return arrows;
    }

    /**
     * @param arrows the arrows to set
     */
    public void setArrows(String arrows) {
        this.arrows = arrows;
    }

    /**
     * @return the y
     */
    public Double getY() {
        return y;
    }

    /**
     * @param y the y to set
     */
    public void setY(Double y) {
        this.y = y;
    }

    /**
     * @return the criticalPath
     */
    public Boolean getCriticalPath() {
        return criticalPath;
    }

    /**
     * @param criticalPath the criticalPath to set
     */
    public void setCriticalPath(Boolean criticalPath) {
        this.criticalPath = criticalPath;
    }

    /**
     * @return the centerPath
     */
    public Boolean getCenterPath() {
        return centerPath;
    }

    /**
     * @param centerPath the centerPath to set
     */
    public void setCenterPath(Boolean centerPath) {
        this.centerPath = centerPath;
    }

    /**
     * @return the step2c
     */
    public Integer getStep2c() {
        return step2c;
    }

    /**
     * @param step2c the step2c to set
     */
    public void setStep2c(Integer step2c) {
        this.step2c = step2c;
    }

    /**
     * @return the time2c
     */
    public Date getTime2c() {
        return time2c;
    }

    /**
     * @param time2c the time2c to set
     */
    public void setTime2c(Date time2c) {
        this.time2c = time2c;
    }
}
