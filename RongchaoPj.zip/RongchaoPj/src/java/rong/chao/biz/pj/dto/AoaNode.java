/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.biz.pj.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author ZhouRongChao
 */
@Table("pj_aoa_node")
public class AoaNode {

    @Column("id")
    @Id
    private Integer id;
    @Column("x")
    private Double x;
    @Column("y")
    private Double y;
    @Column("r")
    private Double r;
    @Column("code")
    private Integer code;
    @Column("work_id")
    private Integer workId;
    @Column("end_date")
    private Date endDate;

    public AoaNode() {
    }

    public AoaNode(Double x, Double y, Double r) {
        this.x = x;
        this.y = y;
        this.r = r;
    }

    /**
     * @return the id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return the x
     */
    public Double getX() {
        return x;
    }

    /**
     * @param x the x to set
     */
    public void setX(Double x) {
        this.x = x;
    }

    /**
     * @return the y
     */
    public Double getY() {
        return y;
    }

    /**
     * @param y the y to set
     */
    public void setY(Double y) {
        this.y = y;
    }

    /**
     * @return the r
     */
    public Double getR() {
        return r;
    }

    /**
     * @param r the r to set
     */
    public void setR(Double r) {
        this.r = r;
    }

    /**
     * @return the code
     */
    public Integer getCode() {
        return code;
    }

    /**
     * @param code the code to set
     */
    public void setCode(Integer code) {
        this.code = code;
    }

    /**
     * @return the workId
     */
    public Integer getWorkId() {
        return workId;
    }

    /**
     * @param workId the workId to set
     */
    public void setWorkId(Integer workId) {
        this.workId = workId;
    }

    /**
     * @return the endDate
     */
    public Date getEndDate() {
        return endDate;
    }

    /**
     * @param endDate the endDate to set
     */
    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }
}
