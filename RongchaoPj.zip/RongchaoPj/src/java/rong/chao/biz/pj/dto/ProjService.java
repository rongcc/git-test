/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.biz.pj.dto;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rcsoft.rc.db.CachingRcdb;

/**
 *
 * @author ZhouRongChao
 */
public class ProjService {

    DataSource ds = CachingRcdb.getInstance().getDs4Ts();
    Dao dao = new NutDao(ds);
    public int pathNumber = 0;
    public Map workQueues = Collections.synchronizedMap(new HashMap());

    /**
     * 递归寻找最大路径数目。
     * @param wList
     */
    private void getPathNumber(List wList) {
        List stepWorks = new ArrayList();
        for (int i = 0; i < wList.size(); i++) {
            ProjWork w = (ProjWork) wList.get(i);
            String fo = w.getFollowWorks();
            String[] c = fo.split(",");
            for (int n = 0; n < c.length; n++) {
                if (c[n].equals("")) {
                    continue;
                }
                ProjWork pw = dao.fetch(ProjWork.class, new Integer(c[n]));
                stepWorks.add(pw);
            }
        }
        if (stepWorks.size() > pathNumber) {
            pathNumber = stepWorks.size();
        }
        if (stepWorks.isEmpty()) {
            return;
        } else {
            getPathNumber(stepWorks);
        }
    }

    /**
     * 递归构建工作队列。
     * @param wList
     */
    private void getWorkQueues(List wList) {
        List stepWorks = new ArrayList();
        for (int i = 0; i < wList.size(); i++) {
            ProjWork w = (ProjWork) wList.get(i);
            //stepWorks
            String fo = w.getFollowWorks();
            String[] c = fo.split(",");
            for (int n = 0; n < c.length; n++) {
                if (c[n].equals("")) {
                    continue;
                }
                ProjWork pw = dao.fetch(ProjWork.class, new Integer(c[n]));
                stepWorks.add(pw);
            }
            //队列
            if (w.getPreWorks() == null) {
                Iterator iterator = workQueues.values().iterator();
                while (iterator.hasNext()) {
                    Deque que = (Deque) iterator.next();
                    que.add(w);
                }
            } else {
                Iterator iterator = workQueues.values().iterator();
                while (iterator.hasNext()) {
                    Deque que = (Deque) iterator.next();
                    ProjWork lastWork = (ProjWork) que.peekLast();

                    //队列最后一个元素是当前工作的紧前活动，则在此队列中加入此工作。
                    if (isPreWork(lastWork, w)) {
                        que.add(w);
                        break;
                    }
                }
            }
        }
        if (stepWorks.isEmpty()) {
            return;
        } else {
            getWorkQueues(stepWorks);
        }
    }

    private void getWorkQueues(List wList, Deque que) {
        List stepWorks = new ArrayList();
        for (int i = 0; i < wList.size(); i++) {
            ProjWork w = (ProjWork) wList.get(i);
            //stepWorks
            String fo = w.getFollowWorks();
            String[] c = fo.split(",");
            for (int n = 0; n < c.length; n++) {
                if (c[n].equals("")) {
                    continue;
                }
                ProjWork pw = dao.fetch(ProjWork.class, new Integer(c[n]));
                stepWorks.add(pw);
            }
            //队列
            if (w.getPreWorks() == null) {
                que.add(w);
            } else {
                ProjWork lastWork = (ProjWork) que.peekLast();
                //队列最后一个元素是当前工作的紧前活动，则在此队列中加入此工作。
                if (isPreWork(lastWork, w)) {
                    que.add(w);
                }
            }
        }
        if (stepWorks.isEmpty()) {
            return;
        } else {
            getWorkQueues(stepWorks);
        }
    }

    public ProjService() {
        List wList = dao.query(ProjWork.class, Cnd.wrap("pre_works is null"), null);
        getPathNumber(wList);
        for (int i = 1; i <= pathNumber; i++) {
            workQueues.put(i, new LinkedList());
        }
        getWorkQueues(wList);
    }

    /**
     * 判断pw是否是w的紧前工作。
     * @param pw
     * @param w
     * @return
     */
    public boolean isPreWork(ProjWork pw, ProjWork w) {
        boolean cboo = false;
        String pre = w.getPreWorks();
        String[] c = pre.split(",");
        for (int n = 0; n < c.length; n++) {
            if (c[n].equals(pw.getId() + "")) {
                cboo = true;
            }
        }
        return cboo;
    }

    /**
     * 找到该工作的紧后工作。
     * @param pw
     * @return
     */
    public List findFollowWorks(ProjWork pw) {
        List follows = new ArrayList();
        List wList = dao.query(ProjWork.class, Cnd.wrap("pre_works is not null"), null);
        for (int i = 0; i < wList.size(); i++) {
            ProjWork w = (ProjWork) wList.get(i);
            boolean cboo = false;
            String pre = w.getPreWorks();
            String[] c = pre.split(",");
            for (int n = 0; n < c.length; n++) {
                if (c[n].equals(pw.getId() + "")) {
                    cboo = true;
                }
            }
            if (cboo) {
                follows.add(w);
            }
        }
        return follows;
    }

    /**
     * 将紧后工作放入该工作紧后工作信息中。
     * @param pw
     */
    public void putFollowWorks(ProjWork pw) {
        StringBuilder followWorks = new StringBuilder();
        List follows = this.findFollowWorks(pw);
        for (int i = 0; i < follows.size(); i++) {
            ProjWork w = (ProjWork) follows.get(i);
            if (i == 0) {
                followWorks.append(w.getId());
            } else {
                followWorks.append(",");
                followWorks.append(w.getId());
            }
        }
        //System.out.println(followWorks.toString());
        pw.setFollowWorks(followWorks.toString());
        dao.update(pw);
    }

    /**
     * 为所有工作数据表设置紧后工作信息。
     */
    public void putFollowWorks4All() {
        List wList = dao.query(ProjWork.class, Cnd.wrap("1=1"), null);
        for (int i = 0; i < wList.size(); i++) {
            ProjWork pw = (ProjWork) wList.get(i);
            this.putFollowWorks(pw);
        }
    }
}
