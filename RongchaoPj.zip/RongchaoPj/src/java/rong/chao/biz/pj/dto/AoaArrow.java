/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.biz.pj.dto;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author ZhouRongChao
 */
@Table("pj_aoa_arrow")
public class AoaArrow {

    @Column("id")
    @Id
    private Integer id;
    @Column("start_node")
    private Integer startNode;
    @Column("end_node")
    private Integer endNode;
    @Column("work_id")
    private Integer workId;
    @Column("name")
    private String name;
    @Column("time_limit")
    private Integer timeLimit;

    /**
     * @return the id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return the startNode
     */
    public Integer getStartNode() {
        return startNode;
    }

    /**
     * @param startNode the startNode to set
     */
    public void setStartNode(Integer startNode) {
        this.startNode = startNode;
    }

    /**
     * @return the endNode
     */
    public Integer getEndNode() {
        return endNode;
    }

    /**
     * @param endNode the endNode to set
     */
    public void setEndNode(Integer endNode) {
        this.endNode = endNode;
    }

    /**
     * @return the workId
     */
    public Integer getWorkId() {
        return workId;
    }

    /**
     * @param workId the workId to set
     */
    public void setWorkId(Integer workId) {
        this.workId = workId;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the timeLimit
     */
    public Integer getTimeLimit() {
        return timeLimit;
    }

    /**
     * @param timeLimit the timeLimit to set
     */
    public void setTimeLimit(Integer timeLimit) {
        this.timeLimit = timeLimit;
    }
}
