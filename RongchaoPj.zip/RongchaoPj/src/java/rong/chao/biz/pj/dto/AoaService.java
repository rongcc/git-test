/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.biz.pj.dto;

import java.util.ArrayList;
import java.util.Deque;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rcsoft.rc.db.CachingRcdb;

/**
 *
 * @author ZhouRongChao
 */
public class AoaService {

    DataSource ds = CachingRcdb.getInstance().getDs4Ts();
    Dao dao = new NutDao(ds);

    public void work2node() {
        AoaNode node = new AoaNode(0.0, 0.0, 10.0);
        node.setCode(1);
        dao.insert(node);
        List follows = new ArrayList();
        List wList = dao.query(ProjWork.class, Cnd.wrap("1=1"), null);
        for (int i = 0; i < wList.size(); i++) {
            ProjWork w = (ProjWork) wList.get(i);
            double x = w.getSchTimeLimit() * 24;
            node = new AoaNode(x, 0.0, 10.0);
            node.setWorkId(w.getId());
            dao.insert(node);
        }
    }

    public void work2path() {
        //获取路径数目
        ProjService ps = new ProjService();
        Map workQueues = ps.workQueues;
        Iterator iterator = workQueues.values().iterator();
        while (iterator.hasNext()) {
            AoaPath ap = new AoaPath();
            StringBuilder sb = new StringBuilder();
            Deque que = (Deque) iterator.next();
            for (int i = 0; 0 < que.size(); i++) {
                ProjWork w = (ProjWork) que.pollFirst();
                if (i == 0) {
                    sb.append(w.getId());
                } else {
                    sb.append(",");
                    sb.append(w.getId());
                }
            }
            ap.setWorks(sb.toString());
            dao.insert(ap);
        }
    }

    public void work2path_node() {
    }

    public void node2arrow() {
    }
}
