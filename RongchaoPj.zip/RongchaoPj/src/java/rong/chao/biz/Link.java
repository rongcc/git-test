/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.biz;

/**
 *
 * @author ZhouRongChao
 */
public interface Link {
    
}
