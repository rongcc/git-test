/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.biz;

import java.util.Deque;
import java.util.LinkedList;

/**
 * 流程。
 *
 * @author ZhouRongChao
 */
public abstract class AbstractProcess implements Process {

    /**
     * 链结集合的双端列表。
     */
    private Deque linkDeque = new LinkedList();

    public AbstractProcess() {
    }

    /**
     * 将指定链结插入双端队列的末尾。
     *
     * @param link
     */
    public void addLast(Link link) {
        linkDeque.addLast(link);
    }

    /**
     * 将指定链结插入双端队列的开头。
     *
     * @param link
     */
    public void addFirst(Link link) {
        linkDeque.addFirst(link);
    }

    /**
     * 获取，但不移除此双端队列的最后一个元素。
     *
     * @return
     */
    public Link getLast() {
        return (Link) linkDeque.getLast();
    }

    /**
     * 获取，但不移除此双端队列的第一个元素。
     *
     * @return
     */
    public Link getFirst() {
        return (Link) linkDeque.getFirst();
    }
}
