/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.biz.lucene;

import org.apache.lucene.index.Term;
import org.apache.lucene.search.*;

/**
 * 查询类
 *
 * @author ZhouRongChao
 */
public class QueryUtil {

    /**
     * 功能：按词条搜索 － TermQuery
     *
     * @param field field的名称
     * @param searchKey 查询的词
     * @return
     */
    public static Query searchByTeam(String field, String searchKey) {
        System.err.println("TermQuery test demo------");
        Term term = new Term(field, searchKey);
        Query query = new TermQuery(term);
        System.err.println("查询条件:" + query);
        System.err.println("查询语义:查询在AlarmType中出现\"" + searchKey + "\"这个词的Document.");
        return query;
    }

    /**
     * 功能：查询俩个子查询的交集
     *
     * @param qy1
     * @param qy2
     * @return
     */
    public static Query booleanAndSearch(Query qy1, Query qy2) {
        BooleanQuery query = new BooleanQuery();//新建一个布尔查询
        query.add(qy1, BooleanClause.Occur.MUST);
        query.add(qy2, BooleanClause.Occur.MUST);
        return query;
    }

    /**
     * 功能：查询俩个子查询的交集
     *
     * @param fieldOne 第一个子查询field
     * @param searchKeyOne 第一个子查询关键词
     * @param fieldTwo 第二个子查询的field
     * @param searchKeyTwo 第二个子查询的关键词
     * @return
     */
    public static Query searchByBooleanAnd(String fieldOne, String searchKeyOne, String fieldTwo, String searchKeyTwo) {
        BooleanQuery query = new BooleanQuery();//新建一个布尔查询
        Query qy1 = QueryUtil.searchByTeam(fieldOne, searchKeyOne);
        Query qy2 = QueryUtil.searchByTeam(fieldTwo, searchKeyTwo);
        query.add(qy1, BooleanClause.Occur.MUST);
        query.add(qy2, BooleanClause.Occur.MUST);
        System.err.println("查询条件:" + query);
        System.err.println("查询语义:查询在" + fieldOne + "中包含\"" + searchKeyOne + "\"这个词但是不能包含查询在" + fieldTwo + "中包含\"" + searchKeyTwo + "\"的Document.");
        return query;
    }

    /**
     * 功能：查询俩个子查询的并集
     *
     * @param fieldOne 第一个子查询field
     * @param searchKeyOne 第一个子查询关键词
     * @param fieldTwo 第二个子查询的field
     * @param searchKeyTwo 第二个子查询的关键词
     * @return
     */
    public static Query searchByBooleanOr(String fieldOne, String searchKeyOne, String fieldTwo, String searchKeyTwo) {
        BooleanQuery query = new BooleanQuery();//新建一个布尔查询
        Query qy1 = QueryUtil.searchByTeam(fieldOne, searchKeyOne);
        Query qy2 = QueryUtil.searchByTeam(fieldTwo, searchKeyTwo);
        query.add(qy1, BooleanClause.Occur.SHOULD);
        query.add(qy2, BooleanClause.Occur.SHOULD);
        System.err.println("查询条件:" + query);
        System.err.println("查询语义:包含查询在" + fieldOne + "中包含\"" + searchKeyOne + "\"这个词而且包含查询在" + fieldTwo + "中包含\"" + searchKeyTwo + "\"的Document.");

        return query;
    }

    /**
     * 功能：查询俩个子查询的 差集,第一个子查询的结果不包含第二个子查询
     *
     * @param fieldOne 第一个子查询field
     * @param searchKeyOne 第一个子查询关键词
     * @param fieldTwo 第二个子查询的field
     * @param searchKeyTwo 第二个子查询的关键词
     * @return
     */
    public static Query searchByBooleanNot(String fieldOne, String searchKeyOne, String fieldTwo, String searchKeyTwo) {
        BooleanQuery query = new BooleanQuery();//新建一个布尔查询
        Query qy1 = QueryUtil.searchByTeam(fieldOne, searchKeyOne);
        Query qy2 = QueryUtil.searchByTeam(fieldTwo, searchKeyTwo);
        query.add(qy1, BooleanClause.Occur.MUST);
        query.add(qy2, BooleanClause.Occur.MUST_NOT);
        System.err.println("查询条件:" + query);
        System.err.println("查询语义:查询在" + fieldOne + "中包含\"" + searchKeyOne + "\"这个词但是不包含查询在" + fieldTwo + "中包含\"" + searchKeyTwo + "\"的Document.");

        return query;
    }

    /**
     * 功能：词组查询也称短语查询
     *
     * @param fields 查询的field
     * @param keywords 关键词数组
     * @return
     */
    public static Query searchByManyKeywords(String fields, String[] keywords) {
        PhraseQuery query = new PhraseQuery();
        String str = null;
        for (int i = 0; i < keywords.length; i++) {
            query.add(new Term(fields, keywords[i]));
            str = str + keywords[i];
        }
        query.setSlop(5);
        System.err.println("查询条件:" + query);
        System.err.println("查询语义:查询" + fields + "中含有:" + str + "的数据，这几个词至少移动五步才能构成词组，返回符合条件的Document.");
        return query;
    }
}
