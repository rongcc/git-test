/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.biz.lucene;

import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexWriterConfig.OpenMode;
import org.apache.lucene.index.Term;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;

/**
 * 更新索引
 *
 * @author ZhouRongChao
 */
public class UpdateIndex {

    /**
     * 功能：删除原先的索引之后，新增新的索引
     *
     * @param rm
     */
    public static void updateAndNewIndex(ResumeModel rm) {
        try {
            if (rm.getState() == 1) {//已经存在了简历
                deleteIndex("id", String.valueOf(rm.getResumeId()));
            }
            Document doc = CreateIndex.builderDocument(rm);
            Directory dir = FSDirectory.open(Constant.INDEX_DIR);
            IndexWriterConfig config = new IndexWriterConfig(Version.LUCENE_35, Constant.analyzer).setOpenMode(OpenMode.APPEND);
            IndexWriter writer = new IndexWriter(dir, config);
            writer.addDocument(doc);
            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * 删除索引，这里主要是对resumeId进行查询，然后删除这个结果
     *
     * @param field
     * @param keyword
     * @throws Exception
     */
    public static void deleteIndex(String field, String keyword) throws Exception {
        long startTime = System.currentTimeMillis();
        //首先，我们需要先将相应的document删除   
        Directory dir = FSDirectory.open(Constant.INDEX_DIR);
        IndexReader reader = IndexReader.open(dir, false);
        Term term = new Term(field, keyword);
        reader.deleteDocuments(term);
        reader.close();
        long endTime = System.currentTimeMillis();
        System.out.println("total time: " + (endTime - startTime) + " ms");
    }
}
