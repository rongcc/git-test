/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.biz.lucene;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexWriterConfig.OpenMode;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;

/**
 * 创建索引类
 *
 * @author ZhouRongChao
 */
public class CreateIndex {

//	private static final File INDEX_DIR = new File("E:\\新的设计目录\\txlpf\\lucene");
//    private static final Analyzer analyzer = new StandardAnalyzer(Version.LUCENE_35);  
    /**
     * 将简历信息添加到索引库中
     *
     * @param list
     * @throws IOException
     */
    public static void index(List<ResumeModel> list) throws IOException {
        long start1 = new Date().getTime();
        IndexWriter writer = openIndexWriter();
        try {
            for (ResumeModel rm : list) {
                Document document = builderDocument(rm);
                writer.addDocument(document);
            }
        } finally {
            writer.close();
        }
        long end1 = new Date().getTime();
        System.out.println("创建索引花费时间：" + (double) (end1 - start1) / 1000 + "秒");
    }

    private static IndexWriter openIndexWriter() throws IOException {
        IndexWriterConfig iwc = new IndexWriterConfig(Version.LUCENE_35,
                Constant.analyzer);
        iwc.setOpenMode(OpenMode.CREATE_OR_APPEND);//增量型索引 ，这个地方是关于你创建索引是增量的还是始终创建的。一般来说，选择create_or_append比较好，无论你是否已经创建了索引，都满足
        return new IndexWriter(FSDirectory.open(Constant.INDEX_DIR), iwc);
    }

    /**
     * 创建索引
     *
     * @param obj 要创建索引的对象
     * @return
     */
    public static Document builderDocument(ResumeModel rm) {
        Document document = new Document();
        String state = null;
        if (rm.getState() == 0) {
            state = "未录用";
        } else {
            state = "已录用";
        }
        Field id = new Field("id", String.valueOf(rm.getResumeId()), Field.Store.YES, Field.Index.ANALYZED);
        Field content = new Field("content", rm.getDegree() + rm.getJingyan() + rm.getWorkExp() + rm.getEducationExp() + rm.getProjectExp() + rm.getSelfEvaluation() + state, Field.Store.YES, Field.Index.ANALYZED);
        document.add(id);
        document.add(content);
        return document;
    }
}