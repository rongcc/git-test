/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.biz.lucene;

import java.io.File;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.util.Version;

/**
 *
 * @author ZhouRongChao
 */
public class Constant {

//	private static final File INDEX_DIR = new File("E:\\新的设计目录\\txlpf\\lucene");
//    private static final Analyzer analyzer = new StandardAnalyzer(Version.LUCENE_35);  
    static Analyzer analyzer = new StandardAnalyzer(Version.LUCENE_35);
    static File INDEX_DIR = new File("E:\\新的设计目录\\txlpf\\lucene");
}
