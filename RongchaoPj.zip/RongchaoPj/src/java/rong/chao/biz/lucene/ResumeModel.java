/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.biz.lucene;

/**
 *
 * @author ZhouRongChao
 */
public class ResumeModel {

    private int resumeId;
    private String degree;
    private String jingyan;
    private String workExp;
    private String educationExp;
    private String projectExp;
    private String selfEvaluation;
    private int state;

    /**
     * @return the resumeId
     */
    public int getResumeId() {
        return resumeId;
    }

    /**
     * @param resumeId the resumeId to set
     */
    public void setResumeId(int resumeId) {
        this.resumeId = resumeId;
    }

    /**
     * @return the degree
     */
    public String getDegree() {
        return degree;
    }

    /**
     * @param degree the degree to set
     */
    public void setDegree(String degree) {
        this.degree = degree;
    }

    /**
     * @return the jingyan
     */
    public String getJingyan() {
        return jingyan;
    }

    /**
     * @param jingyan the jingyan to set
     */
    public void setJingyan(String jingyan) {
        this.jingyan = jingyan;
    }

    /**
     * @return the workExp
     */
    public String getWorkExp() {
        return workExp;
    }

    /**
     * @param workExp the workExp to set
     */
    public void setWorkExp(String workExp) {
        this.workExp = workExp;
    }

    /**
     * @return the educationExp
     */
    public String getEducationExp() {
        return educationExp;
    }

    /**
     * @param educationExp the educationExp to set
     */
    public void setEducationExp(String educationExp) {
        this.educationExp = educationExp;
    }

    /**
     * @return the projectExp
     */
    public String getProjectExp() {
        return projectExp;
    }

    /**
     * @param projectExp the projectExp to set
     */
    public void setProjectExp(String projectExp) {
        this.projectExp = projectExp;
    }

    /**
     * @return the selfEvaluation
     */
    public String getSelfEvaluation() {
        return selfEvaluation;
    }

    /**
     * @param selfEvaluation the selfEvaluation to set
     */
    public void setSelfEvaluation(String selfEvaluation) {
        this.selfEvaluation = selfEvaluation;
    }

    /**
     * @return the state
     */
    public int getState() {
        return state;
    }

    /**
     * @param state the state to set
     */
    public void setState(int state) {
        this.state = state;
    }
}
