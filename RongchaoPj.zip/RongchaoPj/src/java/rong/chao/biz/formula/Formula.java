/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.biz.formula;

import java.util.Vector;

/**
 *
 * @author ZhouRongChao
 */
public class Formula {

    /**
     * 存放公式对应的Beanshell脚本
     */
    private String script;
    /**
     * 存放公式中包含的参数项，每个参数项包含一个String[2]数组，String[0]存放 参数名，String[1]存放参数类型
     */
    private Vector parameters;

    public Formula(String srt, Vector para) {
        script = srt;
        parameters = para;
    }

    /**
     * 获得公式对应的Beanshell脚本。
     *
     * @return
     */
    public String getScript() {
        return script;
    }

    /**
     * 获得存放公式中包含的参数项。
     *
     * @return
     */
    public Vector getParameters() {
        return parameters;
    }
}
