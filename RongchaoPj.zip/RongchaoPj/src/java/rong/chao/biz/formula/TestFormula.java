/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.biz.formula;

import java.util.Hashtable;

/**
 *
 * @author ZhouRongChao
 */
public class TestFormula {

    /**
     * Creates a new instance of TestFormula
     */
    public TestFormula() {
        FormulaParser fp = new FormulaParser();
        Hashtable paras = new Hashtable();
        paras.put("price", new Double(100.0));
        paras.put("discount", new Double(0.9));
        System.out.println("计算结果：" + fp.caculateByFormula(fp.loadFormula("1001"), paras));
        FormulaParser fp1 = new FormulaParser();
        Hashtable paras1 = new Hashtable();
        paras1.put("sale", new Double(11000.0));
        paras1.put("score", new Double(0.8));
        System.out.println("计算结果：" + fp1.caculateByFormula(fp1.loadFormula("1002"), paras1));
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        TestFormula tf = new TestFormula();
    }
}
