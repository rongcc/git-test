/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.biz.formula;

import bsh.Interpreter;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;

/**
 * 公式解析器
 *
 * @author ZhouRongChao
 */
public class FormulaParser {

    private static String prefix = "E:\\zaixj\\workspace2010\\RongchaoPj\\src\\";

    public FormulaParser() {
        //prefix= System.getProperty("user.dir");
    }

    public void storeFormula(String express) {
    }

    /**
     * 用公式进行计算。
     *
     * @param formula 公式
     * @param parameters 参数
     * @return
     */
    public double caculateByFormula(Formula formula, Hashtable parameters) {
        double result = 0.0;
        try {
            //beanshell的解释器
            Interpreter i = new Interpreter(); // Construct an interpreter
            i.eval("import rong.chao.biz.formula.*;");
            Vector para = formula.getParameters();
            Iterator it = para.iterator();
            while (it.hasNext()) {
                String[] dec = (String[]) it.next();
                String declare = dec[1] + " " + dec[0];
                i.eval(declare);
                String value = ((Double) parameters.get(dec[0])).toString();
                if (value != null) {
                    String assign_value = dec[0] + "=" + value;
                    i.eval(assign_value);
                } else {
                    System.out.println("caculateByFormula():" + dec[0] + "参数名不符或改参数不存在");
                    System.exit(1);
                }
            }
            //参数设置成功，根据公式进行计算
            i.eval(formula.getScript());
            Double rst = (Double) i.get("result");
            result = rst.doubleValue();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return result;
    }

    /**
     * （从自定义公式的xml文件中）加载公式。
     *
     * @param formulaID 自定义公式的ID
     * @return
     */
    public Formula loadFormula(String formulaID) {
        Vector paras = new Vector();
        try {
            SAXBuilder builder = new SAXBuilder();
            Document doc = builder.build(prefix + "Formulas.xml");
            Element root = doc.getRootElement();
            List formulas = root.getChildren("formula");
            Iterator it = formulas.iterator();
            Element formula = null;
            while (it.hasNext()) {
                formula = (Element) it.next();
                if (formula.getAttributeValue("id").equals(formulaID)) {
                    break;
                }
            }
            //获取参数列表
            List parameters = formula.getChild("parameters").getChildren();
            Iterator itp = parameters.iterator();
            while (itp.hasNext()) {
                String[] s_para = new String[2];
                Element e_para = (Element) itp.next();
                s_para[0] = e_para.getAttributeValue("name");
                s_para[1] = e_para.getAttributeValue("type");
                paras.add(s_para);
            }
            Element script = formula.getChild("script");
            String s_script = script.getTextTrim();
            return new Formula(s_script, paras);
        } catch (Exception e) {
            System.out.println("loadFormula():" + e.getMessage());
        }
        return null;
    }

    private void convertExpression(String express) {
    }
}
