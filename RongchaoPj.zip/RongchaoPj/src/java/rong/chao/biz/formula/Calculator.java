/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.biz.formula;

/**
 *
 * @author ZhouRongChao
 */
public class Calculator {

    /**
     * 加
     *
     * @param x
     * @param y
     * @return
     */
    public static double add(double x, double y) {
        return x + y;
    }

    /**
     * 减
     *
     * @param x
     * @param y
     * @return
     */
    public static double sub(double x, double y) {
        return x - y;
    }

    /**
     * 乘
     *
     * @param x
     * @param y
     * @return
     */
    public static double mutiply(double x, double y) {
        return x * y;
    }

    /**
     * 除以
     *
     * @param x
     * @param y
     * @return
     */
    public static double divide(double x, double y) {
        return x / y;
    }
}
