/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.biz.proj;

import java.util.Date;
import java.util.List;
import javax.sql.DataSource;
import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.util.GenericForwardComposer;
import org.zkoss.zul.Chart;
import org.zkoss.zul.GanttModel;
import org.zkoss.zul.GanttModel.GanttTask;
import rcsoft.rc.db.CachingRcdb;

/**
 *
 * @author ZhouRongChao
 */
public class GanttComposer extends GenericForwardComposer {

    GanttModel ganttmodel;
    Chart chart;
    Integer pjId;

    @Override
    public void doAfterCompose(Component comp) throws Exception {

        super.doAfterCompose(comp);
        if (session.getAttribute("pj") != null) {
            pjId = (Integer) session.getAttribute("pj");
            refreshModel(pjId);
        }
    }

    private void refreshModel(Integer p) {
        DataSource ds = CachingRcdb.getInstance().getDs4Ts();
        Dao dao = new NutDao(ds);
        ProjWork pw = dao.fetch(ProjWork.class, p);
        List wList = dao.query(ProjWork.class, Cnd.wrap("where father_id=" + pw.getId()), null);
        ganttmodel = new GanttModel();
        for (int i = 0; i < wList.size(); i++) {
            ProjWork w = (ProjWork) wList.get(i);
            ganttmodel.addValue("计划", new GanttTask(w.getName(), w.getSchStartDate(), w.getSchEndDate(), w.getSchPercent()));
        }
        /*
        for (int i = 0; i < wList.size(); i++) {
        ProjWork w = (ProjWork) wList.get(i);
        ganttmodel.addValue("实际", new GanttTask(w.getName(), w.getActStartDate(), w.getActEndDate(), w.getActPercent()));
        }
         */
        chart.setTitle(pw.getName());
        chart.setModel(ganttmodel);
        chart.setHeight((wList.size() * 18+80) + "px");
        chart.setWidth((pw.getSchTimeLimit().intValue() * 12+100) + "px");
    }

    public Date date(int year, int month, int day) {
        final java.util.Calendar calendar = java.util.Calendar.getInstance();
        calendar.set(year, month - 1, day);
        final Date result = calendar.getTime();
        return result;
    }

    public Date datehm(int year, int month, int day, int hourOfDay, int minute) {
        final java.util.Calendar calendar = java.util.Calendar.getInstance();
        calendar.set(year, month - 1, day, hourOfDay, minute);
        final Date result = calendar.getTime();
        return result;
    }
}
