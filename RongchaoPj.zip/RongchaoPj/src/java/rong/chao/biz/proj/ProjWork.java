/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.biz.proj;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author ZhouRongChao
 */
@Table("pj_proj_work")
public class ProjWork {

    @Column("id")
    @Id
    private Integer id;
    @Column("code")
    private String code;
    @Column("name")
    private String name;
    @Column("type")
    private String type;
    @Column("pre_works")
    private String preWorks;
    @Column("follow_works")
    private String followWorks;
    @Column("sch_start_date")
    private Date schStartDate;
    @Column("sch_end_date")
    private Date schEndDate;
    @Column("act_start_date")
    private Date actStartDate;
    @Column("act_end_date")
    private Date actEndDate;
    @Column("sch_percent")
    private Double schPercent;
    @Column("act_percent")
    private Double actPercent;
    @Column("sch_time_limit")
    private Double schTimeLimit;
    @Column("act_time_limit")
    private Double actTimeLimit;
    @Column("unit_of_time")
    private String unitOfTime;
    @Column("father_id")
    private Integer fatherId;
    @Column("father_name")
    private String fatherName;
    @Column("level")
    private Integer level;

    /**
     * @return the id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * @param code the code to set
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return the preWorks
     */
    public String getPreWorks() {
        return preWorks;
    }

    /**
     * @param preWorks the preWorks to set
     */
    public void setPreWorks(String preWorks) {
        this.preWorks = preWorks;
    }

    /**
     * @return the followWorks
     */
    public String getFollowWorks() {
        return followWorks;
    }

    /**
     * @param followWorks the followWorks to set
     */
    public void setFollowWorks(String followWorks) {
        this.followWorks = followWorks;
    }

    /**
     * @return the schStartDate
     */
    public Date getSchStartDate() {
        return schStartDate;
    }

    /**
     * @param schStartDate the schStartDate to set
     */
    public void setSchStartDate(Date schStartDate) {
        this.schStartDate = schStartDate;
    }

    /**
     * @return the schEndDate
     */
    public Date getSchEndDate() {
        return schEndDate;
    }

    /**
     * @param schEndDate the schEndDate to set
     */
    public void setSchEndDate(Date schEndDate) {
        this.schEndDate = schEndDate;
    }

    /**
     * @return the actStartDate
     */
    public Date getActStartDate() {
        return actStartDate;
    }

    /**
     * @param actStartDate the actStartDate to set
     */
    public void setActStartDate(Date actStartDate) {
        this.actStartDate = actStartDate;
    }

    /**
     * @return the actEndDate
     */
    public Date getActEndDate() {
        return actEndDate;
    }

    /**
     * @param actEndDate the actEndDate to set
     */
    public void setActEndDate(Date actEndDate) {
        this.actEndDate = actEndDate;
    }

    /**
     * @return the schPercent
     */
    public Double getSchPercent() {
        return schPercent;
    }

    /**
     * @param schPercent the schPercent to set
     */
    public void setSchPercent(Double schPercent) {
        this.schPercent = schPercent;
    }

    /**
     * @return the actPercent
     */
    public Double getActPercent() {
        return actPercent;
    }

    /**
     * @param actPercent the actPercent to set
     */
    public void setActPercent(Double actPercent) {
        this.actPercent = actPercent;
    }

    /**
     * @return the schTimeLimit
     */
    public Double getSchTimeLimit() {
        return schTimeLimit;
    }

    /**
     * @param schTimeLimit the schTimeLimit to set
     */
    public void setSchTimeLimit(Double schTimeLimit) {
        this.schTimeLimit = schTimeLimit;
    }

    /**
     * @return the actTimeLimit
     */
    public Double getActTimeLimit() {
        return actTimeLimit;
    }

    /**
     * @param actTimeLimit the actTimeLimit to set
     */
    public void setActTimeLimit(Double actTimeLimit) {
        this.actTimeLimit = actTimeLimit;
    }

    /**
     * @return the unitOfTime
     */
    public String getUnitOfTime() {
        return unitOfTime;
    }

    /**
     * @param unitOfTime the unitOfTime to set
     */
    public void setUnitOfTime(String unitOfTime) {
        this.unitOfTime = unitOfTime;
    }

    /**
     * @return the fatherId
     */
    public Integer getFatherId() {
        return fatherId;
    }

    /**
     * @param fatherId the fatherId to set
     */
    public void setFatherId(Integer fatherId) {
        this.fatherId = fatherId;
    }

    /**
     * @return the fatherName
     */
    public String getFatherName() {
        return fatherName;
    }

    /**
     * @param fatherName the fatherName to set
     */
    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }

    /**
     * @return the level
     */
    public Integer getLevel() {
        return level;
    }

    /**
     * @param level the level to set
     */
    public void setLevel(Integer level) {
        this.level = level;
    }
    

}
