/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.biz.proj;

import java.util.List;
import javax.sql.DataSource;
import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import org.zkforge.timeline.Bandinfo;
import org.zkforge.timeline.Timeline;
import org.zkforge.timeline.data.OccurEvent;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.util.GenericForwardComposer;
import rcsoft.rc.db.CachingRcdb;

/**
 *
 * @author ZhouRongChao
 */
public class TimelineComposer extends GenericForwardComposer {

    Timeline timeline;
    Bandinfo b1;
    Bandinfo b2;
    Bandinfo b3;
    Integer pjId;

    @Override
    public void doAfterCompose(Component comp) throws Exception {
        super.doAfterCompose(comp);
        if (session.getAttribute("pj") != null) {
            pjId = (Integer) session.getAttribute("pj");
            refreshModel(pjId);
        }
    }

    public void onClick$freshBt() {
        if (session.getAttribute("pj") != null) {
            pjId = (Integer) session.getAttribute("pj");
            refreshModel(pjId);
        }
    }

    private void refreshModel(Integer p) {
        DataSource ds = CachingRcdb.getInstance().getDs4Ts();
        Dao dao = new NutDao(ds);
        ProjWork pw = dao.fetch(ProjWork.class, p);
        List wList = dao.query(ProjWork.class, Cnd.wrap("where father_id=" + pw.getId()), null);
        for (int i = 0; i < wList.size(); i++) {
            ProjWork w = (ProjWork) wList.get(i);
            OccurEvent event = new OccurEvent();
            event.setStart(w.getSchStartDate());
            event.setEnd(w.getSchEndDate());
            event.setDuration(false);
            event.setText("" + w.getName());
            event.setDescription("" + w.getCode());
            if (new java.util.Date().after(w.getSchEndDate()) && w.getActPercent() < 1) {
                event.setColor("red");
            }
            if (new java.util.Date().after(w.getSchStartDate()) && w.getActPercent() == 0) {
                event.setTextColor("red");
            }
            if (w.getActPercent() == 1) {
                event.setColor("green");
            }
            b1.addOccurEvent(event);
        }
        b2.setOverview(true);
        b3.setOverview(true);
    }
}
