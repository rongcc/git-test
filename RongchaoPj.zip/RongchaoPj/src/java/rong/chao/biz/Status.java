/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.biz;

/**
 * 状态。
 *
 * @author ZhouRongChao
 */
public interface Status {
}
