/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.rcsoft.zcal;

import java.util.List;
import javax.sql.DataSource;
import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;

/**
 *
 * @author ZhouRongChao
 */
public class MyCalendarService {

    /**
     * 获取我的日历的事情列表。
     * @param ds
     * @param operNo
     * @return
     */
    public List getMyEventList(DataSource ds, String operNo) {
        List al = null;
        try {
            Dao dao = new NutDao(ds);
            al = dao.query(MyCalendarEvent.class, Cnd.where("input_name", "=", operNo).desc("id"), null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return al;
    }

    /**
     * 更新一个事情。
     * @param ds
     * @param event
     * @return
     */
    public int updateMyEvent(DataSource ds, MyCalendarEvent event) {
        int di = 0;
        try {
            Dao dao = new NutDao(ds);
            di = dao.update(event);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return di;
    }

    /**
     * 删除一个事情。
     * @param ds
     * @param event
     * @return
     */
    public int removeMyEvent(DataSource ds, MyCalendarEvent event) {
        int di = 0;
        try {
            Dao dao = new NutDao(ds);
            di = dao.delete(event);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return di;
    }
}
