/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.rcsoft.zcal;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;
import org.zkoss.calendar.impl.SimpleCalendarEvent;

/**
 *
 * @author ZhouRongChao
 */
@Table("my_calendar_event")
public class MyCalendarEvent extends SimpleCalendarEvent {

    @Id
    @Column("id")
    private Integer id;
    @Column("begin_date")
    private Date beginDate;
    @Column("end_date")
    private Date endDate;
    @Column("title")
    private String title;
    @Column("content")
    private String content;
    @Column("header_color")
    private String headerColor;
    @Column("content_color")
    private String contentColor;
    @Column("locked")
    private boolean locked;
    @Column("status")
    private int status;
    @Column("remark")
    private String remark;
    @Column("pin")
    private Double pin;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;
    @Column("edit_date")
    private Date editDate;
    @Column("edit_name")
    private String editName;

    public MyCalendarEvent() {
    }

    public MyCalendarEvent(Integer id) {
        this.id = id;
    }

    public MyCalendarEvent(Integer id, Date beginDate, Date endDate, String content, boolean locked, int status) {
        this.id = id;
        this.beginDate = beginDate;
        this.endDate = endDate;
        this.content = content;
        this.locked = locked;
        this.status = status;
    }

    /**
     * @return the id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return the beginDate
     */
    public Date getBeginDate() {
        return beginDate;
    }

    /**
     * @param beginDate the beginDate to set
     */
    public void setBeginDate(Date beginDate) {
        this.beginDate = beginDate;
    }

    /**
     * @return the endDate
     */
    public Date getEndDate() {
        return endDate;
    }

    /**
     * @param endDate the endDate to set
     */
    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @return the content
     */
    public String getContent() {
        return content;
    }

    /**
     * @param content the content to set
     */
    public void setContent(String content) {
        this.content = content;
    }

    /**
     * @return the headerColor
     */
    public String getHeaderColor() {
        return headerColor;
    }

    /**
     * @param headerColor the headerColor to set
     */
    public void setHeaderColor(String headerColor) {
        this.headerColor = headerColor;
    }

    /**
     * @return the contentColor
     */
    public String getContentColor() {
        return contentColor;
    }

    /**
     * @param contentColor the contentColor to set
     */
    public void setContentColor(String contentColor) {
        this.contentColor = contentColor;
    }

    /**
     * @return the locked
     */
    public boolean isLocked() {
        return locked;
    }

    /**
     * @param locked the locked to set
     */
    public void setLocked(boolean locked) {
        this.locked = locked;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * @param remark the remark to set
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * @return the pin
     */
    public Double getPin() {
        return pin;
    }

    /**
     * @param pin the pin to set
     */
    public void setPin(Double pin) {
        this.pin = pin;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    /**
     * @return the editDate
     */
    public Date getEditDate() {
        return editDate;
    }

    /**
     * @param editDate the editDate to set
     */
    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }

    /**
     * @return the editName
     */
    public String getEditName() {
        return editName;
    }

    /**
     * @param editName the editName to set
     */
    public void setEditName(String editName) {
        this.editName = editName;
    }
}
