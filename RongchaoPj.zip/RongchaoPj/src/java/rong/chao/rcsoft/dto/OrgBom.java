/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.rcsoft.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.PK;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author ZhouRongChao
 */
@Table("org_bom")
@PK({"fatherId", "sonId"})
public class OrgBom {

    @Column("father_id")
    private int fatherId;
    @Column("son_id")
    private int sonId;
    @Column("father_name")
    private String fatherName;
    @Column("son_name")
    private String sonName;
    @Column("obs_type")
    private String obsType;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;

    /**
     * @return the fatherId
     */
    public int getFatherId() {
        return fatherId;
    }

    /**
     * @param fatherId the fatherId to set
     */
    public void setFatherId(int fatherId) {
        this.fatherId = fatherId;
    }

    /**
     * @return the sonId
     */
    public int getSonId() {
        return sonId;
    }

    /**
     * @param sonId the sonId to set
     */
    public void setSonId(int sonId) {
        this.sonId = sonId;
    }

    /**
     * @return the fatherName
     */
    public String getFatherName() {
        return fatherName;
    }

    /**
     * @param fatherName the fatherName to set
     */
    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }

    /**
     * @return the sonName
     */
    public String getSonName() {
        return sonName;
    }

    /**
     * @param sonName the sonName to set
     */
    public void setSonName(String sonName) {
        this.sonName = sonName;
    }

    /**
     * @return the obsType
     */
    public String getObsType() {
        return obsType;
    }

    /**
     * @param obsType the obsType to set
     */
    public void setObsType(String obsType) {
        this.obsType = obsType;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }
}
