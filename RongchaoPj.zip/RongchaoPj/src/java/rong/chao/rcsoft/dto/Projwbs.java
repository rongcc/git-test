/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.rcsoft.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author ZhouRongChao
 */
@Table("projwbs")
public class Projwbs {

    @Column("father_work_id")
    private Integer fatherWorkId;
    @Column("father_work_name")
    private String fatherWorkName;
    @Column("pre_work_id")
    private Integer preWorkId;
    @Column("pre_work_name")
    private String preWorkName;
    @Id
    @Column("work_id")
    private Integer workId;
    @Column("work_name")
    private String workName;
    @Column("wbs_code")
    private String wbsCode;
    @Column("sch_start_date")
    private Date schStartDate;
    @Column("sch_end_date")
    private Date schEndDate;
    @Column("act_start_date")
    private Date actStartDate;
    @Column("act_end_date")
    private Date actEndDate;
    @Column("sch_percent")
    private Double schPercent;
    @Column("act_percent")
    private Double actPercent;
    @Column("take_name")
    private String takeName;
    @Column("time_limit_sch")
    private Double timeLimitSch;
    @Column("time_limit_act")
    private Double timeLimitAct;
    @Column("time_limit_units")
    private String timeLimitUnits;
    @Column("level_num")
    private Integer levelNum;
    @Column("finished")
    private boolean finished;
    @Column("type")
    private String type;
    @Column("description")
    private String description;
    @Column("status")
    private int status;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;
    @Column("edit_date")
    private Date editDate;
    @Column("edit_name")
    private String editName;
    @Column("pin")
    private Double pin;

    /**
     * @return the fatherWorkId
     */
    public Integer getFatherWorkId() {
        return fatherWorkId;
    }

    /**
     * @param fatherWorkId the fatherWorkId to set
     */
    public void setFatherWorkId(Integer fatherWorkId) {
        this.fatherWorkId = fatherWorkId;
    }

    /**
     * @return the fatherWorkName
     */
    public String getFatherWorkName() {
        return fatherWorkName;
    }

    /**
     * @param fatherWorkName the fatherWorkName to set
     */
    public void setFatherWorkName(String fatherWorkName) {
        this.fatherWorkName = fatherWorkName;
    }

    /**
     * @return the preWorkId
     */
    public Integer getPreWorkId() {
        return preWorkId;
    }

    /**
     * @param preWorkId the preWorkId to set
     */
    public void setPreWorkId(Integer preWorkId) {
        this.preWorkId = preWorkId;
    }

    /**
     * @return the preWorkName
     */
    public String getPreWorkName() {
        return preWorkName;
    }

    /**
     * @param preWorkName the preWorkName to set
     */
    public void setPreWorkName(String preWorkName) {
        this.preWorkName = preWorkName;
    }

    /**
     * @return the workId
     */
    public Integer getWorkId() {
        return workId;
    }

    /**
     * @param workId the workId to set
     */
    public void setWorkId(Integer workId) {
        this.workId = workId;
    }

    /**
     * @return the workName
     */
    public String getWorkName() {
        return workName;
    }

    /**
     * @param workName the workName to set
     */
    public void setWorkName(String workName) {
        this.workName = workName;
    }

    /**
     * @return the wbsCode
     */
    public String getWbsCode() {
        return wbsCode;
    }

    /**
     * @param wbsCode the wbsCode to set
     */
    public void setWbsCode(String wbsCode) {
        this.wbsCode = wbsCode;
    }

    /**
     * @return the schStartDate
     */
    public Date getSchStartDate() {
        return schStartDate;
    }

    /**
     * @param schStartDate the schStartDate to set
     */
    public void setSchStartDate(Date schStartDate) {
        this.schStartDate = schStartDate;
    }

    /**
     * @return the schEndDate
     */
    public Date getSchEndDate() {
        return schEndDate;
    }

    /**
     * @param schEndDate the schEndDate to set
     */
    public void setSchEndDate(Date schEndDate) {
        this.schEndDate = schEndDate;
    }

    /**
     * @return the actStartDate
     */
    public Date getActStartDate() {
        return actStartDate;
    }

    /**
     * @param actStartDate the actStartDate to set
     */
    public void setActStartDate(Date actStartDate) {
        this.actStartDate = actStartDate;
    }

    /**
     * @return the actEndDate
     */
    public Date getActEndDate() {
        return actEndDate;
    }

    /**
     * @param actEndDate the actEndDate to set
     */
    public void setActEndDate(Date actEndDate) {
        this.actEndDate = actEndDate;
    }

    /**
     * @return the schPercent
     */
    public Double getSchPercent() {
        return schPercent;
    }

    /**
     * @param schPercent the schPercent to set
     */
    public void setSchPercent(Double schPercent) {
        this.schPercent = schPercent;
    }

    /**
     * @return the actPercent
     */
    public Double getActPercent() {
        return actPercent;
    }

    /**
     * @param actPercent the actPercent to set
     */
    public void setActPercent(Double actPercent) {
        this.actPercent = actPercent;
    }

    /**
     * @return the takeName
     */
    public String getTakeName() {
        return takeName;
    }

    /**
     * @param takeName the takeName to set
     */
    public void setTakeName(String takeName) {
        this.takeName = takeName;
    }

    /**
     * @return the timeLimitSch
     */
    public Double getTimeLimitSch() {
        return timeLimitSch;
    }

    /**
     * @param timeLimitSch the timeLimitSch to set
     */
    public void setTimeLimitSch(Double timeLimitSch) {
        this.timeLimitSch = timeLimitSch;
    }

    /**
     * @return the timeLimitAct
     */
    public Double getTimeLimitAct() {
        return timeLimitAct;
    }

    /**
     * @param timeLimitAct the timeLimitAct to set
     */
    public void setTimeLimitAct(Double timeLimitAct) {
        this.timeLimitAct = timeLimitAct;
    }

    /**
     * @return the timeLimitUnits
     */
    public String getTimeLimitUnits() {
        return timeLimitUnits;
    }

    /**
     * @param timeLimitUnits the timeLimitUnits to set
     */
    public void setTimeLimitUnits(String timeLimitUnits) {
        this.timeLimitUnits = timeLimitUnits;
    }

    /**
     * @return the levelNum
     */
    public Integer getLevelNum() {
        return levelNum;
    }

    /**
     * @param levelNum the levelNum to set
     */
    public void setLevelNum(Integer levelNum) {
        this.levelNum = levelNum;
    }

    /**
     * @return the finished
     */
    public boolean isFinished() {
        return finished;
    }

    /**
     * @param finished the finished to set
     */
    public void setFinished(boolean finished) {
        this.finished = finished;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    /**
     * @return the editDate
     */
    public Date getEditDate() {
        return editDate;
    }

    /**
     * @param editDate the editDate to set
     */
    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }

    /**
     * @return the editName
     */
    public String getEditName() {
        return editName;
    }

    /**
     * @param editName the editName to set
     */
    public void setEditName(String editName) {
        this.editName = editName;
    }

    /**
     * @return the pin
     */
    public Double getPin() {
        return pin;
    }

    /**
     * @param pin the pin to set
     */
    public void setPin(Double pin) {
        this.pin = pin;
    }
}
