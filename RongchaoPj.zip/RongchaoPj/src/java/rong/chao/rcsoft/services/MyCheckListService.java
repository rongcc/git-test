/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.rcsoft.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.List;
import javax.sql.DataSource;
import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rong.chao.rcsoft.dto.MyCheckList;

/**
 *
 * @author ZhouRongChao
 */
public class MyCheckListService {

    /**
     *
     * @param ds
     * @return
     */
    public int getNextNo(DataSource ds) {
        int nextNo = 0;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            //取原表
            String sqlStr = "select max(order_no) from my_check_list";
            pStmt = conn.prepareStatement(sqlStr);
            rs = pStmt.executeQuery();
            if (rs.next()) {
                nextNo = rs.getInt(1) + 1;
            } else {
                nextNo = 1;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return nextNo;
    }

    /**
     *
     * @param ds
     * @param codeType
     * @param code
     * @return
     */
    public MyCheckList fetch(DataSource ds, int codeType, int code) {
        MyCheckList cd = null;
        try {
            Dao dao = new NutDao(ds);
            cd = dao.fetchx(MyCheckList.class, codeType, code);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cd;
    }

    /**
     *
     * @param ds
     * @param cd
     * @return
     */
    public int delete(DataSource ds, MyCheckList cd) {
        int di = 0;
        try {
            Dao dao = new NutDao(ds);
            di = dao.deletex(MyCheckList.class, cd.getOrderNo(), cd.getItemNo());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return di;
    }

    /**
     *
     * @param ds
     * @param orderNo
     * @return
     */
    public List findItemList(DataSource ds, int orderNo) {
        List al = null;
        try {
            Dao dao = new NutDao(ds);
            al = dao.query(MyCheckList.class, Cnd.where("order_no", "=", orderNo).asc("item_no"), null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return al;
    }
}
