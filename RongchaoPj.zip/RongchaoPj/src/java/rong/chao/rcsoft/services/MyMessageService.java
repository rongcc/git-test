/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.rcsoft.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import javax.sql.DataSource;

/**
 *
 * @author ZhouRongChao
 */
public class MyMessageService {

    /**
     * 获得用户的未读消息数量。
     * @param ds
     * @param urStr
     * @return
     */
    public int getMyMessageNum(DataSource ds, String urStr) {
        int mNum = 0;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            //取原表
            String sqlStr = "SELECT count(1) FROM my_message where to_name=? AND status=0 ";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, urStr);
            rs = pStmt.executeQuery();
            if (rs.next()) {
                mNum = rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return mNum;
    }
}
