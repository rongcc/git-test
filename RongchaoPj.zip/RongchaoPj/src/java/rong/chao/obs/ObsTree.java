/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.obs;

import org.zkoss.zk.ui.ext.AfterCompose;
import org.zkoss.zul.Include;
import org.zkoss.zul.Tree;
import org.zkoss.zul.Treeitem;

/**
 *
 * @author ZhouRongChao
 */
public class ObsTree extends Tree implements AfterCompose {

    public ObsTree() {
    }

    public void onSelect() {
    }

    public void afterCompose() {
    }
}
