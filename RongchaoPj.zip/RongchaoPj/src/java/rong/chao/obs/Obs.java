/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.obs;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.PK;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author ZhouRongChao
 */
@Table("obs")
@PK({"fatherId", "sonId"})
public class Obs {

    @Column("father_id")
    private int fatherId;
    @Column("father_name")
    private String fatherName;
    @Column("obs_type")
    private String obsType;
    @Column("son_id")
    private int sonId;
    @Column("son_name")
    private String sonName;
    @Column("status")
    private int status;
    @Column("pin_type")
    private String pinType;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;
    @Column("project_no")
    private int projectNo;

    /**
     * @return the fatherId
     */
    public int getFatherId() {
        return fatherId;
    }

    /**
     * @param fatherId the fatherId to set
     */
    public void setFatherId(int fatherId) {
        this.fatherId = fatherId;
    }

    /**
     * @return the fatherName
     */
    public String getFatherName() {
        return fatherName;
    }

    /**
     * @param fatherName the fatherName to set
     */
    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }

    /**
     * @return the obsType
     */
    public String getObsType() {
        return obsType;
    }

    /**
     * @param obsType the obsType to set
     */
    public void setObsType(String obsType) {
        this.obsType = obsType;
    }

    /**
     * @return the sonId
     */
    public int getSonId() {
        return sonId;
    }

    /**
     * @param sonId the sonId to set
     */
    public void setSonId(int sonId) {
        this.sonId = sonId;
    }

    /**
     * @return the sonName
     */
    public String getSonName() {
        return sonName;
    }

    /**
     * @param sonName the sonName to set
     */
    public void setSonName(String sonName) {
        this.sonName = sonName;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the pinType
     */
    public String getPinType() {
        return pinType;
    }

    /**
     * @param pinType the pinType to set
     */
    public void setPinType(String pinType) {
        this.pinType = pinType;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    /**
     * @return the projectNo
     */
    public int getProjectNo() {
        return projectNo;
    }

    /**
     * @param projectNo the projectNo to set
     */
    public void setProjectNo(int projectNo) {
        this.projectNo = projectNo;
    }
}
