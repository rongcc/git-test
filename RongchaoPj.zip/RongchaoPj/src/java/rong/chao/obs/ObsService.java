/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.obs;

import java.util.List;
import javax.sql.DataSource;
import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;

/**
 *
 * @author ZhouRongChao
 */
public class ObsService {

    /**
     * 获取
     * @param ds
     * @param fatherId
     * @param sonId
     * @return
     */
    public Obs fetch(DataSource ds, int fatherId, int sonId) {
        Obs cd = null;
        try {
            Dao dao = new NutDao(ds);
            cd = dao.fetchx(Obs.class, fatherId, sonId);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cd;
    }

    /**
     * 删除
     * @param ds
     * @param cd
     * @return
     */
    public int delete(DataSource ds, Obs cd) {
        int di = 0;
        try {
            Dao dao = new NutDao(ds);
            di = dao.deletex(Obs.class, cd.getFatherId(), cd.getSonId());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return di;
    }

    /**
     *
     * @param ds
     * @param fatherId
     * @param sonId
     * @return
     */
    public int deletex(DataSource ds, int fatherId, int sonId) {
        int di = 0;
        try {
            Dao dao = new NutDao(ds);
            di = dao.deletex(Obs.class, fatherId, sonId);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return di;
    }

    /**
     * 获得所有子节点。
     * @param ds
     * @param fatherId
     * @return
     */
    public List findSonList(DataSource ds, int fatherId) {
        List iList = null;
        try {
            Dao dao = new NutDao(ds);
            iList = dao.query(Obs.class, Cnd.where("father_id", "=", fatherId), null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return iList;
    }
}
