/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.acct.services;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Calendar;
import java.util.List;
import javax.sql.DataSource;
import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.nutz.dao.Sqls;
import org.nutz.dao.impl.NutDao;
import org.nutz.dao.sql.Sql;
import rong.chao.acct.dto.Pingzh;
import rong.chao.acct.dto.PingzhItem;

/**
 *
 * @author zhourongchao
 */
public class PingzhService {

    public PingzhItem fetchPingzhItem(DataSource ds, String codeType, String code) {
        PingzhItem cd = null;
        try {
            Dao dao = new NutDao(ds);
            cd = dao.fetchx(PingzhItem.class, codeType, code);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cd;
    }

    public int deletePingzhItem(DataSource ds, PingzhItem cd) {
        int di = 0;
        try {
            Dao dao = new NutDao(ds);
            dao.deletex(PingzhItem.class, cd.getPingzhNo(), cd.getItemNo());
            di = 1;
        } catch (Exception e) {
            di = -3;
            e.printStackTrace();
        }
        return di;
    }

    public String create(DataSource ds, Pingzh order) {
        //
        if (order == null) {
            return null;
        }
        if (order.getPingzhNo() == null || order.getPingzhNo().equals("") || order.getItemList().size() < 1) {
            return "-1";
        }
        //
        String orderNo = "";
        try {
            Dao dao = new NutDao(ds);
            Pingzh po = dao.insert(order);
            orderNo = po.getPingzhNo();
            List itemList = po.getItemList();
            for (int i = 0; i < itemList.size(); i++) {
                PingzhItem item = (PingzhItem) itemList.get(i);
                dao.insert(item);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return orderNo;
    }

    public String edit(DataSource ds, Pingzh order) {
        //
        if (order == null) {
            return null;
        }
        if (order.getPingzhNo() == null || order.getPingzhNo().equals("") || order.getItemList().size() < 1) {
            return "-1";
        }
        //
        String orderNo = "";
        try {
            Dao dao = new NutDao(ds);
            //更新主体
            int upi = dao.update(order);
            //清除条目
            Sql sql = Sqls.create("delete from pingzh_item where pingzh_no=@pingzh_no");
            sql.params().set("pingzh_no", order.getPingzhNo());
            dao.execute(sql);
            //重新插入条目
            List itemList = order.getItemList();
            for (int i = 0; i < itemList.size(); i++) {
                PingzhItem pItem = (PingzhItem) itemList.get(i);
                dao.insert(pItem);
            }
            //更新主体成功即返回编码
            if (upi == 1) {
                orderNo = order.getPingzhNo();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return orderNo;
    }

    public int destroy(DataSource ds, Pingzh order) {
        //
        if (order == null) {
            return -2;
        }
        if (order.getPingzhNo() == null || order.getPingzhNo().equals("")) {
            return -1;
        }
        //
        int dt = 0;
        try {
            Dao dao = new NutDao(ds);
            Sql sql = Sqls.create("update pingzh set status = '-1' where pingzh_no=@pingzh_no");
            sql.params().set("pingzh_no", order.getPingzhNo());
            dao.execute(sql);
            dt = 1;
        } catch (Exception e) {
            dt = -3;
            e.printStackTrace();
        }
        return dt;
    }

    /**
     * 删除凭证包括各明细条目，效果同delete()方法。
     * @param ds
     * @param order
     * @return
     */
    public int deletePingzh(DataSource ds, Pingzh order) {
        //
        if (order == null) {
            return -2;
        }
        if (order.getPingzhNo() == null || order.getPingzhNo().equals("")) {
            return -1;
        }
        //
        int dt = 0;
        try {
            Dao dao = new NutDao(ds);
            List itemList = order.getItemList();
            for (int i = 0; i < itemList.size(); i++) {
                PingzhItem item = (PingzhItem) itemList.get(i);
                this.deletePingzhItem(ds, item);
            }
            dao.delete(order);
            dt = 1;
        } catch (Exception e) {
            dt = -3;
            e.printStackTrace();
        }
        return dt;
    }

    /**
     * 删除凭证包括各明细条目
     * @param ds
     * @param orderNo
     * @return
     */
    public int delete(DataSource ds, String orderNo) {
        //
        if (orderNo == null || orderNo.equals("")) {
            return -1;
        }
        //
        int dt = 0;
        try {
            Dao dao = new NutDao(ds);
            dao.delete(Pingzh.class, orderNo);
            Sql sql = Sqls.create("delete from pingzh where pingzh_no=@pingzh_no");
            sql.params().set("pingzh_no", orderNo);
            dao.execute(sql);
            sql = Sqls.create("delete from pingzh_item where pingzh_no=@pingzh_no");
            sql.params().set("pingzh_no", orderNo);
            dao.execute(sql);
            dt = 1;
        } catch (Exception e) {
            dt = -3;
            e.printStackTrace();
        }
        return dt;
    }

    public List findItemList(DataSource ds, String orderNo) {
        List al = null;
        try {
            Dao dao = new NutDao(ds);
            al = dao.query(PingzhItem.class, Cnd.where("pingzh_no", "=", orderNo).asc("item_no"), null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return al;
    }

    public Pingzh findOrder(DataSource ds, String orderNo) {
        Pingzh order = null;
        try {
            Dao dao = new NutDao(ds);
            order = dao.fetch(Pingzh.class, orderNo);
            order.setItemList(this.findItemList(ds, order.getPingzhNo()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return order;
    }

    public List findAll(DataSource ds) {
        List al = null;
        try {
            Dao dao = new NutDao(ds);
            al = dao.query(Pingzh.class, null, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return al;
    }

    /**
     * get the next order no.
     */
    public String getNextNo(DataSource ds) {
        String nextNo = "";
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            StringBuffer sb = new StringBuffer();
            Calendar rightNow = Calendar.getInstance();
            int y = rightNow.get(Calendar.YEAR);
            conn = ds.getConnection();
            //先取原表
            String sqlStr = "select max(pingzh_no) from pingzh";
            pStmt = conn.prepareStatement(sqlStr);
            rs = pStmt.executeQuery();
            String no = null;
            if (rs.next()) {
                no = rs.getString(1);
            }
            //取原表为空再去历史表
            if (no == null || no.equals("")) {
                sqlStr = "select max(pingzh_no) from pingzh_history";
                pStmt = conn.prepareStatement(sqlStr);
                ResultSet rsh = pStmt.executeQuery();
                if (rsh.next()) {
                    no = rsh.getString(1);
                }
            }
            //根据查询结果运算
            if (no != null && no.length() > 4) {
                int lastYear = 2000 + Integer.parseInt(no.substring(2, 4));
                if (y > lastYear) {
                    nextNo = sb.append("PZ").append(String.valueOf(y).substring(2)).append("000001").toString();
                } else {
                    int ino = Integer.parseInt(no.substring(4));
                    nextNo = sb.append("PZ").append(String.valueOf(y).substring(2)).append(String.valueOf(1000001 + ino).substring(1)).toString();
                }
            } else {
                nextNo = sb.append("PZ").append(String.valueOf(y).substring(2)).append("000001").toString();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return nextNo;
    }

    /**
     * 凭证检查，未制作完成，尚未使用。
     * @param ds
     * @return
     */
    public int check(DataSource ds) {
        int yi = 0;
        Connection conn = null;
        PreparedStatement pStmt = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            //打开分录表，要未过账且为审核过的凭证的分录
            String sqlStr = "select * from pingzh_item where pingzh_no in(select pingzh_no from pingzh where pz_status=1 and gz_status<>1)";
            pStmt = conn.prepareStatement(sqlStr);
            ResultSet rs2 = pStmt.executeQuery();
            //打开凭证表，要未过账且为审核过的凭证
            sqlStr = "select * from pingzh where pz_status=1 and gz_status<>1";
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs3 = stmt.executeQuery(sqlStr);
            System.out.println("-逐个凭证的-");
            //逐个凭证的
            rs3.beforeFirst();
            System.out.println("过账成功");
            yi = 1;
        } catch (Exception e) {
            System.out.println("过账失败");
            yi = -1;
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return yi;
    }

    /**
     * 凭证过账
     * @param ds
     * @return
     */
    public int post2(DataSource ds) {
        int yi = 0;
        Connection conn = null;
        PreparedStatement pStmt = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            Calendar rightNow = Calendar.getInstance();
            int nowMonth = rightNow.MONTH + 1;
            conn = ds.getConnection();
            //打开账簿初始化表
            String sqlStr = "select * from kemu_start";
            pStmt = conn.prepareStatement(sqlStr);
            ResultSet rs0 = pStmt.executeQuery();
            //打开本期汇总账簿表
            sqlStr = "select * from kemu_zong";
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs1 = stmt.executeQuery(sqlStr);
            //打开分录表，要未过账且为审核过的凭证的分录
            sqlStr = "select * from pingzh_item where pingzh_no in(select pingzh_no from pingzh where pz_status=1 and gz_status<>1)";
            pStmt = conn.prepareStatement(sqlStr);
            ResultSet rs2 = pStmt.executeQuery();
            //打开凭证表，要未过账且为审核过的凭证
            sqlStr = "select * from pingzh where pz_status=1 and gz_status<>1";
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs3 = stmt.executeQuery(sqlStr);
            //打开系统参数表
            sqlStr = "select * from code_data where code_type='my_code' and code='qijian'";
            pStmt = conn.prepareStatement(sqlStr);
            ResultSet rs4 = pStmt.executeQuery();
            //取得系统参数-会计期间
            int myCodeQijian = nowMonth;
            if (rs4.next()) {
                myCodeQijian = Integer.parseInt(rs4.getString("description"));
            }
            //进行凭证过账，并把计算结果保存于‘本期汇总账簿表’kemu_zong中
            System.out.println("-逐个凭证的-");
            //逐个凭证的
            while (rs3.next()) {
                System.out.println("--逐个本期汇总账簿表科目的-");
                //逐个本期汇总账簿表科目的
                while (rs1.next()) {
                    System.out.println("---逐个分录的-");
                    //逐个分录的
                    while (rs2.next()) {
                        if (rs3.getString("pingzh_no").equals(rs2.getString("pingzh_no")) && rs1.getString("kemu_id").equals(rs2.getString("kemu_id"))) {
                            System.out.println("--在此执行--");
                            rs1.updateBigDecimal("bq_debit_heji", rs1.getBigDecimal("bq_debit_heji").add(rs2.getBigDecimal("debit")));
                            rs1.updateBigDecimal("bq_credit_heji", rs1.getBigDecimal("bq_credit_heji").add(rs2.getBigDecimal("credit")));
                            //为后面的应用提前更新一下底层字段值
                            rs1.updateRow();
                            rs1.updateBigDecimal("year_debit_leiji", rs1.getBigDecimal("bq_debit_heji"));
                            rs1.updateBigDecimal("year_credit_leiji", rs1.getBigDecimal("bq_credit_heji"));
                            if (rs1.getString("yue_fxiang").equals("借方")) {
                                rs1.updateBigDecimal("yue", rs1.getBigDecimal("yue").add(rs2.getBigDecimal("debit").subtract(rs2.getBigDecimal("credit"))));
                            } else {
                                rs1.updateBigDecimal("yue", rs1.getBigDecimal("yue").add(rs2.getBigDecimal("credit").subtract(rs2.getBigDecimal("debit"))));
                            }
                        } else {
                            System.out.println("--无执行--");
                        }
                    }
                    rs2.beforeFirst();
                    rs1.updateInt("qijian", myCodeQijian);
                    rs1.updateRow();
                }
                rs1.beforeFirst();
                rs3.updateInt("gz_status", 1);
                rs3.updateInt("status", 2);
                rs3.updateRow();
            }
            rs3.beforeFirst();
            System.out.println("过账成功");
            yi = 1;
        } catch (Exception e) {
            System.out.println("过账失败");
            yi = -1;
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return yi;
    }

    /**
     * 期末结账
     * @param ds
     * @return
     */
    public int post3(DataSource ds) {
        int yi = 0;
        Connection conn = null;
        PreparedStatement pStmt = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            Calendar rightNow = Calendar.getInstance();
            int nowMonth = rightNow.MONTH + 1;
            conn = ds.getConnection();
            String sqlStr = "";
            //打开本期汇总账簿表
            sqlStr = "select * from kemu_zong";
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs1 = stmt.executeQuery(sqlStr);
            //打开系统参数表
            sqlStr = "select * from code_data where code_type='my_code' and code='qijian'";
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs4 = stmt.executeQuery(sqlStr);
            //进行期末结账处理
            while (rs1.next()) {
                //打开科目余额表kemu_yue
                sqlStr = "select * from kemu_yue where kemu_id='" + rs1.getString("kemu_id") + "'";
                stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
                ResultSet rs0 = stmt.executeQuery(sqlStr);
                //为科目余额表计算值
                if (rs0.next()) {
                    if (rs1.getString("yue_fxiang").equals("借方")) {
                        //期初借方余额
                        rs0.updateBigDecimal("start_debit_yue", rs1.getBigDecimal("yue"));
                    } else {
                        //期初贷方余额
                        rs0.updateBigDecimal("start_credit_yue", rs1.getBigDecimal("yue"));
                    }
                    rs0.updateBigDecimal("bq_debit_fs", rs1.getBigDecimal("bq_debit_heji"));
                    rs0.updateBigDecimal("bq_credit_fs", rs1.getBigDecimal("bq_credit_heji"));
                    rs0.updateRow();
                    rs0.updateBigDecimal("year_debit_fs", rs0.getBigDecimal("year_debit_fs").add(rs0.getBigDecimal("bq_debit_fs")));
                    rs0.updateBigDecimal("year_credit_fs", rs0.getBigDecimal("year_credit_fs").add(rs0.getBigDecimal("bq_credit_fs")));
                    //本期借方余额
                    rs0.updateBigDecimal("bq_debit_yue", rs0.getBigDecimal("start_debit_yue").add(rs0.getBigDecimal("bq_debit_fs")));
                    //本期贷方余额
                    rs0.updateBigDecimal("bq_credit_yue", rs0.getBigDecimal("start_credit_yue").add(rs0.getBigDecimal("bq_credit_fs")));
                    rs0.updateString("yue_fxiang", rs1.getString("yue_fxiang"));
                    rs0.updateInt("qijian", rs1.getInt("qijian"));
                    rs0.updateRow();
                }
                //更新本期汇总账簿表
                rs1.updateBigDecimal("start_yue", BigDecimal.ZERO);
                rs1.updateBigDecimal("bq_debit_heji", BigDecimal.ZERO);
                rs1.updateBigDecimal("bq_credit_heji", BigDecimal.ZERO);
                rs1.updateBigDecimal("year_debit_leiji", BigDecimal.ZERO);
                rs1.updateBigDecimal("year_credit_leiji", BigDecimal.ZERO);
                rs1.updateBigDecimal("yue", BigDecimal.ZERO);
                rs1.updateRow();
            }
            //更新会计期间
            if (rs4.next()) {
                //需要考虑第二年月份的变化
                int yuanQijian = Integer.parseInt(rs4.getString("description"));
                int xinQijian = yuanQijian + 1;
                //一年有12个会计期间的算法，第二年重回期间1
                //if(yuanQijian==12)
                // xinQijian=1;
                rs4.updateString("description", xinQijian + "");
                rs4.updateRow();
            }
            //将凭证及分录表的数据转移至hist历史表
            sqlStr = "insert into pingzh_item_history(select * from pingzh_item)";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.executeUpdate();
            sqlStr = "insert into pingzh_history(select * from pingzh)";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.executeUpdate();
            
            //删除凭证及分录表中的记录
            sqlStr = "delete from pingzh_item";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.executeUpdate();
            sqlStr = "delete from pingzh";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.executeUpdate();
            //以上为将凭证及分录表数据转移到历史表完成并删除原表数据
            System.out.println("期末结账成功");
            yi = 1;
        } catch (Exception e) {
            System.out.println("期末结账失败");
            yi = -1;
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return yi;
    }
}
