/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.acct.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Calendar;
import javax.sql.DataSource;

/**
 *
 * @author zhourongchao
 */
public class BalanceSheetService {

    public int fillBs(DataSource ds) {
        int yi = 0;
        Connection conn = null;
        PreparedStatement pStmt = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            Calendar rightNow = Calendar.getInstance();
            int nowMonth = rightNow.MONTH + 1;
            conn = ds.getConnection();
            //打开资产负债表
            String sqlStr = "select * from balance_sheet_ac";
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs0 = stmt.executeQuery(sqlStr);
            //打开科目余额表
            sqlStr = "select * from kemu_zong";
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs1 = stmt.executeQuery(sqlStr);
            //进行资产负债表计算
            System.out.println("-进行资产负债表计算-");
            while (rs1.next()) {
                //判断科目余额表中的会计期间是否等于用户输入的
                //如果是则执行
            }
            //把资产负债计算的结果添加于资产负债表中
            //
            System.out.println("填写资产负债表成功");
            yi = 1;
        } catch (Exception e) {
            System.out.println("填写资产负债表失败");
            yi = -1;
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return yi;
    }
}
