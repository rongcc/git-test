/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.acct.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;

/**
 *
 * @author zhourongchao
 */
public class KemuService {

    /**
     * 获得用于SQL集合格式的科目集合字符串
     * @param ds
     * @param seCo   如1101-1109,1209这样的格式，即连接线做范围逗号起隔开作用。
     * @return
     */
    public String getKemuList(DataSource ds, String seCo) {
        String kemuList = "";
        //把前后先插入逗号
        //找到每个-符号的位置
        //演绎出每个连接符的范围内科目（通过逗号与连接围出前后科目）并逗号连接
        //去掉前后逗号
        //完成
        StringBuilder kmSb = new StringBuilder();
        kmSb.append(",");
        if (seCo != null) {
            kmSb.append(seCo);
        }
        kmSb.append(",j");
        while (0 < kmSb.indexOf("-")) {
            int plc = kmSb.indexOf("-");
            System.out.println("plc-value-" + plc);
            int houd = 100;
            while (plc < kmSb.lastIndexOf(",")) {
                houd = kmSb.lastIndexOf(",");
                System.out.println("q-value-" + houd);
                kmSb.replace(houd, houd + 1, "#");
            }
            String endkm = kmSb.substring(plc + 1, houd);
            System.out.println("e-value-" + endkm);
            int qiand = 1;
            while (kmSb.indexOf(",") < plc && kmSb.indexOf(",") >= 0) {
                qiand = kmSb.indexOf(",");
                System.out.println("qiand-value-" + qiand);
                kmSb.replace(qiand, qiand + 1, "#");
            }
            String startkm = kmSb.substring(qiand + 1, plc);
            System.out.println("startkm-value-" + startkm);
            //演绎出每个连接符的范围内科目
            List clist = cutKemuList(ds, startkm, endkm);
            for (int i = 1; i < clist.size(); i++) {
                kmSb.insert(plc + 1, clist.get(i) + "#");
            }
            //
            kmSb.replace(plc, plc + 1, "#");
            while (0 <= kmSb.indexOf("#")) {
                kmSb.replace(kmSb.indexOf("#"), kmSb.indexOf("#") + 1, ",");
            }
        }
        kemuList = kmSb.substring(1, kmSb.length() - 2);
        return kemuList;
    }

    /**
     * 获得两个科目圈定的科目集合
     * @param ds
     * @param startKemu
     * @param endKemu
     * @return
     */
    public List cutKemuList(DataSource ds, String startKemu, String endKemu) {
        List al = new ArrayList();
        Connection conn = null;
        PreparedStatement pStmt = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            String sqlStr = "select kemu_id from kemu where kemu_id between ? and ?";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, startKemu);
            pStmt.setString(2, endKemu);
            rs = pStmt.executeQuery();
            while (rs.next()) {
                al.add(rs.getString(1));
            }
            System.out.println("成功");
        } catch (Exception e) {
            System.out.println("失败");
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return al;
    }
}
