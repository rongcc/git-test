/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.acct.services;

import java.util.List;
import javax.sql.DataSource;
import org.nutz.dao.Dao;
import org.nutz.dao.Sqls;
import org.nutz.dao.impl.NutDao;
import org.nutz.dao.sql.Sql;
import rong.chao.acct.dto.KemuStart;

/**
 *
 * @author zhourongchao
 */
public class KemuStartService {

    /**
     * 创建新账簿
     * @param ds
     * @return
     */
    public int createZhangbu(DataSource ds) {
        int yi = 0;
        try {
            Dao dao = new NutDao(ds);
            //清空表重新导入科目
            Sql sql = Sqls.create("delete FROM kemu_start");
            dao.execute(sql);
            sql = Sqls.create("insert into kemu_start(kemu_id,kemu_name,yue_fxiang) SELECT kemu_id,kemu_name,yue_fxiang FROM kemu");
            dao.execute(sql);
            //清空汇总表重新导入科目
            sql = Sqls.create("delete FROM kemu_zong");
            dao.execute(sql);
            sql = Sqls.create("insert into kemu_zong(kemu_id,kemu_name,yue_fxiang) SELECT kemu_id,kemu_name,yue_fxiang FROM kemu;");
            dao.execute(sql);
            //清空试算平衡表重新导入科目
            sql = Sqls.create("delete FROM kemu_balance");
            dao.execute(sql);
            sql = Sqls.create("insert into kemu_balance(kemu_id,kemu_name) SELECT kemu_id,kemu_name FROM kemu;");
            dao.execute(sql);
            //清空余额表重新导入科目
            sql = Sqls.create("delete FROM kemu_yue");
            dao.execute(sql);
            sql = Sqls.create("insert into kemu_yue(kemu_id,kemu_name,yue_fxiang) SELECT kemu_id,kemu_name,yue_fxiang FROM kemu;");
            dao.execute(sql);
            yi = 1;
        } catch (Exception e) {
            yi = -1;
            e.printStackTrace();
        }
        return yi;
    }

    /**
     * 启用账簿
     * @param ds
     * @param iList账户数据
     * @return
     */
    public int qiyongZhangbu(DataSource ds, List iList) {
        int yi = 0;
        try {
            Dao dao = new NutDao(ds);
            //在什么时机执行？
            //将填充的累计借方、累计贷方与期初余额保存
            for (int i = 0; i < iList.size(); i++) {
                KemuStart part = (KemuStart) iList.get(i);
                dao.update(part);
            }
            //isBalance判断是否平衡，否则终止执行，返回-10
            if (!this.isBalance(ds)) {
                return -10;
            }
            //‘删除’本期汇总账簿表-kemu_zong中的记录，即将数值设为0
            Sql sql = Sqls.create("update kemu_zong set start_yue=0,bq_debit_heji=0,bq_credit_heji=0,year_debit_leiji=0,year_credit_leiji=0,yue=0;");
            dao.execute(sql);

            //更新本期汇总账簿表-kemu_zong中的记录，设置期初余额与余额
            sql = Sqls.create("update kemu_start a,kemu_zong b set b.start_yue=a.start_yue,b.yue=a.start_yue where a.kemu_id=b.kemu_id;");
            dao.execute(sql);

            //删除试算平衡表-kemu_balance中的记录
            sql = Sqls.create("update kemu_balance set start_debit=0,start_credit=0,bq_debit_fs=0,bq_credit_fs=0,end_debit=0,end_credit=0;");
            dao.execute(sql);

            //删除分录表中的记录-pingzh_item

            //删除凭证表中的记录-pingzh

            //删除资产负债表中的记录-

            //删除科目余额表中的记录-kemu_yue
            sql = Sqls.create("update kemu_yue set start_debit_yue=0,start_credit_yue=0,bq_debit_fs=0,bq_credit_fs=0,year_debit_fs=0,year_credit_fs=0,bq_debit_yue=0,bq_credit_yue=0,end_jiesuan_fenlu=0;");
            dao.execute(sql);

            yi = 1;
        } catch (Exception e) {
            yi = -1;
            e.printStackTrace();
        }
        return yi;
    }

    /**
     * 试算平衡
     * @param ds
     * @return
     */
    public boolean isBalance(DataSource ds) {
        boolean yiboo = false;
        try {
            //删除试算平衡表中的记录
            //对应于账簿初始化表-kemu_start计算试算平衡表-kemu_balance的各个记录的值，并合并
            //求和，期初借方合计，期初贷方合计，本期发生借方合计，本期发生贷方合计，期末借方合计，期末贷方合计
            //判断是否平衡
        } catch (Exception e) {
            yiboo = false;
            e.printStackTrace();
        }
        return yiboo;
    }
}
