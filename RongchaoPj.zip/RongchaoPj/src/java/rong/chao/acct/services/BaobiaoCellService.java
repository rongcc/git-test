/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.acct.services;

import java.util.List;
import javax.sql.DataSource;
import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rong.chao.acct.dto.Baobiao;
import rong.chao.acct.dto.BaobiaoCell;

/**
 *
 * @author zhourongchao
 */
public class BaobiaoCellService {

    public BaobiaoCell fetch(DataSource ds, int baobiaoId, int lieNum, int rowNum) {
        BaobiaoCell cd = null;
        try {
            Dao dao = new NutDao(ds);
            cd = dao.fetchx(BaobiaoCell.class, baobiaoId, lieNum, rowNum);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cd;
    }

    public int delete(DataSource ds, BaobiaoCell cd) {
        int di = 0;
        try {
            Dao dao = new NutDao(ds);
            di = dao.deletex(BaobiaoCell.class, cd.getBaobiaoId(), cd.getLieNum(), cd.getRowNum());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return di;
    }

    /**
     * 生产出报表的各个格子
     * @param ds
     * @param cde
     */
    public void produceCell(DataSource ds, Baobiao cde) {
        Dao dao = new NutDao(ds);
        dao.clear(BaobiaoCell.class, Cnd.where("baobiao_id", "=", cde.getBaobiaoId()));
        int h = cde.getLieNumSum();
        int v = cde.getRowNumSum();
        for (int j = 1; j <= v; j++) {
            for (int i = 1; i <= h; i++) {
                BaobiaoCell bbcell = new BaobiaoCell();
                bbcell.setBaobiaoId(cde.getBaobiaoId());
                bbcell.setLieNum(i);
                bbcell.setRowNum(j);
                dao.insert(bbcell);
            }
        }
    }
}
