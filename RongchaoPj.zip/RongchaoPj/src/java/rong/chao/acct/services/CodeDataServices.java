/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.acct.services;

import javax.sql.DataSource;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rong.chao.acct.dto.CodeData;

/**
 *
 * @author zhourongchao
 */
public class CodeDataServices {

    public CodeData fetch(DataSource ds, String codeType, String code) {
        CodeData cd = null;
        try {
            Dao dao = new NutDao(ds);
            cd = dao.fetchx(CodeData.class, codeType, code);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cd;
    }

    public int delete(DataSource ds, CodeData cd) {
        int di = 0;
        try {
            Dao dao = new NutDao(ds);
            di = dao.deletex(CodeData.class, cd.getCodeType(), cd.getCode());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return di;
    }
}
