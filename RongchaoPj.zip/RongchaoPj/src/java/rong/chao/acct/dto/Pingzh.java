/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.acct.dto;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Name;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("pingzh")
public class Pingzh {

    @Column("pingzh_no")
    @Name
    private String pingzhNo;
    @Column("serial_num")
    private Integer serialNum;
    @Column("qijian")
    private Integer qijian;
    @Column("p_zihao")
    private String pZihao;
    @Column("p_date")
    private Date pDate;
    @Column("fudanju")
    private Integer fudanju;
    @Column("zhidan_name")
    private String zhidanName;
    @Column("debit_heji")
    private BigDecimal debitHeji;
    @Column("credit_heji")
    private BigDecimal creditHeji;
    @Column("gz_status")
    private Integer gzStatus;
    @Column("pz_status")
    private Integer pzStatus;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;
    @Column("post_date")
    private Date postDate;
    @Column("post_name")
    private String postName;
    @Column("status")
    private Integer status;
    @Column("remark")
    private String remark;
    @Column("status1")
    private String status1;
    @Column("status2")
    private String status2;
    @Column("pingzh_zi")
    private String pingzhZi;
    @Column("pingzh_hao")
    private Integer pingzhHao;

    private List itemList;

    public Pingzh() {
    }

    public Pingzh(String pingzhNo) {
        this.pingzhNo = pingzhNo;
    }

    public Pingzh(String pingzhNo, String zhidanName) {
        this.pingzhNo = pingzhNo;
        this.zhidanName = zhidanName;
    }

    public String getPingzhNo() {
        return pingzhNo;
    }

    public void setPingzhNo(String pingzhNo) {
        this.pingzhNo = pingzhNo;
    }

    public Integer getSerialNum() {
        return serialNum;
    }

    public void setSerialNum(Integer serialNum) {
        this.serialNum = serialNum;
    }

    public Integer getQijian() {
        return qijian;
    }

    public void setQijian(Integer qijian) {
        this.qijian = qijian;
    }

    public String getPZihao() {
        return pZihao;
    }

    public void setPZihao(String pZihao) {
        this.pZihao = pZihao;
    }

    public Date getPDate() {
        return pDate;
    }

    public void setPDate(Date pDate) {
        this.pDate = pDate;
    }

    public Integer getFudanju() {
        return fudanju;
    }

    public void setFudanju(Integer fudanju) {
        this.fudanju = fudanju;
    }

    public String getZhidanName() {
        return zhidanName;
    }

    public void setZhidanName(String zhidanName) {
        this.zhidanName = zhidanName;
    }

    public BigDecimal getDebitHeji() {
        return debitHeji;
    }

    public void setDebitHeji(BigDecimal debitHeji) {
        this.debitHeji = debitHeji;
    }

    public BigDecimal getCreditHeji() {
        return creditHeji;
    }

    public void setCreditHeji(BigDecimal creditHeji) {
        this.creditHeji = creditHeji;
    }

    public Integer getGzStatus() {
        return gzStatus;
    }

    public void setGzStatus(Integer gzStatus) {
        this.gzStatus = gzStatus;
    }

    public Integer getPzStatus() {
        return pzStatus;
    }

    public void setPzStatus(Integer pzStatus) {
        this.pzStatus = pzStatus;
    }

    public Date getInputDate() {
        return inputDate;
    }

    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    public String getInputName() {
        return inputName;
    }

    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    public Date getPostDate() {
        return postDate;
    }

    public void setPostDate(Date postDate) {
        this.postDate = postDate;
    }

    public String getPostName() {
        return postName;
    }

    public void setPostName(String postName) {
        this.postName = postName;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getStatus1() {
        return status1;
    }

    public void setStatus1(String status1) {
        this.status1 = status1;
    }

    public String getStatus2() {
        return status2;
    }

    public void setStatus2(String status2) {
        this.status2 = status2;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (pingzhNo != null ? pingzhNo.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Pingzh)) {
            return false;
        }
        Pingzh other = (Pingzh) object;
        if ((this.pingzhNo == null && other.pingzhNo != null) || (this.pingzhNo != null && !this.pingzhNo.equals(other.pingzhNo))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "rong.chao.acct.dto.Pingzh[pingzhNo=" + pingzhNo + "]";
    }

    /**
     * @return the itemList
     */
    public List getItemList() {
        return itemList;
    }

    /**
     * @param itemList the itemList to set
     */
    public void setItemList(List itemList) {
        this.itemList = itemList;
    }

    /**
     * @return the pingzhZi
     */
    public String getPingzhZi() {
        return pingzhZi;
    }

    /**
     * @param pingzhZi the pingzhZi to set
     */
    public void setPingzhZi(String pingzhZi) {
        this.pingzhZi = pingzhZi;
    }

    /**
     * @return the pingzhHao
     */
    public Integer getPingzhHao() {
        return pingzhHao;
    }

    /**
     * @param pingzhHao the pingzhHao to set
     */
    public void setPingzhHao(Integer pingzhHao) {
        this.pingzhHao = pingzhHao;
    }
}
