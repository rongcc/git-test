/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.acct.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("baobiao_ex")
public class BaobiaoEx {

    @Column("baobiao_id")
    @Id
    private Integer baobiaoId;
    @Column("attribute1")
    private String attribute1;
    @Column("attribute2")
    private String attribute2;
    @Column("attribute3")
    private String attribute3;
    @Column("attribute4")
    private String attribute4;
    @Column("attribute5")
    private String attribute5;
    @Column("attribute6")
    private String attribute6;
    @Column("attribute7")
    private String attribute7;
    @Column("attribute8")
    private String attribute8;
    @Column("attribute9")
    private String attribute9;
    @Column("attribute10")
    private String attribute10;
    @Column("attribute11")
    private String attribute11;
    @Column("attribute12")
    private String attribute12;
    @Column("attribute13")
    private String attribute13;
    @Column("attribute14")
    private String attribute14;
    @Column("attribute15")
    private String attribute15;
    @Column("attribute16")
    private String attribute16;
    @Column("attribute17")
    private String attribute17;
    @Column("attribute18")
    private String attribute18;
    @Column("attribute19")
    private String attribute19;
    @Column("attribute20")
    private String attribute20;
    @Column("status")
    private Integer status;
    @Column("remark")
    private String remark;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;
    @Column("edit_date")
    private Date editDate;
    @Column("edit_name")
    private String editName;
    @Column("post_date")
    private Date postDate;
    @Column("post_name")
    private String postName;

    /**
     * @return the babiaoId
     */
    public Integer getBaobiaoId() {
        return baobiaoId;
    }

    /**
     * @param babiaoId the babiaoId to set
     */
    public void setBaobiaoId(Integer baobiaoId) {
        this.baobiaoId = baobiaoId;
    }

    /**
     * @return the attribute1
     */
    public String getAttribute1() {
        return attribute1;
    }

    /**
     * @param attribute1 the attribute1 to set
     */
    public void setAttribute1(String attribute1) {
        this.attribute1 = attribute1;
    }

    /**
     * @return the attribute2
     */
    public String getAttribute2() {
        return attribute2;
    }

    /**
     * @param attribute2 the attribute2 to set
     */
    public void setAttribute2(String attribute2) {
        this.attribute2 = attribute2;
    }

    /**
     * @return the attribute3
     */
    public String getAttribute3() {
        return attribute3;
    }

    /**
     * @param attribute3 the attribute3 to set
     */
    public void setAttribute3(String attribute3) {
        this.attribute3 = attribute3;
    }

    /**
     * @return the attribute4
     */
    public String getAttribute4() {
        return attribute4;
    }

    /**
     * @param attribute4 the attribute4 to set
     */
    public void setAttribute4(String attribute4) {
        this.attribute4 = attribute4;
    }

    /**
     * @return the attribute5
     */
    public String getAttribute5() {
        return attribute5;
    }

    /**
     * @param attribute5 the attribute5 to set
     */
    public void setAttribute5(String attribute5) {
        this.attribute5 = attribute5;
    }

    /**
     * @return the attribute6
     */
    public String getAttribute6() {
        return attribute6;
    }

    /**
     * @param attribute6 the attribute6 to set
     */
    public void setAttribute6(String attribute6) {
        this.attribute6 = attribute6;
    }

    /**
     * @return the attribute7
     */
    public String getAttribute7() {
        return attribute7;
    }

    /**
     * @param attribute7 the attribute7 to set
     */
    public void setAttribute7(String attribute7) {
        this.attribute7 = attribute7;
    }

    /**
     * @return the attribute8
     */
    public String getAttribute8() {
        return attribute8;
    }

    /**
     * @param attribute8 the attribute8 to set
     */
    public void setAttribute8(String attribute8) {
        this.attribute8 = attribute8;
    }

    /**
     * @return the attribute9
     */
    public String getAttribute9() {
        return attribute9;
    }

    /**
     * @param attribute9 the attribute9 to set
     */
    public void setAttribute9(String attribute9) {
        this.attribute9 = attribute9;
    }

    /**
     * @return the attribute10
     */
    public String getAttribute10() {
        return attribute10;
    }

    /**
     * @param attribute10 the attribute10 to set
     */
    public void setAttribute10(String attribute10) {
        this.attribute10 = attribute10;
    }

    /**
     * @return the attribute11
     */
    public String getAttribute11() {
        return attribute11;
    }

    /**
     * @param attribute11 the attribute11 to set
     */
    public void setAttribute11(String attribute11) {
        this.attribute11 = attribute11;
    }

    /**
     * @return the attribute12
     */
    public String getAttribute12() {
        return attribute12;
    }

    /**
     * @param attribute12 the attribute12 to set
     */
    public void setAttribute12(String attribute12) {
        this.attribute12 = attribute12;
    }

    /**
     * @return the attribute13
     */
    public String getAttribute13() {
        return attribute13;
    }

    /**
     * @param attribute13 the attribute13 to set
     */
    public void setAttribute13(String attribute13) {
        this.attribute13 = attribute13;
    }

    /**
     * @return the attribute14
     */
    public String getAttribute14() {
        return attribute14;
    }

    /**
     * @param attribute14 the attribute14 to set
     */
    public void setAttribute14(String attribute14) {
        this.attribute14 = attribute14;
    }

    /**
     * @return the attribute15
     */
    public String getAttribute15() {
        return attribute15;
    }

    /**
     * @param attribute15 the attribute15 to set
     */
    public void setAttribute15(String attribute15) {
        this.attribute15 = attribute15;
    }

    /**
     * @return the attribute16
     */
    public String getAttribute16() {
        return attribute16;
    }

    /**
     * @param attribute16 the attribute16 to set
     */
    public void setAttribute16(String attribute16) {
        this.attribute16 = attribute16;
    }

    /**
     * @return the attribute17
     */
    public String getAttribute17() {
        return attribute17;
    }

    /**
     * @param attribute17 the attribute17 to set
     */
    public void setAttribute17(String attribute17) {
        this.attribute17 = attribute17;
    }

    /**
     * @return the attribute18
     */
    public String getAttribute18() {
        return attribute18;
    }

    /**
     * @param attribute18 the attribute18 to set
     */
    public void setAttribute18(String attribute18) {
        this.attribute18 = attribute18;
    }

    /**
     * @return the attribute19
     */
    public String getAttribute19() {
        return attribute19;
    }

    /**
     * @param attribute19 the attribute19 to set
     */
    public void setAttribute19(String attribute19) {
        this.attribute19 = attribute19;
    }

    /**
     * @return the attribute20
     */
    public String getAttribute20() {
        return attribute20;
    }

    /**
     * @param attribute20 the attribute20 to set
     */
    public void setAttribute20(String attribute20) {
        this.attribute20 = attribute20;
    }

    /**
     * @return the status
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * @return the remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * @param remark the remark to set
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    /**
     * @return the editDate
     */
    public Date getEditDate() {
        return editDate;
    }

    /**
     * @param editDate the editDate to set
     */
    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }

    /**
     * @return the editName
     */
    public String getEditName() {
        return editName;
    }

    /**
     * @param editName the editName to set
     */
    public void setEditName(String editName) {
        this.editName = editName;
    }

    /**
     * @return the postDate
     */
    public Date getPostDate() {
        return postDate;
    }

    /**
     * @param postDate the postDate to set
     */
    public void setPostDate(Date postDate) {
        this.postDate = postDate;
    }

    /**
     * @return the postName
     */
    public String getPostName() {
        return postName;
    }

    /**
     * @param postName the postName to set
     */
    public void setPostName(String postName) {
        this.postName = postName;
    }
}
