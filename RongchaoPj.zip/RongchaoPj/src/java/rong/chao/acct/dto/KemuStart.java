/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.acct.dto;

import java.math.BigDecimal;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Name;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("kemu_start")
public class KemuStart {

    @Column("kemu_id")
    @Name
    private String kemuId;
    @Column("kemu_name")
    private String kemuName;
    @Column("yue_fxiang")
    private String yueFxiang;
    @Column("leiji_debit")
    private BigDecimal leijiDebit;
    @Column("leiji_credit")
    private BigDecimal leijiCredit;
    @Column("start_yue")
    private BigDecimal startYue;

    public KemuStart() {
    }

    public KemuStart(String kemuId) {
        this.kemuId = kemuId;
    }

    public KemuStart(String kemuId, String kemuName) {
        this.kemuId = kemuId;
        this.kemuName = kemuName;
    }

    public String getKemuId() {
        return kemuId;
    }

    public void setKemuId(String kemuId) {
        this.kemuId = kemuId;
    }

    public String getKemuName() {
        return kemuName;
    }

    public void setKemuName(String kemuName) {
        this.kemuName = kemuName;
    }

    public String getYueFxiang() {
        return yueFxiang;
    }

    public void setYueFxiang(String yueFxiang) {
        this.yueFxiang = yueFxiang;
    }

    public BigDecimal getLeijiDebit() {
        return leijiDebit;
    }

    public void setLeijiDebit(BigDecimal leijiDebit) {
        this.leijiDebit = leijiDebit;
    }

    public BigDecimal getLeijiCredit() {
        return leijiCredit;
    }

    public void setLeijiCredit(BigDecimal leijiCredit) {
        this.leijiCredit = leijiCredit;
    }

    public BigDecimal getStartYue() {
        return startYue;
    }

    public void setStartYue(BigDecimal startYue) {
        this.startYue = startYue;
    }

}
