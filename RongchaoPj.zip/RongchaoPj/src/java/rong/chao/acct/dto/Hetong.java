/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.acct.dto;

import java.math.BigDecimal;
import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Name;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("hetong")
public class Hetong {

    @Column("hetong_no")
    @Name
    private String hetongNo;
    @Column("hetong_name")
    private String hetongName;
    @Column("hetong_type")
    private String hetongType;
    @Column("dengji_riqi")
    private Date dengjiRiqi;
    @Column("he_xiangmu")
    private String heXiangmu;
    @Column("xiangmu_didian")
    private String xiangmuDidian;
    @Column("duifang_name")
    private String duifangName;
    @Column("wofang_daibiao")
    private String wofangDaibiao;
    @Column("duifang_daibiao")
    private String duifangDaibiao;
    @Column("qiany_riqi")
    private Date qianyRiqi;
    @Column("qixian_start")
    private Date qixianStart;
    @Column("qixian_end")
    private Date qixianEnd;
    @Column("is_jieshu")
    private Boolean isJieshu;
    @Column("yusuan")
    private BigDecimal yusuan;
    @Column("jiesuan")
    private BigDecimal jiesuan;
    @Column("yajin")
    private BigDecimal yajin;
    @Column("hetong_zong")
    private BigDecimal hetongZong;
    @Column("hetong_yu")
    private BigDecimal hetongYu;
    @Column("jingbanren")
    private String jingbanren;
    @Column("qita")
    private String qita;
    @Column("content")
    private String content;
    @Column("beizhu")
    private String beizhu;
    @Column("zhidan")
    private String zhidan;
    @Column("shenhe")
    private String shenhe;
    @Column("status")
    private Integer status;
    @Column("remark")
    private String remark;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;
    @Column("edit_date")
    private Date editDate;
    @Column("edit_name")
    private String editName;
    @Column("post_date")
    private Date postDate;
    @Column("post_name")
    private String postName;

    /**
     * @return the hetongNo
     */
    public String getHetongNo() {
        return hetongNo;
    }

    /**
     * @param hetongNo the hetongNo to set
     */
    public void setHetongNo(String hetongNo) {
        this.hetongNo = hetongNo;
    }

    /**
     * @return the hetongName
     */
    public String getHetongName() {
        return hetongName;
    }

    /**
     * @param hetongName the hetongName to set
     */
    public void setHetongName(String hetongName) {
        this.hetongName = hetongName;
    }

    /**
     * @return the hetongType
     */
    public String getHetongType() {
        return hetongType;
    }

    /**
     * @param hetongType the hetongType to set
     */
    public void setHetongType(String hetongType) {
        this.hetongType = hetongType;
    }

    /**
     * @return the dengjiRiqi
     */
    public Date getDengjiRiqi() {
        return dengjiRiqi;
    }

    /**
     * @param dengjiRiqi the dengjiRiqi to set
     */
    public void setDengjiRiqi(Date dengjiRiqi) {
        this.dengjiRiqi = dengjiRiqi;
    }

    /**
     * @return the heXiangmu
     */
    public String getHeXiangmu() {
        return heXiangmu;
    }

    /**
     * @param heXiangmu the heXiangmu to set
     */
    public void setHeXiangmu(String heXiangmu) {
        this.heXiangmu = heXiangmu;
    }

    /**
     * @return the xiangmuDidian
     */
    public String getXiangmuDidian() {
        return xiangmuDidian;
    }

    /**
     * @param xiangmuDidian the xiangmuDidian to set
     */
    public void setXiangmuDidian(String xiangmuDidian) {
        this.xiangmuDidian = xiangmuDidian;
    }

    /**
     * @return the duifangName
     */
    public String getDuifangName() {
        return duifangName;
    }

    /**
     * @param duifangName the duifangName to set
     */
    public void setDuifangName(String duifangName) {
        this.duifangName = duifangName;
    }

    /**
     * @return the wofangDaibiao
     */
    public String getWofangDaibiao() {
        return wofangDaibiao;
    }

    /**
     * @param wofangDaibiao the wofangDaibiao to set
     */
    public void setWofangDaibiao(String wofangDaibiao) {
        this.wofangDaibiao = wofangDaibiao;
    }

    /**
     * @return the duifangDaibiao
     */
    public String getDuifangDaibiao() {
        return duifangDaibiao;
    }

    /**
     * @param duifangDaibiao the duifangDaibiao to set
     */
    public void setDuifangDaibiao(String duifangDaibiao) {
        this.duifangDaibiao = duifangDaibiao;
    }

    /**
     * @return the qianyRiqi
     */
    public Date getQianyRiqi() {
        return qianyRiqi;
    }

    /**
     * @param qianyRiqi the qianyRiqi to set
     */
    public void setQianyRiqi(Date qianyRiqi) {
        this.qianyRiqi = qianyRiqi;
    }

    /**
     * @return the qixianStart
     */
    public Date getQixianStart() {
        return qixianStart;
    }

    /**
     * @param qixianStart the qixianStart to set
     */
    public void setQixianStart(Date qixianStart) {
        this.qixianStart = qixianStart;
    }

    /**
     * @return the qixianEnd
     */
    public Date getQixianEnd() {
        return qixianEnd;
    }

    /**
     * @param qixianEnd the qixianEnd to set
     */
    public void setQixianEnd(Date qixianEnd) {
        this.qixianEnd = qixianEnd;
    }

    /**
     * @return the isJieshu
     */
    public Boolean getIsJieshu() {
        return isJieshu;
    }

    /**
     * @param isJieshu the isJieshu to set
     */
    public void setIsJieshu(Boolean isJieshu) {
        this.isJieshu = isJieshu;
    }

    /**
     * @return the yusuan
     */
    public BigDecimal getYusuan() {
        return yusuan;
    }

    /**
     * @param yusuan the yusuan to set
     */
    public void setYusuan(BigDecimal yusuan) {
        this.yusuan = yusuan;
    }

    /**
     * @return the jiesuan
     */
    public BigDecimal getJiesuan() {
        return jiesuan;
    }

    /**
     * @param jiesuan the jiesuan to set
     */
    public void setJiesuan(BigDecimal jiesuan) {
        this.jiesuan = jiesuan;
    }

    /**
     * @return the yajin
     */
    public BigDecimal getYajin() {
        return yajin;
    }

    /**
     * @param yajin the yajin to set
     */
    public void setYajin(BigDecimal yajin) {
        this.yajin = yajin;
    }

    /**
     * @return the hetongZong
     */
    public BigDecimal getHetongZong() {
        return hetongZong;
    }

    /**
     * @param hetongZong the hetongZong to set
     */
    public void setHetongZong(BigDecimal hetongZong) {
        this.hetongZong = hetongZong;
    }

    /**
     * @return the hetongYu
     */
    public BigDecimal getHetongYu() {
        return hetongYu;
    }

    /**
     * @param hetongYu the hetongYu to set
     */
    public void setHetongYu(BigDecimal hetongYu) {
        this.hetongYu = hetongYu;
    }

    /**
     * @return the jingbanren
     */
    public String getJingbanren() {
        return jingbanren;
    }

    /**
     * @param jingbanren the jingbanren to set
     */
    public void setJingbanren(String jingbanren) {
        this.jingbanren = jingbanren;
    }

    /**
     * @return the qita
     */
    public String getQita() {
        return qita;
    }

    /**
     * @param qita the qita to set
     */
    public void setQita(String qita) {
        this.qita = qita;
    }

    /**
     * @return the content
     */
    public String getContent() {
        return content;
    }

    /**
     * @param content the content to set
     */
    public void setContent(String content) {
        this.content = content;
    }

    /**
     * @return the beizhu
     */
    public String getBeizhu() {
        return beizhu;
    }

    /**
     * @param beizhu the beizhu to set
     */
    public void setBeizhu(String beizhu) {
        this.beizhu = beizhu;
    }

    /**
     * @return the zhidan
     */
    public String getZhidan() {
        return zhidan;
    }

    /**
     * @param zhidan the zhidan to set
     */
    public void setZhidan(String zhidan) {
        this.zhidan = zhidan;
    }

    /**
     * @return the shenhe
     */
    public String getShenhe() {
        return shenhe;
    }

    /**
     * @param shenhe the shenhe to set
     */
    public void setShenhe(String shenhe) {
        this.shenhe = shenhe;
    }

    /**
     * @return the status
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * @return the remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * @param remark the remark to set
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    /**
     * @return the editDate
     */
    public Date getEditDate() {
        return editDate;
    }

    /**
     * @param editDate the editDate to set
     */
    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }

    /**
     * @return the editName
     */
    public String getEditName() {
        return editName;
    }

    /**
     * @param editName the editName to set
     */
    public void setEditName(String editName) {
        this.editName = editName;
    }

    /**
     * @return the postDate
     */
    public Date getPostDate() {
        return postDate;
    }

    /**
     * @param postDate the postDate to set
     */
    public void setPostDate(Date postDate) {
        this.postDate = postDate;
    }

    /**
     * @return the postName
     */
    public String getPostName() {
        return postName;
    }

    /**
     * @param postName the postName to set
     */
    public void setPostName(String postName) {
        this.postName = postName;
    }
}
