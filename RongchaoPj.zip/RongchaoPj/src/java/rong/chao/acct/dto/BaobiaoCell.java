/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.acct.dto;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.PK;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("baobiao_cell")
@PK({"baobiaoId", "lieNum", "rowNum"})
public class BaobiaoCell {

    @Column("baobiao_id")
    private int baobiaoId;
    @Column("lie_num")
    private int lieNum;
    @Column("row_num")
    private int rowNum;
    @Column("cell_expressions")
    private String cellExpressions;
    @Column("cell_data")
    private String cellData;

    /**
     * @return the lieNum
     */
    public int getLieNum() {
        return lieNum;
    }

    /**
     * @param lieNum the lieNum to set
     */
    public void setLieNum(int lieNum) {
        this.lieNum = lieNum;
    }

    /**
     * @return the rowNum
     */
    public int getRowNum() {
        return rowNum;
    }

    /**
     * @param rowNum the rowNum to set
     */
    public void setRowNum(int rowNum) {
        this.rowNum = rowNum;
    }

    /**
     * @return the cellExpressions
     */
    public String getCellExpressions() {
        return cellExpressions;
    }

    /**
     * @param cellExpressions the cellExpressions to set
     */
    public void setCellExpressions(String cellExpressions) {
        this.cellExpressions = cellExpressions;
    }

    /**
     * @return the cellData
     */
    public String getCellData() {
        return cellData;
    }

    /**
     * @param cellData the cellData to set
     */
    public void setCellData(String cellData) {
        this.cellData = cellData;
    }

    /**
     * @return the baobiaoId
     */
    public int getBaobiaoId() {
        return baobiaoId;
    }

    /**
     * @param baobiaoId the baobiaoId to set
     */
    public void setBaobiaoId(int baobiaoId) {
        this.baobiaoId = baobiaoId;
    }
}
