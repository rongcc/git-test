/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.acct.dto;

import java.math.BigDecimal;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Name;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("kemu_yue")
public class KemuYue {

    @Column("kemu_id")
    @Name
    private String kemuId;
    @Column("kemu_name")
    private String kemuName;
    @Column("start_debit_yue")
    private BigDecimal startDebitYue;
    @Column("start_credit_yue")
    private BigDecimal startCreditYue;
    @Column("bq_debit_fs")
    private BigDecimal bqDebitFs;
    @Column("bq_credit_fs")
    private BigDecimal bqCreditFs;
    @Column("year_debit_fs")
    private BigDecimal yearDebitFs;
    @Column("year_credit_fs")
    private BigDecimal yearCreditFs;
    @Column("bq_debit_yue")
    private BigDecimal bqDebitYue;
    @Column("bq_credit_yue")
    private BigDecimal bqCreditYue;
    @Column("end_jiesuan_fenlu")
    private BigDecimal endJiesuanFenlu;
    @Column("qijian")
    private Integer qijian;
    @Column("yue_fxiang")
    private String yueFxiang;

    public KemuYue() {
    }

    public KemuYue(String kemuId) {
        this.kemuId = kemuId;
    }

    public String getKemuId() {
        return kemuId;
    }

    public void setKemuId(String kemuId) {
        this.kemuId = kemuId;
    }

    public String getKemuName() {
        return kemuName;
    }

    public void setKemuName(String kemuName) {
        this.kemuName = kemuName;
    }

    public BigDecimal getStartDebitYue() {
        return startDebitYue;
    }

    public void setStartDebitYue(BigDecimal startDebitYue) {
        this.startDebitYue = startDebitYue;
    }

    public BigDecimal getStartCreditYue() {
        return startCreditYue;
    }

    public void setStartCreditYue(BigDecimal startCreditYue) {
        this.startCreditYue = startCreditYue;
    }

    public BigDecimal getBqDebitFs() {
        return bqDebitFs;
    }

    public void setBqDebitFs(BigDecimal bqDebitFs) {
        this.bqDebitFs = bqDebitFs;
    }

    public BigDecimal getBqCreditFs() {
        return bqCreditFs;
    }

    public void setBqCreditFs(BigDecimal bqCreditFs) {
        this.bqCreditFs = bqCreditFs;
    }

    public BigDecimal getYearDebitFs() {
        return yearDebitFs;
    }

    public void setYearDebitFs(BigDecimal yearDebitFs) {
        this.yearDebitFs = yearDebitFs;
    }

    public BigDecimal getYearCreditFs() {
        return yearCreditFs;
    }

    public void setYearCreditFs(BigDecimal yearCreditFs) {
        this.yearCreditFs = yearCreditFs;
    }

    public BigDecimal getBqDebitYue() {
        return bqDebitYue;
    }

    public void setBqDebitYue(BigDecimal bqDebitYue) {
        this.bqDebitYue = bqDebitYue;
    }

    public BigDecimal getBqCreditYue() {
        return bqCreditYue;
    }

    public void setBqCreditYue(BigDecimal bqCreditYue) {
        this.bqCreditYue = bqCreditYue;
    }

    public BigDecimal getEndJiesuanFenlu() {
        return endJiesuanFenlu;
    }

    public void setEndJiesuanFenlu(BigDecimal endJiesuanFenlu) {
        this.endJiesuanFenlu = endJiesuanFenlu;
    }

    public Integer getQijian() {
        return qijian;
    }

    public void setQijian(Integer qijian) {
        this.qijian = qijian;
    }

    public String getYueFxiang() {
        return yueFxiang;
    }

    public void setYueFxiang(String yueFxiang) {
        this.yueFxiang = yueFxiang;
    }

}
