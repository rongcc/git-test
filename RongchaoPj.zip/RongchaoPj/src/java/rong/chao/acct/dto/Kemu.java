/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.acct.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Name;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("kemu")
public class Kemu {

    @Column("kemu_id")
    @Name
    private String kemuId;
    @Column("kemu_name")
    private String kemuName;
    @Column("help_code")
    private String helpCode;
    @Column("kemu_group")
    private String kemuGroup;
    @Column("is_inventory")
    private Boolean isInventory;
    @Column("yue_fxiang")
    private String yueFxiang;
    @Column("unit")
    private String unit;
    @Column("status")
    private int status;
    @Column("remark")
    private String remark;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;
    @Column("post_date")
    private Date postDate;
    @Column("post_name")
    private String postName;

    /**
     * @return the kemuId
     */
    public String getKemuId() {
        return kemuId;
    }

    /**
     * @param kemuId the kemuId to set
     */
    public void setKemuId(String kemuId) {
        this.kemuId = kemuId;
    }

    /**
     * @return the kemuName
     */
    public String getKemuName() {
        return kemuName;
    }

    /**
     * @param kemuName the kemuName to set
     */
    public void setKemuName(String kemuName) {
        this.kemuName = kemuName;
    }

    /**
     * @return the helpCode
     */
    public String getHelpCode() {
        return helpCode;
    }

    /**
     * @param helpCode the helpCode to set
     */
    public void setHelpCode(String helpCode) {
        this.helpCode = helpCode;
    }

    /**
     * @return the kemuGroup
     */
    public String getKemuGroup() {
        return kemuGroup;
    }

    /**
     * @param kemuGroup the kemuGroup to set
     */
    public void setKemuGroup(String kemuGroup) {
        this.kemuGroup = kemuGroup;
    }

    /**
     * @return the isInventory
     */
    public Boolean getIsInventory() {
        return isInventory;
    }

    /**
     * @param isInventory the isInventory to set
     */
    public void setIsInventory(Boolean isInventory) {
        this.isInventory = isInventory;
    }

    /**
     * @return the yueFxiang
     */
    public String getYueFxiang() {
        return yueFxiang;
    }

    /**
     * @param yueFxiang the yueFxiang to set
     */
    public void setYueFxiang(String yueFxiang) {
        this.yueFxiang = yueFxiang;
    }

    /**
     * @return the unit
     */
    public String getUnit() {
        return unit;
    }

    /**
     * @param unit the unit to set
     */
    public void setUnit(String unit) {
        this.unit = unit;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * @param remark the remark to set
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    /**
     * @return the postDate
     */
    public Date getPostDate() {
        return postDate;
    }

    /**
     * @param postDate the postDate to set
     */
    public void setPostDate(Date postDate) {
        this.postDate = postDate;
    }

    /**
     * @return the postName
     */
    public String getPostName() {
        return postName;
    }

    /**
     * @param postName the postName to set
     */
    public void setPostName(String postName) {
        this.postName = postName;
    }
}
