/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.acct.dto;

import java.math.BigDecimal;
import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.PK;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("hetong_duixian")
@PK({"hetongNo", "duixianItem"})
public class HetongDuixian {

    @Column("hetong_no")
    private String hetongNo;
    @Column("duixian_item")
    private int duixianItem;
    @Column("is_yajin")
    private Boolean isYajin;
    @Column("riqi")
    private Date riqi;
    @Column("zhaiyao")
    private String zhaiyao;
    @Column("pingzh_info")
    private String pingzhInfo;
    @Column("duifang_kemu")
    private String duifangKemu;
    @Column("shoukuan_jine")
    private BigDecimal shoukuanJine;
    @Column("fukuan_jine")
    private BigDecimal fukuanJine;
    @Column("status")
    private Integer status;
    @Column("remark")
    private String remark;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;
    @Column("edit_date")
    private Date editDate;
    @Column("edit_name")
    private String editName;

    /**
     * @return the hetongNo
     */
    public String getHetongNo() {
        return hetongNo;
    }

    /**
     * @param hetongNo the hetongNo to set
     */
    public void setHetongNo(String hetongNo) {
        this.hetongNo = hetongNo;
    }

    /**
     * @return the duixianItem
     */
    public int getDuixianItem() {
        return duixianItem;
    }

    /**
     * @param duixianItem the duixianItem to set
     */
    public void setDuixianItem(int duixianItem) {
        this.duixianItem = duixianItem;
    }

    /**
     * @return the isYajin
     */
    public Boolean getIsYajin() {
        return isYajin;
    }

    /**
     * @param isYajin the isYajin to set
     */
    public void setIsYajin(Boolean isYajin) {
        this.isYajin = isYajin;
    }

    /**
     * @return the riqi
     */
    public Date getRiqi() {
        return riqi;
    }

    /**
     * @param riqi the riqi to set
     */
    public void setRiqi(Date riqi) {
        this.riqi = riqi;
    }

    /**
     * @return the zhaiyao
     */
    public String getZhaiyao() {
        return zhaiyao;
    }

    /**
     * @param zhaiyao the zhaiyao to set
     */
    public void setZhaiyao(String zhaiyao) {
        this.zhaiyao = zhaiyao;
    }

    /**
     * @return the pingzhInfo
     */
    public String getPingzhInfo() {
        return pingzhInfo;
    }

    /**
     * @param pingzhInfo the pingzhInfo to set
     */
    public void setPingzhInfo(String pingzhInfo) {
        this.pingzhInfo = pingzhInfo;
    }

    /**
     * @return the duifangKemu
     */
    public String getDuifangKemu() {
        return duifangKemu;
    }

    /**
     * @param duifangKemu the duifangKemu to set
     */
    public void setDuifangKemu(String duifangKemu) {
        this.duifangKemu = duifangKemu;
    }

    /**
     * @return the shoukuanJine
     */
    public BigDecimal getShoukuanJine() {
        return shoukuanJine;
    }

    /**
     * @param shoukuanJine the shoukuanJine to set
     */
    public void setShoukuanJine(BigDecimal shoukuanJine) {
        this.shoukuanJine = shoukuanJine;
    }

    /**
     * @return the fukuanJine
     */
    public BigDecimal getFukuanJine() {
        return fukuanJine;
    }

    /**
     * @param fukuanJine the fukuanJine to set
     */
    public void setFukuanJine(BigDecimal fukuanJine) {
        this.fukuanJine = fukuanJine;
    }

    /**
     * @return the status
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * @return the remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * @param remark the remark to set
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    /**
     * @return the editDate
     */
    public Date getEditDate() {
        return editDate;
    }

    /**
     * @param editDate the editDate to set
     */
    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }

    /**
     * @return the editName
     */
    public String getEditName() {
        return editName;
    }

    /**
     * @param editName the editName to set
     */
    public void setEditName(String editName) {
        this.editName = editName;
    }
}
