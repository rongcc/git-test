/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.acct.dto;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("baobiao")
public class Baobiao {

    @Column("baobiao_id")
    @Id
    private Integer baobiaoId;
    @Column("is_mold")
    private boolean isMold;
    @Column("name")
    private String name;
    @Column("lie_num_sum")
    private int lieNumSum;
    @Column("row_num_sum")
    private int rowNumSum;

    /**
     * @return the babiaoId
     */
    public Integer getBaobiaoId() {
        return baobiaoId;
    }

    /**
     * @param babiaoId the babiaoId to set
     */
    public void setBaobiaoId(Integer baobiaoId) {
        this.baobiaoId = baobiaoId;
    }

    /**
     * @return the isMold
     */
    public boolean isIsMold() {
        return isMold;
    }

    /**
     * @param isMold the isMold to set
     */
    public void setIsMold(boolean isMold) {
        this.isMold = isMold;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the lieNumSum
     */
    public int getLieNumSum() {
        return lieNumSum;
    }

    /**
     * @param lieNumSum the lieNumSum to set
     */
    public void setLieNumSum(int lieNumSum) {
        this.lieNumSum = lieNumSum;
    }

    /**
     * @return the rowNumSum
     */
    public int getRowNumSum() {
        return rowNumSum;
    }

    /**
     * @param rowNumSum the rowNumSum to set
     */
    public void setRowNumSum(int rowNumSum) {
        this.rowNumSum = rowNumSum;
    }
}
