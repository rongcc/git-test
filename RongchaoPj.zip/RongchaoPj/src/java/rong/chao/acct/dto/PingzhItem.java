/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.acct.dto;

import java.math.BigDecimal;
import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.PK;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("pingzh_item")
@PK({"pingzhNo", "itemNo"})
public class PingzhItem {

    @Column("pingzh_no")
    private String pingzhNo;
    @Column("item_no")
    private int itemNo;
    @Column("zhaiyao")
    private String zhaiyao;
    @Column("kemu_id")
    private String kemuId;
    @Column("kemu_name")
    private String kemuName;
    @Column("debit")
    private BigDecimal debit;
    @Column("credit")
    private BigDecimal credit;
    @Column("qty")
    private BigDecimal qty;
    @Column("price")
    private BigDecimal price;
    @Column("settle")
    private String settle;
    @Column("settle_num")
    private Integer settleNum;
    @Column("settle_date")
    private Date settleDate;

    /**
     * @return the pingzhNo
     */
    public String getPingzhNo() {
        return pingzhNo;
    }

    /**
     * @param pingzhNo the pingzhNo to set
     */
    public void setPingzhNo(String pingzhNo) {
        this.pingzhNo = pingzhNo;
    }

    /**
     * @return the itemNo
     */
    public int getItemNo() {
        return itemNo;
    }

    /**
     * @param itemNo the itemNo to set
     */
    public void setItemNo(int itemNo) {
        this.itemNo = itemNo;
    }

    /**
     * @return the zhaiyao
     */
    public String getZhaiyao() {
        return zhaiyao;
    }

    /**
     * @param zhaiyao the zhaiyao to set
     */
    public void setZhaiyao(String zhaiyao) {
        this.zhaiyao = zhaiyao;
    }

    /**
     * @return the kemuId
     */
    public String getKemuId() {
        return kemuId;
    }

    /**
     * @param kemuId the kemuId to set
     */
    public void setKemuId(String kemuId) {
        this.kemuId = kemuId;
    }

    /**
     * @return the kemuName
     */
    public String getKemuName() {
        return kemuName;
    }

    /**
     * @param kemuName the kemuName to set
     */
    public void setKemuName(String kemuName) {
        this.kemuName = kemuName;
    }

    /**
     * @return the debit
     */
    public BigDecimal getDebit() {
        return debit;
    }

    /**
     * @param debit the debit to set
     */
    public void setDebit(BigDecimal debit) {
        this.debit = debit;
    }

    /**
     * @return the credit
     */
    public BigDecimal getCredit() {
        return credit;
    }

    /**
     * @param credit the credit to set
     */
    public void setCredit(BigDecimal credit) {
        this.credit = credit;
    }

    /**
     * @return the qty
     */
    public BigDecimal getQty() {
        return qty;
    }

    /**
     * @param qty the qty to set
     */
    public void setQty(BigDecimal qty) {
        this.qty = qty;
    }

    /**
     * @return the price
     */
    public BigDecimal getPrice() {
        return price;
    }

    /**
     * @param price the price to set
     */
    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    /**
     * @return the settle
     */
    public String getSettle() {
        return settle;
    }

    /**
     * @param settle the settle to set
     */
    public void setSettle(String settle) {
        this.settle = settle;
    }

    /**
     * @return the settleNum
     */
    public Integer getSettleNum() {
        return settleNum;
    }

    /**
     * @param settleNum the settleNum to set
     */
    public void setSettleNum(Integer settleNum) {
        this.settleNum = settleNum;
    }

    /**
     * @return the settleDate
     */
    public Date getSettleDate() {
        return settleDate;
    }

    /**
     * @param settleDate the settleDate to set
     */
    public void setSettleDate(Date settleDate) {
        this.settleDate = settleDate;
    }
}
