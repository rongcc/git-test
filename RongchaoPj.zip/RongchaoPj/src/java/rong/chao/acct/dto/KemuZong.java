/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.acct.dto;

import java.math.BigDecimal;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Name;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("kemu_zong")
public class KemuZong {

    @Column("kemu_id")
    @Name
    private String kemuId;
    @Column("kemu_name")
    private String kemuName;
    @Column("qijian")
    private Integer qijian;
    @Column("start_yue")
    private BigDecimal startYue;
    @Column("bq_debit_heji")
    private BigDecimal bqDebitHeji;
    @Column("bq_credit_heji")
    private BigDecimal bqCreditHeji;
    @Column("year_debit_leiji")
    private BigDecimal yearDebitLeiji;
    @Column("year_credit_leiji")
    private BigDecimal yearCreditLeiji;
    @Column("yue")
    private BigDecimal yue;
    @Column("yue_fxiang")
    private String yueFxiang;

    public KemuZong() {
    }

    public KemuZong(String kemuId) {
        this.kemuId = kemuId;
    }

    public String getKemuId() {
        return kemuId;
    }

    public void setKemuId(String kemuId) {
        this.kemuId = kemuId;
    }

    public String getKemuName() {
        return kemuName;
    }

    public void setKemuName(String kemuName) {
        this.kemuName = kemuName;
    }

    public Integer getQijian() {
        return qijian;
    }

    public void setQijian(Integer qijian) {
        this.qijian = qijian;
    }

    public BigDecimal getStartYue() {
        return startYue;
    }

    public void setStartYue(BigDecimal startYue) {
        this.startYue = startYue;
    }

    public BigDecimal getBqDebitHeji() {
        return bqDebitHeji;
    }

    public void setBqDebitHeji(BigDecimal bqDebitHeji) {
        this.bqDebitHeji = bqDebitHeji;
    }

    public BigDecimal getBqCreditHeji() {
        return bqCreditHeji;
    }

    public void setBqCreditHeji(BigDecimal bqCreditHeji) {
        this.bqCreditHeji = bqCreditHeji;
    }

    public BigDecimal getYearDebitLeiji() {
        return yearDebitLeiji;
    }

    public void setYearDebitLeiji(BigDecimal yearDebitLeiji) {
        this.yearDebitLeiji = yearDebitLeiji;
    }

    public BigDecimal getYearCreditLeiji() {
        return yearCreditLeiji;
    }

    public void setYearCreditLeiji(BigDecimal yearCreditLeiji) {
        this.yearCreditLeiji = yearCreditLeiji;
    }

    public BigDecimal getYue() {
        return yue;
    }

    public void setYue(BigDecimal yue) {
        this.yue = yue;
    }

    public String getYueFxiang() {
        return yueFxiang;
    }

    public void setYueFxiang(String yueFxiang) {
        this.yueFxiang = yueFxiang;
    }
}
