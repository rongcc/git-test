/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.glasses.dto;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.PK;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("peijing_grid")
@PK({"peijingNo", "type"})
public class PeijingGrid {

    @Column("peijing_no")
    private String peijingNo;
    @Column("type")
    private String type;
    @Column("attribute1")
    private String attribute1;
    @Column("attribute2")
    private String attribute2;
    @Column("attribute3")
    private String attribute3;
    @Column("attribute4")
    private String attribute4;
    @Column("attribute5")
    private String attribute5;
    @Column("attribute6")
    private String attribute6;
    @Column("attribute7")
    private String attribute7;
    @Column("attribute8")
    private String attribute8;
    @Column("attribute9")
    private String attribute9;
    @Column("attribute10")
    private String attribute10;

    /**
     * @return the peijingNo
     */
    public String getPeijingNo() {
        return peijingNo;
    }

    /**
     * @param peijingNo the peijingNo to set
     */
    public void setPeijingNo(String peijingNo) {
        this.peijingNo = peijingNo;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return the attribute1
     */
    public String getAttribute1() {
        return attribute1;
    }

    /**
     * @param attribute1 the attribute1 to set
     */
    public void setAttribute1(String attribute1) {
        this.attribute1 = attribute1;
    }

    /**
     * @return the attribute2
     */
    public String getAttribute2() {
        return attribute2;
    }

    /**
     * @param attribute2 the attribute2 to set
     */
    public void setAttribute2(String attribute2) {
        this.attribute2 = attribute2;
    }

    /**
     * @return the attribute3
     */
    public String getAttribute3() {
        return attribute3;
    }

    /**
     * @param attribute3 the attribute3 to set
     */
    public void setAttribute3(String attribute3) {
        this.attribute3 = attribute3;
    }

    /**
     * @return the attribute4
     */
    public String getAttribute4() {
        return attribute4;
    }

    /**
     * @param attribute4 the attribute4 to set
     */
    public void setAttribute4(String attribute4) {
        this.attribute4 = attribute4;
    }

    /**
     * @return the attribute5
     */
    public String getAttribute5() {
        return attribute5;
    }

    /**
     * @param attribute5 the attribute5 to set
     */
    public void setAttribute5(String attribute5) {
        this.attribute5 = attribute5;
    }

    /**
     * @return the attribute6
     */
    public String getAttribute6() {
        return attribute6;
    }

    /**
     * @param attribute6 the attribute6 to set
     */
    public void setAttribute6(String attribute6) {
        this.attribute6 = attribute6;
    }

    /**
     * @return the attribute7
     */
    public String getAttribute7() {
        return attribute7;
    }

    /**
     * @param attribute7 the attribute7 to set
     */
    public void setAttribute7(String attribute7) {
        this.attribute7 = attribute7;
    }

    /**
     * @return the attribute8
     */
    public String getAttribute8() {
        return attribute8;
    }

    /**
     * @param attribute8 the attribute8 to set
     */
    public void setAttribute8(String attribute8) {
        this.attribute8 = attribute8;
    }

    /**
     * @return the attribute9
     */
    public String getAttribute9() {
        return attribute9;
    }

    /**
     * @param attribute9 the attribute9 to set
     */
    public void setAttribute9(String attribute9) {
        this.attribute9 = attribute9;
    }

    /**
     * @return the attribute10
     */
    public String getAttribute10() {
        return attribute10;
    }

    /**
     * @param attribute10 the attribute10 to set
     */
    public void setAttribute10(String attribute10) {
        this.attribute10 = attribute10;
    }
}
