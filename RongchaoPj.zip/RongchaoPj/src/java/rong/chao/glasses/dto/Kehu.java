/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.glasses.dto;

import java.math.BigDecimal;
import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Name;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("kehu")
public class Kehu {

    @Column("kehu_no")
    @Name
    private String kehuNo;
    @Column("kehu_name")
    private String kehuName;
    @Column("age")
    private Integer age;
    @Column("birth_date")
    private Date birthDate;
    @Column("address")
    private String address;
    @Column("dushu")
    private String dushu;
    @Column("telephone")
    private String telephone;
    @Column("qq_no")
    private String qqNo;
    @Column("peijing_date")
    private Date peijingDate;
    @Column("jin_e")
    private BigDecimal jinE;
    @Column("status")
    private int status;
    @Column("remark")
    private String remark;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;

    /**
     * @return the kehuNo
     */
    public String getKehuNo() {
        return kehuNo;
    }

    /**
     * @param kehuNo the kehuNo to set
     */
    public void setKehuNo(String kehuNo) {
        this.kehuNo = kehuNo;
    }

    /**
     * @return the kehuName
     */
    public String getKehuName() {
        return kehuName;
    }

    /**
     * @param kehuName the kehuName to set
     */
    public void setKehuName(String kehuName) {
        this.kehuName = kehuName;
    }

    /**
     * @return the age
     */
    public Integer getAge() {
        return age;
    }

    /**
     * @param age the age to set
     */
    public void setAge(Integer age) {
        this.age = age;
    }

    /**
     * @return the birthDate
     */
    public Date getBirthDate() {
        return birthDate;
    }

    /**
     * @param birthDate the birthDate to set
     */
    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    /**
     * @return the address
     */
    public String getAddress() {
        return address;
    }

    /**
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * @return the dushu
     */
    public String getDushu() {
        return dushu;
    }

    /**
     * @param dushu the dushu to set
     */
    public void setDushu(String dushu) {
        this.dushu = dushu;
    }

    /**
     * @return the telephone
     */
    public String getTelephone() {
        return telephone;
    }

    /**
     * @param telephone the telephone to set
     */
    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    /**
     * @return the qqNo
     */
    public String getQqNo() {
        return qqNo;
    }

    /**
     * @param qqNo the qqNo to set
     */
    public void setQqNo(String qqNo) {
        this.qqNo = qqNo;
    }

    /**
     * @return the peijingDate
     */
    public Date getPeijingDate() {
        return peijingDate;
    }

    /**
     * @param peijingDate the peijingDate to set
     */
    public void setPeijingDate(Date peijingDate) {
        this.peijingDate = peijingDate;
    }

    /**
     * @return the jinE
     */
    public BigDecimal getJinE() {
        return jinE;
    }

    /**
     * @param jinE the jinE to set
     */
    public void setJinE(BigDecimal jinE) {
        this.jinE = jinE;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * @param remark the remark to set
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }
}
