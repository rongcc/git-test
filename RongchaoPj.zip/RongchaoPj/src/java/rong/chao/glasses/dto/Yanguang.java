/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.glasses.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Name;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("yanguang")
public class Yanguang {

    @Column("yanguang_no")
    @Name
    private String yanguangNo;
    @Column("kehu_name")
    private String kehuName;
    @Column("age")
    private Integer age;
    @Column("yanguang_date")
    private Date yanguangDate;
    @Column("jingpian")
    private String jingpian;
    @Column("jingjia")
    private String jingjia;
    @Column("tongkong_yuan")
    private String tongkongYuan;
    @Column("tongkong_jin")
    private String tongkongJin;
    @Column("yanguang")
    private String yanguang;
    @Column("status")
    private int status;
    @Column("remark")
    private String remark;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;

    /**
     * @return the yanguangNo
     */
    public String getYanguangNo() {
        return yanguangNo;
    }

    /**
     * @param yanguangNo the yanguangNo to set
     */
    public void setYanguangNo(String yanguangNo) {
        this.yanguangNo = yanguangNo;
    }

    /**
     * @return the kehuName
     */
    public String getKehuName() {
        return kehuName;
    }

    /**
     * @param kehuName the kehuName to set
     */
    public void setKehuName(String kehuName) {
        this.kehuName = kehuName;
    }

    /**
     * @return the age
     */
    public Integer getAge() {
        return age;
    }

    /**
     * @param age the age to set
     */
    public void setAge(Integer age) {
        this.age = age;
    }

    /**
     * @return the yanguangDate
     */
    public Date getYanguangDate() {
        return yanguangDate;
    }

    /**
     * @param yanguangDate the yanguangDate to set
     */
    public void setYanguangDate(Date yanguangDate) {
        this.yanguangDate = yanguangDate;
    }

    /**
     * @return the jingpian
     */
    public String getJingpian() {
        return jingpian;
    }

    /**
     * @param jingpian the jingpian to set
     */
    public void setJingpian(String jingpian) {
        this.jingpian = jingpian;
    }

    /**
     * @return the jingjia
     */
    public String getJingjia() {
        return jingjia;
    }

    /**
     * @param jingjia the jingjia to set
     */
    public void setJingjia(String jingjia) {
        this.jingjia = jingjia;
    }

    /**
     * @return the tongkongYuan
     */
    public String getTongkongYuan() {
        return tongkongYuan;
    }

    /**
     * @param tongkongYuan the tongkongYuan to set
     */
    public void setTongkongYuan(String tongkongYuan) {
        this.tongkongYuan = tongkongYuan;
    }

    /**
     * @return the tongkongJin
     */
    public String getTongkongJin() {
        return tongkongJin;
    }

    /**
     * @param tongkongJin the tongkongJin to set
     */
    public void setTongkongJin(String tongkongJin) {
        this.tongkongJin = tongkongJin;
    }

    /**
     * @return the yanguang
     */
    public String getYanguang() {
        return yanguang;
    }

    /**
     * @param yanguang the yanguang to set
     */
    public void setYanguang(String yanguang) {
        this.yanguang = yanguang;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * @param remark the remark to set
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }
}
