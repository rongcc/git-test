/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.glasses.dto;

import java.math.BigDecimal;
import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Name;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("peijing")
public class Peijing {

    @Column("peijing_no")
    @Name
    private String peijingNo;
    @Column("kehu_name")
    private String kehuName;
    @Column("age")
    private Integer age;
    @Column("zhiye")
    private String zhiye;
    @Column("youbian")
    private String youbian;
    @Column("address")
    private String address;
    @Column("peijing_date")
    private Date peijingDate;
    @Column("qujing_date")
    private Date qujingDate;
    @Column("telephone")
    private String telephone;
    @Column("shuangguang_you")
    private String shuangguangYou;
    @Column("shuangguang_zuo")
    private String shuangguangZuo;
    @Column("jingbanyuan")
    private String jingbanyuan;
    @Column("tongju")
    private String tongju;
    @Column("yuanjing_tongju")
    private String yuanjingTongju;
    @Column("peijing_tongju")
    private String peijingTongju;
    @Column("jingpian_type")
    private String jingpianType;
    @Column("jingpian_jin_e")
    private BigDecimal jingpianJinE;
    @Column("jingjia_type")
    private String jingjiaType;
    @Column("jingjia_jin_e")
    private BigDecimal jingjiaJinE;
    @Column("qita_shuoming")
    private String qitaShuoming;
    @Column("heji_jin_e")
    private BigDecimal hejiJinE;
    @Column("status")
    private Integer status;
    @Column("remark")
    private String remark;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;

    /**
     * @return the peijingNo
     */
    public String getPeijingNo() {
        return peijingNo;
    }

    /**
     * @param peijingNo the peijingNo to set
     */
    public void setPeijingNo(String peijingNo) {
        this.peijingNo = peijingNo;
    }

    /**
     * @return the kehuName
     */
    public String getKehuName() {
        return kehuName;
    }

    /**
     * @param kehuName the kehuName to set
     */
    public void setKehuName(String kehuName) {
        this.kehuName = kehuName;
    }

    /**
     * @return the age
     */
    public Integer getAge() {
        return age;
    }

    /**
     * @param age the age to set
     */
    public void setAge(Integer age) {
        this.age = age;
    }

    /**
     * @return the zhiye
     */
    public String getZhiye() {
        return zhiye;
    }

    /**
     * @param zhiye the zhiye to set
     */
    public void setZhiye(String zhiye) {
        this.zhiye = zhiye;
    }

    /**
     * @return the youbian
     */
    public String getYoubian() {
        return youbian;
    }

    /**
     * @param youbian the youbian to set
     */
    public void setYoubian(String youbian) {
        this.youbian = youbian;
    }

    /**
     * @return the address
     */
    public String getAddress() {
        return address;
    }

    /**
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * @return the peijingDate
     */
    public Date getPeijingDate() {
        return peijingDate;
    }

    /**
     * @param peijingDate the peijingDate to set
     */
    public void setPeijingDate(Date peijingDate) {
        this.peijingDate = peijingDate;
    }

    /**
     * @return the qujingDate
     */
    public Date getQujingDate() {
        return qujingDate;
    }

    /**
     * @param qujingDate the qujingDate to set
     */
    public void setQujingDate(Date qujingDate) {
        this.qujingDate = qujingDate;
    }

    /**
     * @return the telephone
     */
    public String getTelephone() {
        return telephone;
    }

    /**
     * @param telephone the telephone to set
     */
    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    /**
     * @return the shuangguangYou
     */
    public String getShuangguangYou() {
        return shuangguangYou;
    }

    /**
     * @param shuangguangYou the shuangguangYou to set
     */
    public void setShuangguangYou(String shuangguangYou) {
        this.shuangguangYou = shuangguangYou;
    }

    /**
     * @return the shuangguangZuo
     */
    public String getShuangguangZuo() {
        return shuangguangZuo;
    }

    /**
     * @param shuangguangZuo the shuangguangZuo to set
     */
    public void setShuangguangZuo(String shuangguangZuo) {
        this.shuangguangZuo = shuangguangZuo;
    }

    /**
     * @return the jingbanyuan
     */
    public String getJingbanyuan() {
        return jingbanyuan;
    }

    /**
     * @param jingbanyuan the jingbanyuan to set
     */
    public void setJingbanyuan(String jingbanyuan) {
        this.jingbanyuan = jingbanyuan;
    }

    /**
     * @return the tongju
     */
    public String getTongju() {
        return tongju;
    }

    /**
     * @param tongju the tongju to set
     */
    public void setTongju(String tongju) {
        this.tongju = tongju;
    }

    /**
     * @return the yuanjingTongju
     */
    public String getYuanjingTongju() {
        return yuanjingTongju;
    }

    /**
     * @param yuanjingTongju the yuanjingTongju to set
     */
    public void setYuanjingTongju(String yuanjingTongju) {
        this.yuanjingTongju = yuanjingTongju;
    }

    /**
     * @return the peijingTongju
     */
    public String getPeijingTongju() {
        return peijingTongju;
    }

    /**
     * @param peijingTongju the peijingTongju to set
     */
    public void setPeijingTongju(String peijingTongju) {
        this.peijingTongju = peijingTongju;
    }

    /**
     * @return the jingpianType
     */
    public String getJingpianType() {
        return jingpianType;
    }

    /**
     * @param jingpianType the jingpianType to set
     */
    public void setJingpianType(String jingpianType) {
        this.jingpianType = jingpianType;
    }

    /**
     * @return the jingpianJinE
     */
    public BigDecimal getJingpianJinE() {
        return jingpianJinE;
    }

    /**
     * @param jingpianJinE the jingpianJinE to set
     */
    public void setJingpianJinE(BigDecimal jingpianJinE) {
        this.jingpianJinE = jingpianJinE;
    }

    /**
     * @return the jingjiaType
     */
    public String getJingjiaType() {
        return jingjiaType;
    }

    /**
     * @param jingjiaType the jingjiaType to set
     */
    public void setJingjiaType(String jingjiaType) {
        this.jingjiaType = jingjiaType;
    }

    /**
     * @return the jingjiaJinE
     */
    public BigDecimal getJingjiaJinE() {
        return jingjiaJinE;
    }

    /**
     * @param jingjiaJinE the jingjiaJinE to set
     */
    public void setJingjiaJinE(BigDecimal jingjiaJinE) {
        this.jingjiaJinE = jingjiaJinE;
    }

    /**
     * @return the qitaShuoming
     */
    public String getQitaShuoming() {
        return qitaShuoming;
    }

    /**
     * @param qitaShuoming the qitaShuoming to set
     */
    public void setQitaShuoming(String qitaShuoming) {
        this.qitaShuoming = qitaShuoming;
    }

    /**
     * @return the hejiJinE
     */
    public BigDecimal getHejiJinE() {
        return hejiJinE;
    }

    /**
     * @param hejiJinE the hejiJinE to set
     */
    public void setHejiJinE(BigDecimal hejiJinE) {
        this.hejiJinE = hejiJinE;
    }

    /**
     * @return the status
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * @return the remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * @param remark the remark to set
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }


    
}
