/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.glasses.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import org.apache.commons.dbcp.BasicDataSource;

/**
 *
 * @author zhourongchao
 */
public class DBConnect {

    private String dbUrl = "jdbc:mysql://localhost:3306/glasses?useUnicode=true&characterEncoding=GBK";
    private String dbUser = "root";
    private String dbPwd = "125412";

    /** Creates a new instance of DBConnect */
    public DBConnect() throws Exception {
        //Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
        Class.forName("com.mysql.jdbc.Driver");// org.gjt.mm.mysql.Driver");//
    }

    public Connection getConnection() throws Exception {
        return java.sql.DriverManager.getConnection(dbUrl, dbUser, dbPwd);
    }

    public void closeConnection(Connection con) {
        try {
            if (con != null) {
                con.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void closePrepStmt(PreparedStatement prepStmt) {
        try {
            if (prepStmt != null) {
                prepStmt.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void closeResultSet(ResultSet rs) {
        try {
            if (rs != null) {
                rs.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public BasicDataSource getDataSource() {
        BasicDataSource ds = null;
        try {
            ds = new BasicDataSource();
            ds.setDriverClassName("com.mysql.jdbc.Driver");
            ds.setUrl(dbUrl);
            ds.setUsername(dbUser);
            ds.setPassword(dbPwd);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ds;
    }
}
