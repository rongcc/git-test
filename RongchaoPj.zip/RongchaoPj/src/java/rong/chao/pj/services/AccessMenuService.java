/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.pj.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.sql.DataSource;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rong.gwm.ts.dto.AccessMenu;

/**
 *
 * @author zhourongchao
 */
public class AccessMenuService {

    /**
     * 获取一个用户对一个菜单的权限
     * @param ds
     * @param codeType
     * @param code
     * @return
     */
    public AccessMenu fetch(DataSource ds, String codeType, String code) {
        AccessMenu cd = null;
        try {
            Dao dao = new NutDao(ds);
            cd = dao.fetchx(AccessMenu.class, codeType, code);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cd;
    }

    /**
     * 删除一个用户对一个菜单的权限
     * @param ds
     * @param cd
     * @return
     */
    public int delete(DataSource ds, AccessMenu cd) {
        int di = 0;
        try {
            Dao dao = new NutDao(ds);
            di = dao.deletex(AccessMenu.class, cd.getOperNo(), cd.getAccessMenu());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return di;
    }

    /**
     * 删除一个用户所有的菜单权限
     * @param ds
     * @param cd
     * @return
     */
    public int deleteOperMenus(DataSource ds, String oper) {
        int di = 0;
        Connection conn = null;
        PreparedStatement pStmt = null;
        try {
            conn = ds.getConnection();
            String sqlStr = "delete FROM access_menu where oper_no=? ";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, oper);
            di = pStmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return di;
    }
}
