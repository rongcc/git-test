/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.pj.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.sql.DataSource;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rong.chao.pj.dto.Work;

/**
 *
 * @author zhourongchao
 */
public class WorkService {

    public Work fetch(DataSource ds, String codeType, String code) {
        Work cd = null;
        try {
            Dao dao = new NutDao(ds);
            cd = dao.fetchx(Work.class, codeType, code);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cd;
    }

    public int delete(DataSource ds, Work cd) {
        int di = 0;
        try {
            Dao dao = new NutDao(ds);
            di = dao.deletex(Work.class, cd.getWorkNo(), cd.getPjNo());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return di;
    }

    /**
     * 获得此工作的子工作的下一个编号。如果首次编号可以传入空。
     * @param ds
     * @param pjNo
     * @param workNo
     * @return
     */
    public String getNextSonNo(DataSource ds, int pjNo, String workNo) {
        String nextNo = "";
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            StringBuffer sb = new StringBuffer();
            //传入空的情况
            String myWorkNo = "";
            int myLength = 0;
            if (workNo == null || workNo.equals("")) {
                myLength = 0;
                myWorkNo = "";
            }
            if (workNo.length() < 3) {
                myLength = 0;
                myWorkNo = "";
            }
            myWorkNo = "" + workNo;
            //
            myLength = workNo.length();
            String sqlStr = "SELECT max(work_no) FROM chao_work where pj_no=? and work_no like '%" + workNo + "%' and length(work_no)=? ;";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setInt(1, pjNo);
            pStmt.setInt(2, myLength + 3);
            rs = pStmt.executeQuery();
            String maxNo = null;
            if (rs.next()) {
                maxNo = rs.getString(1);
            }
            int ni;
            if (maxNo != null) {
                ni = 1001 + Integer.parseInt(maxNo.substring(myLength));
            } else {
                ni = 1001;
            }
            //
            nextNo = myWorkNo + sb.append(ni).substring(1).toString();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return nextNo;
    }
}
