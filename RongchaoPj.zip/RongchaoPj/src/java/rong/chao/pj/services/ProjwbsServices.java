/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.pj.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;
import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rong.chao.pj.dto.Projwbs;

/**
 *
 * @author ZhouRongChao
 */
public class ProjwbsServices {

    /**
     * 获取
     * @param ds
     * @param codeType
     * @param code
     * @return
     */
    public Projwbs fetch(DataSource ds, int codeType, int code) {
        Projwbs cd = null;
        try {
            Dao dao = new NutDao(ds);
            cd = dao.fetchx(Projwbs.class, codeType, code);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cd;
    }

    /**
     * 删除
     * @param ds
     * @param cd
     * @return
     */
    public int delete(DataSource ds, Projwbs cd) {
        int di = 0;
        try {
            Dao dao = new NutDao(ds);
            di = dao.deletex(Projwbs.class, cd.getFatherId(), cd.getWorkId());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return di;
    }

    /**
     * 获得项目的顶层工作。
     * @param ds
     * @param projectNo
     * @return
     */
    public List getProjTopWorks(DataSource ds, int projectNo) {
        List al = null;
        try {
            Dao dao = new NutDao(ds);
            al = dao.query(Projwbs.class, Cnd.where("project_no", "=", projectNo).and("father_id", "=", 0), null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return al;
    }

    /**
     * 获得一项工作的所有子节点。
     * @param ds
     * @param cd
     * @return
     */
    public List getSonList(DataSource ds, Projwbs cd) {
        List al = null;
        try {
            Dao dao = new NutDao(ds);
            al = dao.query(Projwbs.class, Cnd.where("project_no", "=", cd.getProjectNo()).and("father_id", "=", cd.getWorkId()), null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return al;
    }

    /**
     * 获得项目的底层工作。
     * @param ds
     * @param projectNo
     * @return
     */
    public List getProjBaseWorks(DataSource ds, int projectNo) {
        List al = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            String sqlStr = "select work_id from PROJWBS where project_no=? and "
                    + "work_id not in(select father_id from PROJWBS where project_no=?)";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setInt(1, projectNo);
            pStmt.setInt(2, projectNo);
            rs = pStmt.executeQuery();
            al = new ArrayList();
            while (rs.next()) {
                al.add(rs.getInt(1));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return al;
    }

    /**
     * 是否为底层工作。
     * @param ds
     * @param cd
     * @return
     */
    public boolean isBaseWork(DataSource ds, Projwbs cd) {
        boolean boo = false;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            String sqlStr = "select count(1) from PROJWBS where project_no=? and father_id=?";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setInt(1, cd.getProjectNo());
            pStmt.setInt(2, cd.getWorkId());
            rs = pStmt.executeQuery();
            int di = -1;
            while (rs.next()) {
                di = rs.getInt(1);
            }
            if (di == 0) {
                boo = true;
            } else {
                boo = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return boo;
    }

    /**
     * 获得一个项目的最大层阶值。
     * @param ds
     * @param projectNo
     * @return
     */
    public int getProjMaxLevel(DataSource ds, int projectNo) {
        int di = 0;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            String sqlStr = "select max(level) from projwbs where project_no=?";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setInt(1, projectNo);
            rs = pStmt.executeQuery();
            while (rs.next()) {
                di = rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return di;
    }

    /**
     * 获得一项工作下一个ID号
     * @param ds
     * @param projectNo
     * @return
     */
    public int getNextWorkId(DataSource ds, int projectNo) {
        int di = 0;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            String sqlStr = "select max(work_id) from projwbs where project_no=?";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setInt(1, projectNo);
            rs = pStmt.executeQuery();
            if (rs.next()) {
                di = rs.getInt(1);
            }
            if (di < 1) {
                di = 1;
            } else {
                di += 1;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return di;
    }
}
