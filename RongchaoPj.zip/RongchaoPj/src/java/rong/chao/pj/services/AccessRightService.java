/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.pj.services;

import javax.sql.DataSource;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rong.gwm.ts.dto.AccessRight;

/**
 *
 * @author zhourongchao
 */
public class AccessRightService {

    /**
     * 获取一个用户对一个页面的权限
     * @param ds
     * @param codeType
     * @param code
     * @return
     */
    public AccessRight fetch(DataSource ds, String codeType, String code) {
        AccessRight cd = null;
        try {
            Dao dao = new NutDao(ds);
            cd = dao.fetchx(AccessRight.class, codeType, code);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cd;
    }

    /**
     * 删除一个用户对一个页面的权限
     * @param ds
     * @param cd
     * @return
     */
    public int delete(DataSource ds, AccessRight cd) {
        int di = 0;
        try {
            Dao dao = new NutDao(ds);
            di = dao.deletex(AccessRight.class, cd.getOperNo(), cd.getAccessPage());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return di;
    }

    /**
     * 获取用户的数据范围
     * @param ds
     * @param operNo
     * @param accessPage
     * @return
     */
    public int getDataScope(DataSource ds, String operNo, String accessPage) {
        return fetch(ds, operNo, accessPage).getDataScope();
    }
}
