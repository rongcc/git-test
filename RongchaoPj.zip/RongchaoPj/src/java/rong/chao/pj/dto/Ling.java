/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.pj.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Name;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("chao_ling")
public class Ling {

    @Column("ling_no")
    @Name
    private String lingNo;
    @Column("ling_name")
    private String lingName;
    @Column("ling_description")
    private String lingDescription;
    @Column("start_date")
    private Date startDate;
    @Column("end_date")
    private Date endDate;
    @Column("person")
    private String person;
    @Column("tip")
    private String tip;
    @Column("impower")
    private String impower;
    @Column("imorder")
    private String imorder;
    @Column("about_work")
    private String aboutWork;
    @Column("status")
    private int status;
    @Column("finished")
    private boolean finished;
    @Column("feedback")
    private String feedback;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;
    @Column("edit_date")
    private Date editDate;
    @Column("edit_name")
    private String editName;
    @Column("post_date")
    private Date postDate;
    @Column("post_name")
    private String postName;
    @Column("remark")
    private String remark;

    /**
     * @return the lingNo
     */
    public String getLingNo() {
        return lingNo;
    }

    /**
     * @param lingNo the lingNo to set
     */
    public void setLingNo(String lingNo) {
        this.lingNo = lingNo;
    }

    /**
     * @return the lingName
     */
    public String getLingName() {
        return lingName;
    }

    /**
     * @param lingName the lingName to set
     */
    public void setLingName(String lingName) {
        this.lingName = lingName;
    }

    /**
     * @return the lingDescription
     */
    public String getLingDescription() {
        return lingDescription;
    }

    /**
     * @param lingDescription the lingDescription to set
     */
    public void setLingDescription(String lingDescription) {
        this.lingDescription = lingDescription;
    }

    /**
     * @return the startDate
     */
    public Date getStartDate() {
        return startDate;
    }

    /**
     * @param startDate the startDate to set
     */
    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    /**
     * @return the endDate
     */
    public Date getEndDate() {
        return endDate;
    }

    /**
     * @param endDate the endDate to set
     */
    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    /**
     * @return the person
     */
    public String getPerson() {
        return person;
    }

    /**
     * @param person the person to set
     */
    public void setPerson(String person) {
        this.person = person;
    }

    /**
     * @return the tip
     */
    public String getTip() {
        return tip;
    }

    /**
     * @param tip the tip to set
     */
    public void setTip(String tip) {
        this.tip = tip;
    }

    /**
     * @return the impower
     */
    public String getImpower() {
        return impower;
    }

    /**
     * @param impower the impower to set
     */
    public void setImpower(String impower) {
        this.impower = impower;
    }


    /**
     * @return the aboutWork
     */
    public String getAboutWork() {
        return aboutWork;
    }

    /**
     * @param aboutWork the aboutWork to set
     */
    public void setAboutWork(String aboutWork) {
        this.aboutWork = aboutWork;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the finished
     */
    public boolean isFinished() {
        return finished;
    }

    /**
     * @param finished the finished to set
     */
    public void setFinished(boolean finished) {
        this.finished = finished;
    }

    /**
     * @return the feedback
     */
    public String getFeedback() {
        return feedback;
    }

    /**
     * @param feedback the feedback to set
     */
    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    /**
     * @return the editDate
     */
    public Date getEditDate() {
        return editDate;
    }

    /**
     * @param editDate the editDate to set
     */
    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }

    /**
     * @return the editName
     */
    public String getEditName() {
        return editName;
    }

    /**
     * @param editName the editName to set
     */
    public void setEditName(String editName) {
        this.editName = editName;
    }

    /**
     * @return the postDate
     */
    public Date getPostDate() {
        return postDate;
    }

    /**
     * @param postDate the postDate to set
     */
    public void setPostDate(Date postDate) {
        this.postDate = postDate;
    }

    /**
     * @return the postName
     */
    public String getPostName() {
        return postName;
    }

    /**
     * @param postName the postName to set
     */
    public void setPostName(String postName) {
        this.postName = postName;
    }

    /**
     * @return the remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * @param remark the remark to set
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * @return the imorder
     */
    public String getImorder() {
        return imorder;
    }

    /**
     * @param imorder the imorder to set
     */
    public void setImorder(String imorder) {
        this.imorder = imorder;
    }
}
