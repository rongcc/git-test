/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.pj.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.PK;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author ZhouRongChao
 */
@Table("projwbs")
@PK({"projectNo", "workId"})
public class Projwbs {

    @Column("father_id")
    private int fatherId;
    @Column("work_id")
    private int workId;
    @Column("pre_work_id")
    private int preWorkId;
    @Column("work_name")
    private String workName;
    @Column("wbs_code")
    private String wbsCode;
    @Column("sch_start_date")
    private Date schStartDate;
    @Column("sch_end_date")
    private Date schEndDate;
    @Column("act_start_date")
    private Date actStartDate;
    @Column("act_end_date")
    private Date actEndDate;
    @Column("sch_percent")
    private Double schPercent;
    @Column("act_percent")
    private Double actPercent;
    @Column("finished")
    private boolean finished;
    @Column("man")
    private String man;
    @Column("pin_type")
    private String pinType;
    @Column("project_no")
    private int projectNo;
    @Column("type")
    private String type;
    @Column("status")
    private short status;
    @Column("remark")
    private String remark;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;
    @Column("edit_date")
    private Date editDate;
    @Column("edit_name")
    private String editName;
    @Column("sch_time_limit")
    private Double schTimeLimit;
    @Column("act_time_limit")
    private Double actTimeLimit;
    @Column("time_limit_units")
    private String timeLimitUnits;
    @Column("level")
    private int level;

 

    /**
     * @return the workName
     */
    public String getWorkName() {
        return workName;
    }

    /**
     * @param workName the workName to set
     */
    public void setWorkName(String workName) {
        this.workName = workName;
    }

    /**
     * @return the schStartDate
     */
    public Date getSchStartDate() {
        return schStartDate;
    }

    /**
     * @param schStartDate the schStartDate to set
     */
    public void setSchStartDate(Date schStartDate) {
        this.schStartDate = schStartDate;
    }

    /**
     * @return the schEndDate
     */
    public Date getSchEndDate() {
        return schEndDate;
    }

    /**
     * @param schEndDate the schEndDate to set
     */
    public void setSchEndDate(Date schEndDate) {
        this.schEndDate = schEndDate;
    }

    /**
     * @return the actStartDate
     */
    public Date getActStartDate() {
        return actStartDate;
    }

    /**
     * @param actStartDate the actStartDate to set
     */
    public void setActStartDate(Date actStartDate) {
        this.actStartDate = actStartDate;
    }

    /**
     * @return the actEndDate
     */
    public Date getActEndDate() {
        return actEndDate;
    }

    /**
     * @param actEndDate the actEndDate to set
     */
    public void setActEndDate(Date actEndDate) {
        this.actEndDate = actEndDate;
    }

    /**
     * @return the schPercent
     */
    public Double getSchPercent() {
        return schPercent;
    }

    /**
     * @param schPercent the schPercent to set
     */
    public void setSchPercent(Double schPercent) {
        this.schPercent = schPercent;
    }

    /**
     * @return the actPercent
     */
    public Double getActPercent() {
        return actPercent;
    }

    /**
     * @param actPercent the actPercent to set
     */
    public void setActPercent(Double actPercent) {
        this.actPercent = actPercent;
    }

    /**
     * @return the finished
     */
    public boolean isFinished() {
        return finished;
    }

    /**
     * @param finished the finished to set
     */
    public void setFinished(boolean finished) {
        this.finished = finished;
    }

    /**
     * @return the man
     */
    public String getMan() {
        return man;
    }

    /**
     * @param man the man to set
     */
    public void setMan(String man) {
        this.man = man;
    }

    /**
     * @return the pinType
     */
    public String getPinType() {
        return pinType;
    }

    /**
     * @param pinType the pinType to set
     */
    public void setPinType(String pinType) {
        this.pinType = pinType;
    }

    /**
     * @return the projectNo
     */
    public int getProjectNo() {
        return projectNo;
    }

    /**
     * @param projectNo the projectNo to set
     */
    public void setProjectNo(int projectNo) {
        this.projectNo = projectNo;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return the status
     */
    public short getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(short status) {
        this.status = status;
    }

    /**
     * @return the remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * @param remark the remark to set
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    /**
     * @return the editDate
     */
    public Date getEditDate() {
        return editDate;
    }

    /**
     * @param editDate the editDate to set
     */
    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }

    /**
     * @return the editName
     */
    public String getEditName() {
        return editName;
    }

    /**
     * @param editName the editName to set
     */
    public void setEditName(String editName) {
        this.editName = editName;
    }

    /**
     * @return the wbsCode
     */
    public String getWbsCode() {
        return wbsCode;
    }

    /**
     * @param wbsCode the wbsCode to set
     */
    public void setWbsCode(String wbsCode) {
        this.wbsCode = wbsCode;
    }

    /**
     * @return the fatherId
     */
    public int getFatherId() {
        return fatherId;
    }

    /**
     * @param fatherId the fatherId to set
     */
    public void setFatherId(int fatherId) {
        this.fatherId = fatherId;
    }

    /**
     * @return the workId
     */
    public int getWorkId() {
        return workId;
    }

    /**
     * @param workId the workId to set
     */
    public void setWorkId(int workId) {
        this.workId = workId;
    }


    /**
     * @return the schTimeLimit
     */
    public Double getSchTimeLimit() {
        return schTimeLimit;
    }

    /**
     * @param schTimeLimit the schTimeLimit to set
     */
    public void setSchTimeLimit(Double schTimeLimit) {
        this.schTimeLimit = schTimeLimit;
    }

    /**
     * @return the actTimeLimit
     */
    public Double getActTimeLimit() {
        return actTimeLimit;
    }

    /**
     * @param actTimeLimit the actTimeLimit to set
     */
    public void setActTimeLimit(Double actTimeLimit) {
        this.actTimeLimit = actTimeLimit;
    }

    /**
     * @return the timeLimitUnits
     */
    public String getTimeLimitUnits() {
        return timeLimitUnits;
    }

    /**
     * @param timeLimitUnits the timeLimitUnits to set
     */
    public void setTimeLimitUnits(String timeLimitUnits) {
        this.timeLimitUnits = timeLimitUnits;
    }

    /**
     * @return the preWorkId
     */
    public int getPreWorkId() {
        return preWorkId;
    }

    /**
     * @param preWorkId the preWorkId to set
     */
    public void setPreWorkId(int preWorkId) {
        this.preWorkId = preWorkId;
    }

    /**
     * @return the level
     */
    public int getLevel() {
        return level;
    }

    /**
     * @param level the level to set
     */
    public void setLevel(int level) {
        this.level = level;
    }
}
