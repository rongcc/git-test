/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.pj.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.PK;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("access_menu")
@PK({"operNo", "accessMenu"})
public class AccessMenu {

    @Column("oper_no")
    private String operNo;
    @Column("access_menu")
    private String accessMenu;
    @Column("access_menu_name")
    private String accessMenuName;
    @Column("status")
    private int status;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;

    public AccessMenu() {
    }

    public AccessMenu(String operNo, String accessMenu) {
        this.operNo = operNo;
        this.accessMenu = accessMenu;
    }

    /**
     * @return the operNo
     */
    public String getOperNo() {
        return operNo;
    }

    /**
     * @param operNo the operNo to set
     */
    public void setOperNo(String operNo) {
        this.operNo = operNo;
    }

    /**
     * @return the accessMenu
     */
    public String getAccessMenu() {
        return accessMenu;
    }

    /**
     * @param accessMenu the accessMenu to set
     */
    public void setAccessMenu(String accessMenu) {
        this.accessMenu = accessMenu;
    }

    /**
     * @return the accessMenuName
     */
    public String getAccessMenuName() {
        return accessMenuName;
    }

    /**
     * @param accessMenuName the accessMenuName to set
     */
    public void setAccessMenuName(String accessMenuName) {
        this.accessMenuName = accessMenuName;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }
}
