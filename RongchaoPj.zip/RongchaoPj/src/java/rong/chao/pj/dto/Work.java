/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.pj.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.PK;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("chao_work")
@PK({"workNo", "pjNo"})
public class Work {

    @Column("work_no")
    private String workNo;
    @Column("work_name")
    private String workName;
    @Column("work_description")
    private String workDescription;
    @Column("sch_start_date")
    private Date schStartDate;
    @Column("sch_end_date")
    private Date schEndDate;
    @Column("act_start_date")
    private Date actStartDate;
    @Column("act_end_date")
    private Date actEndDate;
    @Column("person")
    private String person;
    @Column("status")
    private int status;
    @Column("finished")
    private boolean finished;
    @Column("percent")
    private Double percent;
    @Column("remark")
    private String remark;
    @Column("pj_no")
    private int pjNo;
    @Column("pj_name")
    private String pjName;

    public Work() {
    }

    public Work(String workNo, int pjNo) {
        this.workNo = workNo;
        this.pjNo = pjNo;
    }
   
    public Work(String workNo, String workName, short status, boolean finished, int pjNo) {
        this.workNo = workNo;
        this.workName = workName;
        this.status = status;
        this.finished = finished;
        this.pjNo = pjNo;
    }

    /**
     * @return the workNo
     */
    public String getWorkNo() {
        return workNo;
    }

    /**
     * @param workNo the workNo to set
     */
    public void setWorkNo(String workNo) {
        this.workNo = workNo;
    }

    /**
     * @return the workName
     */
    public String getWorkName() {
        return workName;
    }

    /**
     * @param workName the workName to set
     */
    public void setWorkName(String workName) {
        this.workName = workName;
    }

    /**
     * @return the workDescription
     */
    public String getWorkDescription() {
        return workDescription;
    }

    /**
     * @param workDescription the workDescription to set
     */
    public void setWorkDescription(String workDescription) {
        this.workDescription = workDescription;
    }

    /**
     * @return the schStartDate
     */
    public Date getSchStartDate() {
        return schStartDate;
    }

    /**
     * @param schStartDate the schStartDate to set
     */
    public void setSchStartDate(Date schStartDate) {
        this.schStartDate = schStartDate;
    }

    /**
     * @return the schEndDate
     */
    public Date getSchEndDate() {
        return schEndDate;
    }

    /**
     * @param schEndDate the schEndDate to set
     */
    public void setSchEndDate(Date schEndDate) {
        this.schEndDate = schEndDate;
    }

    /**
     * @return the actStartDate
     */
    public Date getActStartDate() {
        return actStartDate;
    }

    /**
     * @param actStartDate the actStartDate to set
     */
    public void setActStartDate(Date actStartDate) {
        this.actStartDate = actStartDate;
    }

    /**
     * @return the actEndDate
     */
    public Date getActEndDate() {
        return actEndDate;
    }

    /**
     * @param actEndDate the actEndDate to set
     */
    public void setActEndDate(Date actEndDate) {
        this.actEndDate = actEndDate;
    }

    /**
     * @return the person
     */
    public String getPerson() {
        return person;
    }

    /**
     * @param person the person to set
     */
    public void setPerson(String person) {
        this.person = person;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the finished
     */
    public boolean isFinished() {
        return finished;
    }

    /**
     * @param finished the finished to set
     */
    public void setFinished(boolean finished) {
        this.finished = finished;
    }

    /**
     * @return the percent
     */
    public Double getPercent() {
        return percent;
    }

    /**
     * @param percent the percent to set
     */
    public void setPercent(Double percent) {
        this.percent = percent;
    }

    /**
     * @return the remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * @param remark the remark to set
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * @return the pjNo
     */
    public int getPjNo() {
        return pjNo;
    }

    /**
     * @param pjNo the pjNo to set
     */
    public void setPjNo(int pjNo) {
        this.pjNo = pjNo;
    }

    /**
     * @return the pjName
     */
    public String getPjName() {
        return pjName;
    }

    /**
     * @param pjName the pjName to set
     */
    public void setPjName(String pjName) {
        this.pjName = pjName;
    }
}
