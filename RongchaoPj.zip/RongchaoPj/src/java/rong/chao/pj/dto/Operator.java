/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.pj.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Name;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("operator")
public class Operator {

    @Column("oper_no")
    @Name
    private String operNo;
    @Column("oper_name")
    private String operName;
    @Column("passwd")
    private String passwd;
    @Column("dept_no")
    private String deptNo;
    @Column("dept_name")
    private String deptName;
    @Column("oper_status")
    private int operStatus;
    @Column("status")
    private int status;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;
    @Column("edit_date")
    private Date editDate;
    @Column("edit_name")
    private String editName;
    @Column("post_date")
    private Date postDate;
    @Column("post_name")
    private String postName;
    @Column("post2_date")
    private Date post2Date;
    @Column("post2_name")
    private String post2Name;
    @Column("type_no")
    private String typeNo;
    @Column("type_name")
    private String typeName;
    @Column("last_login_ip")
    private String lastLoginIp;
    @Column("current_login_ip")
    private String currentLoginIp;
    @Column("last_login_date")
    private Date lastLoginDate;
    @Column("current_login_date")
    private Date currentLoginDate;
    @Column("oper_group_no")
    private String operGroupNo;
    @Column("oper_group_name")
    private String operGroupName;
    @Column("tel_1")
    private String tel1;
    @Column("tel_2")
    private String tel2;
    @Column("hr_code")
    private String hrCode;
    @Column("duty")
    private String duty;

    /**
     * @return the operNo
     */
    public String getOperNo() {
        return operNo;
    }

    /**
     * @param operNo the operNo to set
     */
    public void setOperNo(String operNo) {
        this.operNo = operNo;
    }

    /**
     * @return the operName
     */
    public String getOperName() {
        return operName;
    }

    /**
     * @param operName the operName to set
     */
    public void setOperName(String operName) {
        this.operName = operName;
    }

    /**
     * @return the passwd
     */
    public String getPasswd() {
        return passwd;
    }

    /**
     * @param passwd the passwd to set
     */
    public void setPasswd(String passwd) {
        this.passwd = passwd;
    }

    /**
     * @return the deptNo
     */
    public String getDeptNo() {
        return deptNo;
    }

    /**
     * @param deptNo the deptNo to set
     */
    public void setDeptNo(String deptNo) {
        this.deptNo = deptNo;
    }

    /**
     * @return the deptName
     */
    public String getDeptName() {
        return deptName;
    }

    /**
     * @param deptName the deptName to set
     */
    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    /**
     * @return the operStatus
     */
    public int getOperStatus() {
        return operStatus;
    }

    /**
     * @param operStatus the operStatus to set
     */
    public void setOperStatus(int operStatus) {
        this.operStatus = operStatus;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    /**
     * @return the editDate
     */
    public Date getEditDate() {
        return editDate;
    }

    /**
     * @param editDate the editDate to set
     */
    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }

    /**
     * @return the editName
     */
    public String getEditName() {
        return editName;
    }

    /**
     * @param editName the editName to set
     */
    public void setEditName(String editName) {
        this.editName = editName;
    }

    /**
     * @return the postDate
     */
    public Date getPostDate() {
        return postDate;
    }

    /**
     * @param postDate the postDate to set
     */
    public void setPostDate(Date postDate) {
        this.postDate = postDate;
    }

    /**
     * @return the postName
     */
    public String getPostName() {
        return postName;
    }

    /**
     * @param postName the postName to set
     */
    public void setPostName(String postName) {
        this.postName = postName;
    }

    /**
     * @return the post2Date
     */
    public Date getPost2Date() {
        return post2Date;
    }

    /**
     * @param post2Date the post2Date to set
     */
    public void setPost2Date(Date post2Date) {
        this.post2Date = post2Date;
    }

    /**
     * @return the post2Name
     */
    public String getPost2Name() {
        return post2Name;
    }

    /**
     * @param post2Name the post2Name to set
     */
    public void setPost2Name(String post2Name) {
        this.post2Name = post2Name;
    }

    /**
     * @return the typeNo
     */
    public String getTypeNo() {
        return typeNo;
    }

    /**
     * @param typeNo the typeNo to set
     */
    public void setTypeNo(String typeNo) {
        this.typeNo = typeNo;
    }

    /**
     * @return the typeName
     */
    public String getTypeName() {
        return typeName;
    }

    /**
     * @param typeName the typeName to set
     */
    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    /**
     * @return the lastLoginIp
     */
    public String getLastLoginIp() {
        return lastLoginIp;
    }

    /**
     * @param lastLoginIp the lastLoginIp to set
     */
    public void setLastLoginIp(String lastLoginIp) {
        this.lastLoginIp = lastLoginIp;
    }

    /**
     * @return the currentLoginIp
     */
    public String getCurrentLoginIp() {
        return currentLoginIp;
    }

    /**
     * @param currentLoginIp the currentLoginIp to set
     */
    public void setCurrentLoginIp(String currentLoginIp) {
        this.currentLoginIp = currentLoginIp;
    }

    /**
     * @return the lastLoginDate
     */
    public Date getLastLoginDate() {
        return lastLoginDate;
    }

    /**
     * @param lastLoginDate the lastLoginDate to set
     */
    public void setLastLoginDate(Date lastLoginDate) {
        this.lastLoginDate = lastLoginDate;
    }

    /**
     * @return the currentLoginDate
     */
    public Date getCurrentLoginDate() {
        return currentLoginDate;
    }

    /**
     * @param currentLoginDate the currentLoginDate to set
     */
    public void setCurrentLoginDate(Date currentLoginDate) {
        this.currentLoginDate = currentLoginDate;
    }

    /**
     * @return the operGroupNo
     */
    public String getOperGroupNo() {
        return operGroupNo;
    }

    /**
     * @param operGroupNo the operGroupNo to set
     */
    public void setOperGroupNo(String operGroupNo) {
        this.operGroupNo = operGroupNo;
    }

    /**
     * @return the operGroupName
     */
    public String getOperGroupName() {
        return operGroupName;
    }

    /**
     * @param operGroupName the operGroupName to set
     */
    public void setOperGroupName(String operGroupName) {
        this.operGroupName = operGroupName;
    }

    /**
     * @return the tel1
     */
    public String getTel1() {
        return tel1;
    }

    /**
     * @param tel1 the tel1 to set
     */
    public void setTel1(String tel1) {
        this.tel1 = tel1;
    }

    /**
     * @return the tel2
     */
    public String getTel2() {
        return tel2;
    }

    /**
     * @param tel2 the tel2 to set
     */
    public void setTel2(String tel2) {
        this.tel2 = tel2;
    }

    /**
     * @return the hrCode
     */
    public String getHrCode() {
        return hrCode;
    }

    /**
     * @param hrCode the hrCode to set
     */
    public void setHrCode(String hrCode) {
        this.hrCode = hrCode;
    }

    /**
     * @return the duty
     */
    public String getDuty() {
        return duty;
    }

    /**
     * @param duty the duty to set
     */
    public void setDuty(String duty) {
        this.duty = duty;
    }
}
