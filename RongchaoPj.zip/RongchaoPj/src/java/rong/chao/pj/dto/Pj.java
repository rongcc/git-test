/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.pj.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("chao_pj")
public class Pj {

    @Column("pj_no")
    @Id
    private Integer pjNo;
    @Column("pj_name")
    private String pjName;
    @Column("pj_description")
    private String pjDescription;
    @Column("status")
    private int status;
    @Column("remark")
    private String remark;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;
    @Column("edit_date")
    private Date editDate;
    @Column("edit_name")
    private String editName;

    /**
     * @return the pjNo
     */
    public Integer getPjNo() {
        return pjNo;
    }

    /**
     * @param pjNo the pjNo to set
     */
    public void setPjNo(Integer pjNo) {
        this.pjNo = pjNo;
    }

    /**
     * @return the pjName
     */
    public String getPjName() {
        return pjName;
    }

    /**
     * @param pjName the pjName to set
     */
    public void setPjName(String pjName) {
        this.pjName = pjName;
    }

    /**
     * @return the pjDescription
     */
    public String getPjDescription() {
        return pjDescription;
    }

    /**
     * @param pjDescription the pjDescription to set
     */
    public void setPjDescription(String pjDescription) {
        this.pjDescription = pjDescription;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * @param remark the remark to set
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    /**
     * @return the editDate
     */
    public Date getEditDate() {
        return editDate;
    }

    /**
     * @param editDate the editDate to set
     */
    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }

    /**
     * @return the editName
     */
    public String getEditName() {
        return editName;
    }

    /**
     * @param editName the editName to set
     */
    public void setEditName(String editName) {
        this.editName = editName;
    }
}
