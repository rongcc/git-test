/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.pj.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("chao_gong")
public class Gong {

    @Id
    @Column("gong_id")
    private Integer gongId;
    @Column("gong_date")
    private Date gongDate;
    @Column("xingqi")
    private Integer xingqi;
    @Column("tianqi")
    private String tianqi;
    @Column("content")
    private String content;
    @Column("status")
    private Integer status;
    @Column("remark")
    private String remark;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;
    @Column("post_date")
    private Date postDate;
    @Column("post_name")
    private String postName;
    @Column("author_name")
    private String authorName;

    public Gong() {
    }

    public Gong(Integer gongId) {
        this.gongId = gongId;
    }

    public Gong(Integer gongId, Date gongDate) {
        this.gongId = gongId;
        this.gongDate = gongDate;
    }

    public Integer getGongId() {
        return gongId;
    }

    public void setGongId(Integer gongId) {
        this.gongId = gongId;
    }

    public Date getGongDate() {
        return gongDate;
    }

    public void setGongDate(Date gongDate) {
        this.gongDate = gongDate;
    }

    public Integer getXingqi() {
        return xingqi;
    }

    public void setXingqi(Integer xingqi) {
        this.xingqi = xingqi;
    }

    public String getTianqi() {
        return tianqi;
    }

    public void setTianqi(String tianqi) {
        this.tianqi = tianqi;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Date getInputDate() {
        return inputDate;
    }

    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    public String getInputName() {
        return inputName;
    }

    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    public Date getPostDate() {
        return postDate;
    }

    public void setPostDate(Date postDate) {
        this.postDate = postDate;
    }

    public String getPostName() {
        return postName;
    }

    public void setPostName(String postName) {
        this.postName = postName;
    }

    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (gongId != null ? gongId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Gong)) {
            return false;
        }
        Gong other = (Gong) object;
        if ((this.gongId == null && other.gongId != null) || (this.gongId != null && !this.gongId.equals(other.gongId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "rong.chao.pj.dto.Gong[gongId=" + gongId + "]";
    }
}
