/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.car.util;

import java.net.URL;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

/**
 *
 * @author zhourongchao
 */
public class CachingServiceLocator {

    private InitialContext ic;
    private Map cache;
    private static CachingServiceLocator me;

    static {
        try {
            me = new CachingServiceLocator();
        } catch (NamingException se) {
            throw new RuntimeException(se);
        }
    }

    private CachingServiceLocator() throws NamingException {
        ic = new InitialContext();
        cache = Collections.synchronizedMap(new HashMap());
    }

    public static CachingServiceLocator getInstance() {
        return me;
    }

    private Object lookup(String jndiName) throws NamingException {
        Object cachedObj = cache.get(jndiName);
        if (cachedObj == null) {
            cachedObj = ic.lookup(jndiName);
            cache.put(jndiName, cachedObj);
        }
        return cachedObj;
    }

    /**
     * This method obtains the datasource
     * @return the DataSource corresponding to the name parameter
     */
    public DataSource getDataSource(String dataSourceName) throws NamingException {
        return (DataSource) lookup(dataSourceName);
    }

    /**
     * @return the URL value corresponding
     * to the env entry name.
     */
    public URL getUrl(String envName) throws NamingException {
        return (URL) lookup(envName);
    }

    /**
     * @return the boolean value corresponding
     * to the env entry such as SEND_CONFIRMATION_MAIL property.
     */
    public boolean getBoolean(String envName) throws NamingException {
        Boolean bool = (Boolean) lookup(envName);
        return bool.booleanValue();
    }

    /**
     * @return the String value corresponding
     * to the env entry name.
     */
    public String getString(String envName) throws NamingException {
        return (String) lookup(envName);
    }
}
