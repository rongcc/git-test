/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.car.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;
import javax.sql.DataSource;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rong.gwm.ts.dto.BfhDc;
import rong.gwm.ts.dto.BfhYanzhengJilu;

/**
 *
 * @author zhourongchao
 */
public class BfhYanzhengJiluService {

    /**
     * get the next order no.
     */
    public String getNextNo(DataSource ds) {
        String nextNo = "";
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            StringBuffer sb = new StringBuffer();
            Calendar rightNow = Calendar.getInstance();
            int y = rightNow.get(Calendar.YEAR);
            conn = ds.getConnection();
            //取原表
            String sqlStr = "select max(yanzheng_no) from bfh_yanzheng_jilu";
            pStmt = conn.prepareStatement(sqlStr);
            rs = pStmt.executeQuery();
            String no = null;
            if (rs.next()) {
                no = rs.getString(1);
            }
            //根据查询结果运算
            if (no != null && no.length() > 4) {
                int lastYear = 2000 + Integer.parseInt(no.substring(2, 4));
                if (y > lastYear) {
                    nextNo = sb.append("YZ").append(String.valueOf(y).substring(2)).append("000001").toString();
                } else {
                    int ino = Integer.parseInt(no.substring(4));
                    nextNo = sb.append("YZ").append(String.valueOf(y).substring(2)).append(String.valueOf(1000001 + ino).substring(1)).toString();
                }
            } else {
                nextNo = sb.append("YZ").append(String.valueOf(y).substring(2)).append("000001").toString();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return nextNo;
    }

    /**
     * 获得指定验证记录的对策编号。
     * @param ds
     * @param orderNo
     * @return
     */
    public String getDcNo(DataSource ds, String orderNo) {
        String dStr = null;
        BfhYanzhengJilu cd = null;
        try {
            Dao dao = new NutDao(ds);
            cd = dao.fetch(BfhYanzhengJilu.class, orderNo);
            dStr = cd.getSourceOrder();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return dStr;
    }

    /**
     * 获得指定验证记录的不符合项编号。
     * @param ds
     * @param orderNo
     * @return
     */
    public String getBfhNo(DataSource ds, String orderNo) {
        String dStr = null;
        BfhYanzhengJilu cd = null;
        try {
            Dao dao = new NutDao(ds);
            cd = dao.fetch(BfhYanzhengJilu.class, orderNo);
            String dcNo = cd.getSourceOrder();
            BfhDc dc = dao.fetch(BfhDc.class, dcNo);
            dStr = dc.getSourceOrder();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return dStr;
    }
}
