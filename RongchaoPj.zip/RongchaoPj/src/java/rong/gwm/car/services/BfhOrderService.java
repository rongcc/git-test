/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.car.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.sql.DataSource;
import org.nutz.dao.Dao;
import org.nutz.dao.Sqls;
import org.nutz.dao.impl.NutDao;
import org.nutz.dao.sql.Sql;
import rong.gwm.ts.dto.BfhOrder;
import rong.gwm.ts.dto.SearchAdItem;
import rong.gwm.ts.util.DadaoUse;

/**
 *
 * @author zhourongchao
 */
public class BfhOrderService {

    /**
     * 新增
     * @param ds
     * @param order
     * @return
     */
    public String create(DataSource ds, BfhOrder order) {
        //
        if (order == null) {
            return null;
        }
        if (order.getBfhNo() == null || order.getBfhNo().equals("") || order.getBfhDescription() == null) {
            return "-1";
        }
        //
        String orderNo = "";
        try {
            Dao dao = new NutDao(ds);
            BfhOrder po = dao.insert(order);
            orderNo = po.getBfhNo();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return orderNo;

    }

    /**
     * 修改
     * @param ds
     * @param order
     * @return
     */
    public String edit(DataSource ds, BfhOrder order) {
        //
        if (order == null) {
            return null;
        }
        if (order.getBfhNo() == null || order.getBfhNo().equals("") || order.getBfhDescription().length() < 1) {
            return "-1";
        }
        //
        String orderNo = "";
        try {
            Dao dao = new NutDao(ds);
            //更新主体
            int upi = dao.update(order);
            //更新主体成功即返回编码
            if (upi == 1) {
                orderNo = order.getBfhNo();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return orderNo;
    }

    /**
     * 删除status-1
     * @param ds
     * @param order
     * @return
     */
    public int destroy(DataSource ds, BfhOrder order) {
        //
        if (order == null) {
            return -2;
        }
        if (order.getBfhNo() == null || order.getBfhNo().equals("")) {
            return -1;
        }
        //
        int dt = 0;
        try {
            Dao dao = new NutDao(ds);
            Sql sql = Sqls.create("update bfh_order set status = '-1' where bfh_no=@bfh_no");
            sql.params().set("bfh_no", order.getBfhNo());
            dao.execute(sql);
            dt = 1;
        } catch (Exception e) {
            dt = -3;
            e.printStackTrace();
        }
        return dt;
    }

    /**
     *
     * @param ds
     * @param orderNo
     * @return
     */
    public BfhOrder findOrder(DataSource ds, String orderNo) {
        BfhOrder order = null;
        try {
            Dao dao = new NutDao(ds);
            order = dao.fetch(BfhOrder.class, orderNo);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return order;
    }

    /**
     *
     * @param ds
     * @return
     */
    public List findAll(DataSource ds) {
        List al = null;
        try {
            Dao dao = new NutDao(ds);
            al = dao.query(BfhOrder.class, null, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return al;
    }

    /**
     * get the next order no.
     */
    public String getNextNo(DataSource ds) {
        String nextNo = "";
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            StringBuffer sb = new StringBuffer();
            Calendar rightNow = Calendar.getInstance();
            int y = rightNow.get(Calendar.YEAR);
            conn = ds.getConnection();
            //取原表
            String sqlStr = "select max(bfh_no) from bfh_order";
            pStmt = conn.prepareStatement(sqlStr);
            rs = pStmt.executeQuery();
            String no = null;
            if (rs.next()) {
                no = rs.getString(1);
            }
            //根据查询结果运算
            if (no != null && no.length() > 4) {
                int lastYear = 2000 + Integer.parseInt(no.substring(2, 4));
                if (y > lastYear) {
                    nextNo = sb.append("BF").append(String.valueOf(y).substring(2)).append("000001").toString();
                } else {
                    int ino = Integer.parseInt(no.substring(4));
                    nextNo = sb.append("BF").append(String.valueOf(y).substring(2)).append(String.valueOf(1000001 + ino).substring(1)).toString();
                }
            } else {
                nextNo = sb.append("BF").append(String.valueOf(y).substring(2)).append("000001").toString();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return nextNo;
    }

    /**
     * 此不符合项是否关闭
     * @param ds
     * @param orderNo
     * @return
     */
    public boolean isClose(DataSource ds, String orderNo) {
        boolean boo = false;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            //
            String sqlStr = "SELECT is_close FROM bfh_order where bfh_no='" + orderNo + "' and status<>-1";
            pStmt = conn.prepareStatement(sqlStr);
            rs = pStmt.executeQuery();
            if (rs.next()) {
                boo = rs.getBoolean(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return boo;
    }

    /**
     * 此不符合项是否结题
     * @param ds
     * @param orderNo
     * @return
     */
    public boolean isJieti(DataSource ds, String orderNo) {
        boolean boo = false;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            //
            String sqlStr = "SELECT is_jieti FROM bfh_order where bfh_no='" + orderNo + "' and status<>-1";
            pStmt = conn.prepareStatement(sqlStr);
            rs = pStmt.executeQuery();
            if (rs.next()) {
                boo = rs.getBoolean(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return boo;
    }

    /**
     * 获得该不符合项的所有对策
     * @param ds
     * @param orderNo
     * @return
     */
    public List getDcList(DataSource ds, String orderNo) {
        List dList = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            //
            String sqlStr = "SELECT dc_no FROM bfh_dc where source_order ='" + orderNo + "' and status<>-1";
            pStmt = conn.prepareStatement(sqlStr);
            rs = pStmt.executeQuery();
            dList = new ArrayList();
            while (rs.next()) {
                dList.add(rs.getString(1));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return dList;
    }

    /**
     * 获得该不符合项的所有结题后验证。此方法尚不可用。
     * @param ds
     * @param orderNo
     * @return
     */
    public List getJietihouYanzhengList(DataSource ds, String orderNo) {
        List dList = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            //
            String sqlStr = "SELECT yanzheng_no FROM bfh_yanzheng_jilu where is_jietihou is true and bfh_no='" + orderNo + "' and status<>-1";
            pStmt = conn.prepareStatement(sqlStr);
            rs = pStmt.executeQuery();
            dList = new ArrayList();
            while (rs.next()) {
                dList.add(rs.getString(1));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return dList;
    }

    /**
     * 获得最后的结题后验证效果。
     * @param ds
     * @param orderNo
     * @return
     */
    public String getJietihouYanzhengXiaoguo(DataSource ds, String orderNo) {
        String dStr = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            //
            String sqlStr = "select yanzheng_xiaoguo from bfh_yanzheng_jilu "
                    + "where source_order in(select dc_no from bfh_dc where source_order=?)"
                    + " and status<>-1 and is_jietihou=1 order by input_date desc";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, orderNo);
            rs = pStmt.executeQuery();
            if (rs.next()) {
                dStr = rs.getString(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return dStr;
    }

    /**
     * 获得该不符合项的所有结题申请单
     * @param ds
     * @param orderNo
     * @return
     */
    public List getJietiSqList(DataSource ds, String orderNo) {
        List dList = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            //
            String sqlStr = "SELECT jieti_sq_no FROM bfh_jieti_sq where source_order='" + orderNo + "' and status<>-1";
            pStmt = conn.prepareStatement(sqlStr);
            rs = pStmt.executeQuery();
            dList = new ArrayList();
            while (rs.next()) {
                dList.add(rs.getString(1));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return dList;
    }

    /**
     * 获得不符合项的审核名称。
     * @param ds
     * @param orderNo
     * @return
     */
    public String getShenheName(DataSource ds, String orderNo) {
        String dStr = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            //
            String sqlStr = "select shenhe_name from shenhe_jihua where "
                    + "shenhe_jihua_no =( SELECT source_order FROM shenhe_baogao where "
                    + "shenhe_baogao_no =(select source_order from bfh_order "
                    + "where bfh_no='" + orderNo + "' and status<>-1))";
            pStmt = conn.prepareStatement(sqlStr);
            rs = pStmt.executeQuery();
            if (rs.next()) {
                dStr = rs.getString(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return dStr;
    }

    /**
     * 综合查询获得不符合项编号的列表。
     * @param ds
     * @param tName
     * @param cName
     * @param cValue
     * @return
     */
    public List searchSyn(DataSource ds, String tName, String cName, String cValue) {
        List dList = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            //
            String sqlStr = "";
            if (tName.equals("bfh_order")) {
                sqlStr = "select bfh_no from bfh_order where " + cName + " like '%" + cValue + "%' and status<>-1 order by bfh_no desc";
            } else if (tName.equals("bfh_dc")) {
                sqlStr = "select source_order from bfh_dc where " + cName + " like '%" + cValue + "%' and status<>-1 order by source_order desc";
            } else if (tName.equals("bfh_dc_bg")) {
                sqlStr = "select source_order from bfh_dc where dc_no in("
                        + "select dc_no from bfh_dc_bg where " + cName + " like '%" + cValue + "%' and status<>-1"
                        + ")  order by source_order desc";
            } else if (tName.equals("bfh_yanzheng_jilu")) {
                sqlStr = "select source_order from bfh_dc where dc_no in("
                        + "select source_order from bfh_yanzheng_jilu  where " + cName + " like '%" + cValue + "%' and status<>-1"
                        + ")  order by source_order desc";
            } else if (tName.equals("bfh_jindu_jilu")) {
                sqlStr = "select bfh_no from bfh_jindu_jilu  where " + cName + " like '%" + cValue + "%' and status<>-1 order by bfh_no desc";
            } else if (tName.equals("bfh_jieti_sq")) {
                sqlStr = "select source_order from bfh_jieti_sq  where " + cName + " like '%" + cValue + "%' and status<>-1 order by source_order desc";
            }
            pStmt = conn.prepareStatement(sqlStr);
            rs = pStmt.executeQuery();
            dList = new ArrayList();
            while (rs.next()) {
                dList.add(rs.getString(1));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return dList;
    }

    /**
     * 综合多表多字段的高级查询，取得多个条件结果集的交集或并集。
     * @param ds
     * @param itemList
     * @return
     */
    public List searchSynAd(DataSource ds, List itemList) {
        if (ds == null || itemList == null) {
            return null;
        }
        List dList = null;
        try {
            SearchAdItem item = null;
            for (int i = 0; i < itemList.size(); i++) {
                item = (SearchAdItem) itemList.get(i);
                if (i == 0) {
                    dList = this.searchSynAdItem(ds, item);
                } else {
                    if (item.getAo().equals("or")) {
                        dList.addAll(this.searchSynAdItem(ds, item));
                    } else {
                        dList.retainAll(this.searchSynAdItem(ds, item));
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return dList;
    }

    /**
     *
     * @param ds
     * @param item
     * @return
     */
    public List searchSynAdItem(DataSource ds, SearchAdItem item) {
        if (ds == null || item == null) {
            return null;
        }
        List dList = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        String tName = "";
        String cName = "";
        String bj = "";
        String cValue = "";
        String kwType = "";
        //字段-比较符-值。
        String cNBV = "";
        try {
            conn = ds.getConnection();
            //
            tName = item.getTbCol().substring(0, item.getTbCol().indexOf("."));
            cName = item.getTbCol().substring(item.getTbCol().indexOf(".") + 1);
            bj = item.getBj();
            cValue = item.getKw().toString();
            kwType = item.getKwType();
            if (kwType.equals("Date")) {
                Date myDate = (Date) item.getKw();
                DadaoUse dUse = new DadaoUse();
                cValue = dUse.formatRiQiDate(myDate);
            }
            if (bj.equals("like")) {
                cNBV = "" + cName + " like '%" + cValue + "%'";
            } else if (bj.equals("=")) {
                cNBV = "" + cName + " = '" + cValue + "'";
            } else if (bj.equals("DaYu")) {
                if (kwType.equals("Integer")) {
                    cNBV = "" + cName + " > " + cValue + "";
                } else {
                    cNBV = "" + cName + " > '" + cValue + "'";
                }
            } else if (bj.equals("DaYuDengYu")) {
                if (kwType.equals("Integer")) {
                    cNBV = "" + cName + " >= " + cValue + "";
                } else {
                    cNBV = "" + cName + " >= '" + cValue + "'";
                }
            } else if (bj.equals("XiaoYu")) {
                if (kwType.equals("Integer")) {
                    cNBV = "" + cName + " < " + cValue + "";
                } else {
                    cNBV = "" + cName + " < '" + cValue + "'";
                }
            } else if (bj.equals("XiaoYuDengYu")) {
                if (kwType.equals("Integer")) {
                    cNBV = "" + cName + " <= " + cValue + "";
                } else {
                    cNBV = "" + cName + " <= '" + cValue + "'";
                }
            } else if (bj.equals("!=")) {
                if (kwType.equals("Integer")) {
                    cNBV = "" + cName + " <> " + cValue + "";
                } else {
                    cNBV = "" + cName + " <> '" + cValue + "'";
                }
            } else if (bj.equals("in")) {
                cNBV = "" + cName + " in( " + cValue + ")";
            } else if (bj.equals("not in")) {
                cNBV = "" + cName + " not in( " + cValue + ")";
            } else {
                cNBV = cName + bj + cValue;
            }
            //
            String sqlStr = "";
            if (tName.equals("bfh_order")) {
                sqlStr = "select bfh_no from bfh_order where " + cNBV + "  and status<>-1";
            } else if (tName.equals("bfh_dc")) {
                sqlStr = "select source_order from bfh_dc where " + cNBV + " and status<>-1";
            } else if (tName.equals("bfh_dc_bg")) {
                sqlStr = "select source_order from bfh_dc where dc_no in("
                        + "select dc_no from bfh_dc_bg where " + cNBV + " and status<>-1"
                        + ")";
            } else if (tName.equals("bfh_yanzheng_jilu")) {
                sqlStr = "select source_order from bfh_dc where dc_no in("
                        + "select source_order from bfh_yanzheng_jilu  where " + cNBV + " and status<>-1"
                        + ")";
            } else if (tName.equals("bfh_jindu_jilu")) {
                sqlStr = "select bfh_no from bfh_jindu_jilu  where " + cNBV + " and status<>-1";
            } else if (tName.equals("bfh_jieti_sq")) {
                sqlStr = "select source_order from bfh_jieti_sq  where " + cNBV + " and status<>-1";
            }
            pStmt = conn.prepareStatement(sqlStr);
            rs = pStmt.executeQuery();
            dList = new ArrayList();
            while (rs.next()) {
                dList.add(rs.getString(1));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return dList;
    }

    /**
     * 高级查询。此功能暂未实行。
     * @param ds
     * @param itemList
     * @return
     */
    public List searchAd(DataSource ds, List itemList) {
        List dList = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            //
            SearchAdItem item = null;
            String sqlStr = "";
            for (int i = 0; i < itemList.size(); i++) {
                item = (SearchAdItem) itemList.get(i);
                String aoStr = item.getAo();
                String khStr = item.getKh();
                String tbColStr = item.getTbCol();
                String bjStr = item.getBj();
                String kwType = item.getKwType();
                //根据kwType内容取值。字符串，日期，整数。
                String kwStr = null;
                Date kwDate = null;
                Integer kwInteger = null;
                if (kwType.equals("String")) {
                    kwStr = (String) item.getKw();
                } else if (kwType.equals("Date")) {
                    kwDate = (Date) item.getKw();
                } else if (kwType.equals("Integer")) {
                    kwInteger = (Integer) item.getKw();
                }
                //
                sqlStr = "" + aoStr + khStr + tbColStr;
                System.out.println(i + "行" + sqlStr);
                //
            }
            //
            System.out.println("SQL语句：" + sqlStr);
            //
            pStmt = conn.prepareStatement(sqlStr);
            rs = pStmt.executeQuery();
            dList = new ArrayList();
            while (rs.next()) {
                dList.add(rs.getString(1));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return dList;
    }
}
