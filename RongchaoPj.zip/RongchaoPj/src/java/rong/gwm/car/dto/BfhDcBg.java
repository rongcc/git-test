/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.car.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Name;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("bfh_dc_bg")
public class BfhDcBg {

    @Column("dc_bg_no")
    @Name
    private String dcBgNo;
    @Column("dc_no")
    private String dcNo;
    @Column("bg_item")
    private String bgItem;
    @Column("bg_date")
    private Date bgDate;
    @Column("bg_yuanyin")
    private String bgYuanyin;
    @Column("bgh_jihua_date")
    private Date bghJihuaDate;
    @Column("remark")
    private String remark;
    @Column("status")
    private int status;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;
    @Column("edit_date")
    private Date editDate;
    @Column("edit_name")
    private String editName;
    @Column("post_date")
    private Date postDate;
    @Column("post_name")
    private String postName;
    @Column("post2_date")
    private Date post2Date;
    @Column("post2_name")
    private String post2Name;

    /**
     * @return the dcBgNo
     */
    public String getDcBgNo() {
        return dcBgNo;
    }

    /**
     * @param dcBgNo the dcBgNo to set
     */
    public void setDcBgNo(String dcBgNo) {
        this.dcBgNo = dcBgNo;
    }

    /**
     * @return the dcNo
     */
    public String getDcNo() {
        return dcNo;
    }

    /**
     * @param dcNo the dcNo to set
     */
    public void setDcNo(String dcNo) {
        this.dcNo = dcNo;
    }

    /**
     * @return the bgItem
     */
    public String getBgItem() {
        return bgItem;
    }

    /**
     * @param bgItem the bgItem to set
     */
    public void setBgItem(String bgItem) {
        this.bgItem = bgItem;
    }

    /**
     * @return the bgDate
     */
    public Date getBgDate() {
        return bgDate;
    }

    /**
     * @param bgDate the bgDate to set
     */
    public void setBgDate(Date bgDate) {
        this.bgDate = bgDate;
    }

    /**
     * @return the bgYuanyin
     */
    public String getBgYuanyin() {
        return bgYuanyin;
    }

    /**
     * @param bgYuanyin the bgYuanyin to set
     */
    public void setBgYuanyin(String bgYuanyin) {
        this.bgYuanyin = bgYuanyin;
    }

    /**
     * @return the bghJihuaDate
     */
    public Date getBghJihuaDate() {
        return bghJihuaDate;
    }

    /**
     * @param bghJihuaDate the bghJihuaDate to set
     */
    public void setBghJihuaDate(Date bghJihuaDate) {
        this.bghJihuaDate = bghJihuaDate;
    }

    /**
     * @return the remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * @param remark the remark to set
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    /**
     * @return the editDate
     */
    public Date getEditDate() {
        return editDate;
    }

    /**
     * @param editDate the editDate to set
     */
    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }

    /**
     * @return the editName
     */
    public String getEditName() {
        return editName;
    }

    /**
     * @param editName the editName to set
     */
    public void setEditName(String editName) {
        this.editName = editName;
    }

    /**
     * @return the postDate
     */
    public Date getPostDate() {
        return postDate;
    }

    /**
     * @param postDate the postDate to set
     */
    public void setPostDate(Date postDate) {
        this.postDate = postDate;
    }

    /**
     * @return the postName
     */
    public String getPostName() {
        return postName;
    }

    /**
     * @param postName the postName to set
     */
    public void setPostName(String postName) {
        this.postName = postName;
    }

    /**
     * @return the post2Date
     */
    public Date getPost2Date() {
        return post2Date;
    }

    /**
     * @param post2Date the post2Date to set
     */
    public void setPost2Date(Date post2Date) {
        this.post2Date = post2Date;
    }

    /**
     * @return the post2Name
     */
    public String getPost2Name() {
        return post2Name;
    }

    /**
     * @param post2Name the post2Name to set
     */
    public void setPost2Name(String post2Name) {
        this.post2Name = post2Name;
    }

 
}
