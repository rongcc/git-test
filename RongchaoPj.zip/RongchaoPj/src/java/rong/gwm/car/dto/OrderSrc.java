/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package rong.gwm.car.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("order_src")
public class OrderSrc {

    @Column("id")
    @Id
    private Integer id;
    @Column("order_no")
    private String orderNo;
    @Column("order_type")
    private String orderType;
    @Column("order_start")
    private String orderStart;
    @Column("input_date")
    private Date inputDate;
    @Column("src_order")
    private String srcOrder;

    /**
     * @return the id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return the orderNo
     */
    public String getOrderNo() {
        return orderNo;
    }

    /**
     * @param orderNo the orderNo to set
     */
    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    /**
     * @return the orderType
     */
    public String getOrderType() {
        return orderType;
    }

    /**
     * @param orderType the orderType to set
     */
    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    /**
     * @return the orderStart
     */
    public String getOrderStart() {
        return orderStart;
    }

    /**
     * @param orderStart the orderStart to set
     */
    public void setOrderStart(String orderStart) {
        this.orderStart = orderStart;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the srcOrder
     */
    public String getSrcOrder() {
        return srcOrder;
    }

    /**
     * @param srcOrder the srcOrder to set
     */
    public void setSrcOrder(String srcOrder) {
        this.srcOrder = srcOrder;
    }

}
