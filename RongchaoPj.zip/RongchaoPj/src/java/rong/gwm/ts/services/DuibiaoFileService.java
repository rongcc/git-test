/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.List;
import javax.sql.DataSource;
import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rong.gwm.ts.dto.DuibiaoFile;
import rong.gwm.ts.dto.DuibiaoFileItem;

/**
 *
 * @author zhourongchao
 */
public class DuibiaoFileService {

    /**
     * 获取一条item
     * @param ds
     * @param codeType
     * @param code
     * @return
     */
    public DuibiaoFileItem fetchItem(DataSource ds, String codeType, String code) {
        DuibiaoFileItem cd = null;
        try {
            Dao dao = new NutDao(ds);
            cd = dao.fetchx(DuibiaoFileItem.class, codeType, code);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cd;
    }

    /**
     * 删除一条item
     * @param ds
     * @param cd
     * @return
     */
    public int deleteItem(DataSource ds, DuibiaoFileItem cd) {
        int di = 0;
        try {
            Dao dao = new NutDao(ds);
            di = dao.deletex(DuibiaoFileItem.class, cd.getDuibiaoId(), cd.getItemNo());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return di;
    }

    /**
     * 获取下一个item的顺序号
     * @param ds
     * @param order
     * @return
     */
    public int getNextItemNo(DataSource ds, DuibiaoFile order) {
        int di = 0;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            String sqlStr = "select max(item_no) from duibiao_file_item where duibiao_id=?";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setInt(1, order.getDuibiaoId());
            rs = pStmt.executeQuery();
            if (rs.next()) {
                di = rs.getInt(1) + 1;
                //System.out.println(rs.getInt(1)+"rs位置：" + di);
            }
            if (di == 0) {
                di = 1;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return di;
    }

    /**
     * 获取下一个item的名称
     * @param ds
     * @param order
     * @param fileName
     * @return
     */
    public String getNextItemName(DataSource ds, DuibiaoFile order, String fileName) {
        String dstr = "";
        try {
            //dstr = order.getDuibiaoId() + "-" + this.getNextItemNo(ds, order) + "-" + fileName;
            int lasti = fileName.lastIndexOf(".");
            Calendar rightNow = Calendar.getInstance();
            int y = rightNow.get(Calendar.YEAR);
            System.out.println("lasti:" + lasti);
            dstr = order.getDuibiaoId() + "" + String.valueOf(y) + this.getNextItemNo(ds, order) + "" + fileName.substring(lasti);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return dstr;
    }

    /**
     * 插入一条item记录
     * @param ds
     * @param item
     * @return
     */
    public int addItem(DataSource ds, DuibiaoFileItem item) {
        int adi = 0;
        try {
            Dao dao = new NutDao(ds);
            dao.insert(item);
            adi = 1;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return adi;
    }

    /**
     * 获取此单号的item列表
     * @param ds
     * @param duibiaoId
     * @return
     */
    public List getItemList(DataSource ds, int duibiaoId) {
        List al = null;
        try {
            Dao dao = new NutDao(ds);
            al = dao.query(DuibiaoFileItem.class, Cnd.where("duibiao_id", "=", duibiaoId), null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return al;
    }
}
