/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.sql.DataSource;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rong.gwm.ts.dto.AccessRightReadySub;

/**
 *
 * @author zhourongchao
 */
public class AccessRightReadySubService {

    /**
     * 获取一个用户对一个数据项的消息。
     * @param ds
     * @param codeType
     * @param code
     * @return
     */
    public AccessRightReadySub fetch(DataSource ds, String codeType, String code) {
        AccessRightReadySub cd = null;
        try {
            Dao dao = new NutDao(ds);
            cd = dao.fetchx(AccessRightReadySub.class, codeType, code);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cd;
    }

    /**
     * 删除一个用户对一个数据项的消息。
     * @param ds
     * @param cd
     * @return
     */
    public int delete(DataSource ds, AccessRightReadySub cd) {
        int di = 0;
        try {
            Dao dao = new NutDao(ds);
            di = dao.deletex(AccessRightReadySub.class, cd.getOperNo(), cd.getAccessPage());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return di;
    }

    /**
     * 检查某用户在某数据项上的某权限消息是否订阅。
     * @param ds
     * @param operNo
     * @param accessPage
     * @param doRight
     * @return
     */
    public boolean checkSub(DataSource ds, String operNo, String accessPage, String doRight) {
        boolean boo = false;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            String sqlStr = "select " + doRight + " FROM access_right_ready_sub where oper_no=? and access_page=? ";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, operNo);
            pStmt.setString(2, accessPage);
            rs = pStmt.executeQuery();
            String myRight = null;
            if (rs.next()) {
                myRight = rs.getString(1);
            }
            if (new String("S").equals(myRight)) {
                boo = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return boo;
    }
}
