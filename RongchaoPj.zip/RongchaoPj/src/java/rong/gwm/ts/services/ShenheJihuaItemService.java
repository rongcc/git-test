/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.sql.DataSource;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rong.gwm.ts.dto.ShenheJihuaItem;

/**
 *
 * @author zhourongchao
 */
public class ShenheJihuaItemService {

    /**
     * 获取一条审核计划的具体安排
     * @param ds
     * @param codeType
     * @param code
     * @return
     */
    public ShenheJihuaItem fetch(DataSource ds, int codeType, int code) {
        ShenheJihuaItem cd = null;
        try {
            Dao dao = new NutDao(ds);
            cd = dao.fetchx(ShenheJihuaItem.class, codeType, code);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cd;
    }

    /**
     * 删除一条审核计划的具体安排
     * @param ds
     * @param cd
     * @return
     */
    public int delete(DataSource ds, ShenheJihuaItem cd) {
        int di = 0;
        try {
            Dao dao = new NutDao(ds);
            di = dao.deletex(ShenheJihuaItem.class, cd.getItemNo(), cd.getShenheJihuaNo());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return di;
    }

    /**
     * 删除计划的具体安排
     * @param ds
     * @param cd
     * @return
     */
    public int deleteOrderItems(DataSource ds, int orderNo) {
        int di = 0;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            String sqlStr = "delete FROM shenhe_jihua_item where shenhe_jihua_no=? ";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setInt(1, orderNo);
            di = pStmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return di;
    }
}
