/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.services;

import java.util.List;
import javax.sql.DataSource;
import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rong.gwm.ts.dto.AccessRightTake;

/**
 *
 * @author zhourongchao
 */
public class AccessRightTakeService {

    public AccessRightTake findAccessRightTake(DataSource ds, String orderNo) {
        AccessRightTake order = null;
        try {
            Dao dao = new NutDao(ds);
            order = dao.fetch(AccessRightTake.class, orderNo);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return order;
    }

    /*
    public String getTakeName(DataSource ds, String orderNo, String takeNo) {
    String dStr = "";
    AccessRightTake order = null;
    try {
    Dao dao = new NutDao(ds);
    order = dao.fetch(AccessRightTake.class, orderNo);
    if (takeNo.equals("take1")) {
    dStr = order.getTake1Name();
    } else if (takeNo.equals("take2")) {
    dStr = order.getTake2Name();
    } else if (takeNo.equals("take3")) {
    dStr = order.getTake3Name();
    } else if (takeNo.equals("take4")) {
    dStr = order.getTake4Name();
    } else if (takeNo.equals("take5")) {
    dStr = order.getTake5Name();
    }
    } catch (Exception e) {
    e.printStackTrace();
    }
    return dStr;
    }*/
}
