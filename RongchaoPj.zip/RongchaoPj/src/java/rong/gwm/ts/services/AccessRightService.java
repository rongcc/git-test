/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rong.gwm.ts.dto.AccessRight;

/**
 *
 * @author zhourongchao
 */
public class AccessRightService {

    /**
     * 获取一个用户对一个页面的权限
     * @param ds
     * @param codeType
     * @param code
     * @return
     */
    public AccessRight fetch(DataSource ds, String codeType, String code) {
        AccessRight cd = null;
        try {
            Dao dao = new NutDao(ds);
            cd = dao.fetchx(AccessRight.class, codeType, code);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cd;
    }

    /**
     * 删除一个用户对一个页面的权限
     * @param ds
     * @param cd
     * @return
     */
    public int delete(DataSource ds, AccessRight cd) {
        int di = 0;
        try {
            Dao dao = new NutDao(ds);
            di = dao.deletex(AccessRight.class, cd.getOperNo(), cd.getAccessPage());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return di;
    }

    /**
     * 获取用户的数据范围
     * @param ds
     * @param operNo
     * @param accessPage
     * @return
     */
    public int getDataScope(DataSource ds, String operNo, String accessPage) {
        return fetch(ds, operNo, accessPage).getDataScope();
    }

    /**
     * 检查某用户在某数据项上的某权限是否有效。
     * @param ds
     * @param operNo
     * @param accessPage
     * @param doRight
     * @return
     */
    public boolean checkRight(DataSource ds, String operNo, String accessPage, String doRight) {
        boolean boo = false;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            String sqlStr = "select " + doRight + " FROM access_right where oper_no=? and access_page=? ";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, operNo);
            pStmt.setString(2, accessPage);
            rs = pStmt.executeQuery();
            String myRight = null;
            if (rs.next()) {
                myRight = rs.getString(1);
            }
            if (myRight == null) {
                boo = false;
            } else if (new String("Y").equals(myRight)) {
                boo = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return boo;
    }

    /**
     * 获得有审核权限的用户。
     * @param ds
     * @param accessPage
     * @return
     */
    public List getPostNames(DataSource ds, String accessPage) {
        List aList = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            String sqlStr = "SELECT oper_no FROM gwm_ts.access_right where access_page=? and post_right='Y' ";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, accessPage);
            rs = pStmt.executeQuery();
            aList = new ArrayList();
            while (rs.next()) {
                aList.add(rs.getString(1));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return aList;
    }

    /**
     * 获得有审核权限的用户。限定部门。
     * @param ds
     * @param accessPage
     * @param deptNo
     * @return
     */
    public List getPostNames(DataSource ds, String accessPage, String deptNo) {
        List aList = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            String sqlStr = "SELECT oper_no FROM gwm_ts.access_right where access_page=? and post_right='Y' "
                    + " and oper_no in(select oper_no from operator where dept_no=? and status!=-1)";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, accessPage);
            pStmt.setString(2, deptNo);
            rs = pStmt.executeQuery();
            aList = new ArrayList();
            while (rs.next()) {
                aList.add(rs.getString(1));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return aList;
    }

    /**
     * 获得有审核权限的用户。限定部门。限定姓名包含字符。
     * @param ds
     * @param accessPage
     * @param deptNo
     * @param kName
     * @return
     */
    public List getPostNames(DataSource ds, String accessPage, String deptNo, String kName) {
        List aList = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            String sqlStr = "SELECT oper_no FROM gwm_ts.access_right where access_page=? and post_right='Y' "
                    + " and oper_no in(select oper_no from operator where dept_no=? and oper_name like '%" + kName + "%' and status!=-1)";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, accessPage);
            pStmt.setString(2, deptNo);
            rs = pStmt.executeQuery();
            aList = new ArrayList();
            while (rs.next()) {
                aList.add(rs.getString(1));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return aList;
    }

    /**
     * 获得有批准权限的用户。
     * @param ds
     * @param accessPage
     * @return
     */
    public List getPost2Names(DataSource ds, String accessPage) {
        List aList = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            String sqlStr = "SELECT oper_no FROM gwm_ts.access_right where access_page=? and post2_right='Y' ";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, accessPage);
            rs = pStmt.executeQuery();
            aList = new ArrayList();
            while (rs.next()) {
                aList.add(rs.getString(1));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return aList;
    }

    /**
     * 获得有批准权限的用户。限定部门。
     * @param ds
     * @param accessPage
     * @param deptNo
     * @return
     */
    public List getPost2Names(DataSource ds, String accessPage, String deptNo) {
        List aList = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            String sqlStr = "SELECT oper_no FROM gwm_ts.access_right where access_page=? and post2_right='Y' "
                    + " and oper_no in(select oper_no from operator where dept_no=? and status!=-1)";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, accessPage);
            pStmt.setString(2, deptNo);
            rs = pStmt.executeQuery();
            aList = new ArrayList();
            while (rs.next()) {
                aList.add(rs.getString(1));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return aList;
    }

    /**
     * 获取有批准权限的用户。限定部门。限定姓名包含字符。
     * @param ds
     * @param accessPage
     * @param deptNo
     * @param kName
     * @return
     */
    public List getPost2Names(DataSource ds, String accessPage, String deptNo, String kName) {
        List aList = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            String sqlStr = "SELECT oper_no FROM gwm_ts.access_right where access_page=? and post2_right='Y' "
                    + " and oper_no in(select oper_no from operator where dept_no=? and oper_name like '%" + kName + "%' and status!=-1)";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, accessPage);
            pStmt.setString(2, deptNo);
            rs = pStmt.executeQuery();
            aList = new ArrayList();
            while (rs.next()) {
                aList.add(rs.getString(1));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return aList;
    }
}
