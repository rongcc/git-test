/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.services;

import java.util.List;
import javax.sql.DataSource;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rong.gwm.ts.dto.QPProblemInfo;

/**
 *
 * @author zhourongchao
 */
public class QPProblemInfoService {

    /**
     *
     * @param ds2
     * @param orderNo
     * @return
     */
    public QPProblemInfo findOrder(DataSource ds2, String orderNo) {
        QPProblemInfo order = null;
        try {
            Dao dao = new NutDao(ds2);
            order = dao.fetch(QPProblemInfo.class, orderNo);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return order;
    }

    /**
     *
     * @param ds2
     * @return
     */
    public List findAll(DataSource ds2) {
        List al = null;
        try {
            Dao dao = new NutDao(ds2);
            al = dao.query(QPProblemInfo.class, null, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return al;
    }
}
