/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.services;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.sql.DataSource;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rong.gwm.ts.dto.DeptDefen;
import rong.gwm.ts.dto.DeptDefenTemp;

/**
 *
 * @author zhourongchao
 */
public class DeptDefenService {

    public DeptDefen fetch(DataSource ds, String codeType, String code, String duanNo) {
        DeptDefen cd = null;
        try {
            Dao dao = new NutDao(ds);
            cd = dao.fetchx(DeptDefen.class, codeType, code, duanNo);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cd;
    }

    public int delete(DataSource ds, DeptDefen cd) {
        int di = 0;
        try {
            Dao dao = new NutDao(ds);
            di = dao.deletex(DeptDefen.class, cd.getBfhTkCode(), cd.getDeptNo(), cd.getDuanNo());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return di;
    }

    /**
     * 获得部门总分
     * @param ds
     * @param deptNo
     * @return
     */
    public BigDecimal getDeptZongfen(DataSource ds, String deptNo, String year, int jidu) {
        BigDecimal dBd = new BigDecimal(0);
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            String sqlStr = "SELECT sum(heji) FROM dept_defen where dept_no=? and year=? and jidu=?";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, deptNo);
            pStmt.setString(2, year);
            pStmt.setInt(3, jidu);
            rs = pStmt.executeQuery();
            if (rs.next()) {
                dBd = rs.getBigDecimal(1);
            }
            if (dBd == null) {
                dBd = new BigDecimal(0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return dBd;
    }
}
