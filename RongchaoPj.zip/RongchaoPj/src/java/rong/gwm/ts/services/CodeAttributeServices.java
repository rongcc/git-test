/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.services;

import javax.sql.DataSource;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rong.gwm.ts.dto.CodeAttribute;

/**
 *
 * @author zhourongchao
 */
public class CodeAttributeServices {

    public CodeAttributeServices() {
    }

    public CodeAttribute fetch(DataSource ds, String codeType, String code) {
        CodeAttribute cd = null;
        try {
            Dao dao = new NutDao(ds);
            cd = dao.fetchx(CodeAttribute.class, codeType, code);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cd;
    }

    public int delete(DataSource ds, CodeAttribute cd) {
        int di = 0;
        try {
            Dao dao = new NutDao(ds);
            di = dao.deletex(CodeAttribute.class, cd.getCodeType(), cd.getCode());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return di;
    }

    public boolean myCode2oc(DataSource ds, String pno) {
        boolean boo = false;
        try {
            CodeAttribute cde = fetch(ds, "my_code2", pno);
            boo = cde.getAttribute1().equals("1");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return boo;
    }

    public String getDescription(DataSource ds, String codeType, String code) {
        String myStr = "";
        try {
            CodeAttribute cde = fetch(ds, codeType, code);
            myStr = cde.getDescription();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return myStr;
    }
}
