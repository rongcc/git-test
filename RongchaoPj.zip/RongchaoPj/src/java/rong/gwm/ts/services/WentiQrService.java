/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;
import javax.sql.DataSource;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rong.gwm.ts.dto.WentiQr;

/**
 *
 * @author zhourongchao
 */
public class WentiQrService {

    /**
     * get the next order no.
     */
    public String getNextNo(DataSource ds) {
        String nextNo = "";
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            StringBuffer sb = new StringBuffer();
            Calendar rightNow = Calendar.getInstance();
            int y = rightNow.get(Calendar.YEAR);
            conn = ds.getConnection();
            //取原表
            String sqlStr = "select max(wenti_qr_no) from wenti_qr";
            pStmt = conn.prepareStatement(sqlStr);
            rs = pStmt.executeQuery();
            String no = null;
            if (rs.next()) {
                no = rs.getString(1);
            }
            //根据查询结果运算
            if (no != null && no.length() > 4) {
                int lastYear = 2000 + Integer.parseInt(no.substring(2, 4));
                if (y > lastYear) {
                    nextNo = sb.append("WQ").append(String.valueOf(y).substring(2)).append("000001").toString();
                } else {
                    int ino = Integer.parseInt(no.substring(4));
                    nextNo = sb.append("WQ").append(String.valueOf(y).substring(2)).append(String.valueOf(1000001 + ino).substring(1)).toString();
                }
            } else {
                nextNo = sb.append("WQ").append(String.valueOf(y).substring(2)).append("000001").toString();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return nextNo;
    }

    /**
     * 审核触发的动作
     * @param ds
     * @param orderNo
     * @return
     */
    public int postTouch(DataSource ds, String orderNo) {
        int di = 0;
        try {
            //
            di = 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return di;
    }

    /**
     * 超过dNum天系统自动触发确认动作
     * @param ds
     * @param orderNo
     * @param dNum
     * @return
     */
    public int post2Touch(DataSource ds, String orderNo, int dNum) {
        int di = 0;
        try {
            Dao dao = new NutDao(ds);
            WentiQr part = dao.fetch(WentiQr.class, orderNo);
            Calendar rightNow = Calendar.getInstance();
            //是否大于两天
            boolean chaBoo = false;
            if (part.getPostDate() == null||part.getStatus()!=1) {
                chaBoo = false;
            } else {
                long cha = rightNow.getTime().getTime() - part.getPostDate().getTime();
                //System.out.println(cha+"-"+(12*60*60*1000));//12小时为43200000毫秒
                if (cha > (dNum * 24 * 60 * 60 * 1000)) {
                    chaBoo = true;
                }
            }
            if (chaBoo) {
                part.setPost2Date(rightNow.getTime());
                part.setPost2Name("system");
                part.setStatus(2);
                dao.update(part);
                DeptDefenTempService ddtService = new DeptDefenTempService();
                //审核后频次累加
                ddtService.updatePinciHeji(ds, part.getBfhTkId(), part.getBeipingjiaDeptCode());
                di += 1;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return di;
    }
}
