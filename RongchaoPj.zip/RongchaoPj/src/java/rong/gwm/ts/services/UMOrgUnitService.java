/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import javax.sql.DataSource;
import rong.gwm.ts.dto.UMOrgUnit;

/**
 *
 * @author zhourongchao
 */
public class UMOrgUnitService {

    /**
     * 根据部门代码获取部门名称。
     * @param ds
     * @param ouCode
     * @return
     */
    public String getOUName(DataSource ds, String ouCode) {
        String ouName = "";
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            //取原表
            String sqlStr = "select OU_Name from UM_OrgUnit where  OU_Code= ? ";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, ouCode);
            rs = pStmt.executeQuery();
            if (rs.next()) {
                ouName = rs.getString(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return ouName;
    }

    public List getSonUnits(DataSource ds, UMOrgUnit fatherCode) {
        return null;
    }
}
