/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;
import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rong.gwm.ts.dto.BfhOrder;
import rong.gwm.ts.dto.QmsWenti;
import rong.gwm.ts.dto.ShenheBaogao;
import rong.gwm.ts.dto.ShenheJiankong;
import rong.gwm.ts.dto.ShenheJihua;

/**
 *
 * @author zhourongchao
 */
public class ShenheJiankongService {

    /**
     * 获取审核计划数据进监控表
     * @param ds
     * @return
     */
    public int fetchJiankongJihua(DataSource ds) {
        int di = 0;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            Dao dao = new NutDao(ds);
            conn = ds.getConnection();
            String sqlStr = "SELECT shenhe_jihua_no FROM shenhe_jihua where status<>-1"
                    + " and shenhe_jihua_no not in(select shenhe_jihua_no from shenhe_jiankong)";
            pStmt = conn.prepareStatement(sqlStr);
            rs = pStmt.executeQuery();
            int jNo = 0;
            ShenheJihua jh = null;
            ShenheJiankong jk = null;
            while (rs.next()) {
                jNo = rs.getInt(1);
                jh = dao.fetch(ShenheJihua.class, jNo);
                //
                jk = new ShenheJiankong();
                jk.setShenheJihuaNo(jh.getShenheJihuaNo());
                jk.setShenheJihuaTitle(jh.getTitle());
                jk.setStatus(0);
                jk.setShenheName(jh.getShenheName());
                jk.setShibiehao(jh.getShibiehao());
                dao.insert(jk);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return di;
    }

    /**
     * 更新此监控条目的进度
     * @param ds
     * @param jkNo
     */
    public void updateJindu(DataSource ds, int jkNo) {
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            String jindu = "审核计划编制";
            int jinduStatus = 1;
            Dao dao = new NutDao(ds);
            ShenheJiankong jk = dao.fetch(ShenheJiankong.class, jkNo);
            int jihuaNo = jk.getShenheJihuaNo();
            //审核计划的状态是否为批准，如果已经批准状态为‘审核实施中’，否则为‘审核计划编制’。
            //System.out.println("001");
            ShenheJihua jh = dao.fetch(ShenheJihua.class, jihuaNo);
            if (jh.getStatus() == 2) {
                jindu = "审核实施中";
                jinduStatus = 2;
            } else {
                //更新进度存入数据库
                jk.setJindu(jindu);
                jk.setJinduStatus(jinduStatus);
                dao.update(jk);
                return;
            }
            //审核报告中是否有此计划号，如果有已经进入‘审核报告编制’，否则为‘审核实施中’。
            //System.out.println("002");
            List bgList = dao.query(ShenheBaogao.class, Cnd.where("source_order", "=", jh.getShenheJihuaNo() + "").and("status", "!=", -1), null);
            if (bgList.size() > 0) {
                jindu = "审核报告编制";
                jinduStatus = 3;
            } else {
                //更新进度存入数据库
                jk.setJindu(jindu);
                jk.setJinduStatus(jinduStatus);
                dao.update(jk);
                return;
            }
            //审核报告的状态是否为批准，如果已经批准状态为‘不符合项整改中’，否则为‘审核报告编制’。
            //System.out.println("003");
            boolean boo = false;
            for (int i = 0; i < bgList.size(); i++) {
                ShenheBaogao bg = (ShenheBaogao) bgList.get(i);
                //一个报告完成批准即进入‘不符合项整改中’。
                if (bg.getStatus() == 2) {
                    boo = true;
                }
            }
            if (boo) {
                jindu = "不符合项整改中";
                jinduStatus = 4;
            } else {
                //更新进度存入数据库
                jk.setJindu(jindu);
                jk.setJinduStatus(jinduStatus);
                dao.update(jk);
                return;
            }
            //关联审核报告的不符合项状态是否全部为结题，如果已经结题状态为‘结题’，否则为‘不符合项整改中’。
            //System.out.println("004");
            int jtInt = 0;
            boolean jtBoo = true;
            for (int i = 0; i < bgList.size(); i++) {
                ShenheBaogao bg = (ShenheBaogao) bgList.get(i);
                List bfhList = dao.query(BfhOrder.class, Cnd.where("source_order", "=", bg.getShenheBaogaoNo() + "").and("status", "!=", -1), null);
                for (int j = 0; j < bfhList.size(); j++) {
                    BfhOrder bfh = (BfhOrder) bfhList.get(j);
                    if (bfh.getIsJieti() == null || !bfh.getIsJieti().booleanValue()) {
                        jtBoo = false;
                    }
                    jtInt++;
                }
            }
            if (jtBoo && jtInt > 0) {
                jindu = "结题";
                jinduStatus = 5;
            } else {
                //更新进度存入数据库
                jk.setJindu(jindu);
                jk.setJinduStatus(jinduStatus);
                dao.update(jk);
                return;
            }
            //更新进度存入数据库
            jk.setJindu(jindu);
            jk.setJinduStatus(jinduStatus);
            dao.update(jk);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
    }

    /**
     * 查看相关资料：审核计划。
     * @param ds
     * @param jhNo
     * @return
     */
    public ShenheJihua getSrcShenheJihua(DataSource ds, int jhNo) {
        ShenheJihua order = null;
        try {
            Dao dao = new NutDao(ds);
            order = dao.fetch(ShenheJihua.class, jhNo);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return order;
    }

    /**
     * 查看相关资料：QMS问题。
     * @param ds
     * @param jhNo
     * @return
     */
    public QmsWenti getSrcQmsWenti(DataSource ds, int jhNo) {
        QmsWenti wt = null;
        ShenheJihua order = null;
        try {
            Dao dao = new NutDao(ds);
            order = dao.fetch(ShenheJihua.class, jhNo);
            String sourceOrder = order.getSourceOrder();
            if (sourceOrder != null) {
                wt = dao.fetch(QmsWenti.class, sourceOrder);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return wt;
    }

    /**
     * 查看相关资料：审核报告列表。
     * @param ds
     * @param jhNo
     * @return
     */
    public List getSrcShenheBaogao(DataSource ds, int jhNo) {
        List al = null;
        try {
            Dao dao = new NutDao(ds);
            String str1= jhNo+"";
            al = dao.query(ShenheBaogao.class, Cnd.where("source_order", "=", str1+ ""), null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return al;
    }

    /**
     * 查看相关资料：不符合项。
     * @param ds
     * @param jhNo
     * @return
     */
    public List getSrcBfhOrder(DataSource ds, int jhNo) {
        List aList = null;
        List al = null;
        try {
            Dao dao = new NutDao(ds);
            ShenheJihua order = dao.fetch(ShenheJihua.class, jhNo);
            al = dao.query(ShenheBaogao.class, Cnd.where("source_order", "=", order.getShenheJihuaNo().intValue() + ""), null);
            ShenheBaogao bg = null;
            aList = new ArrayList();
            List temList = null;
            for (int i = 0; i < al.size(); i++) {
                bg = (ShenheBaogao) al.get(i);
                temList = dao.query(BfhOrder.class, Cnd.where("source_order", "=", bg.getShenheBaogaoNo().intValue() + ""), null);
                aList.addAll(temList);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return aList;
    }
}
