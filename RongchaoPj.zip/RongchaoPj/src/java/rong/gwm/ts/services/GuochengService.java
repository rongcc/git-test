/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.services;

import javax.sql.DataSource;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rong.gwm.ts.dto.Guocheng;

/**
 *
 * @author ZhouRongChao
 */
public class GuochengService {

    /**
     * 获取过程名称。
     * @param ds
     * @param id
     * @return
     */
    public String getName(DataSource ds, Integer id) {
        String dStr = "";
        Guocheng order = null;
        try {
            Dao dao = new NutDao(ds);
            order = dao.fetch(Guocheng.class, id);
            if (order != null) {
                dStr = order.getName();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return dStr;
    }
}
