/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import javax.sql.DataSource;
import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rcsoft.rc.db.CachingRcdb;
import rong.gwm.ts.dto.CodeAttribute;
import rong.gwm.ts.dto.Guocheng;
import rong.gwm.ts.dto.OmPingfenGuocheng;
import rong.gwm.ts.dto.OmPingfenGuochengHistory;
import rong.gwm.ts.dto.OmPingfenResult;
import rong.gwm.ts.dto.OmPingfenResultHistory;

/**
 * 量化评估评分管理器。
 * @author zhourongchao
 */
public class OmPingfenService {

    /**
     * 过程分
     */
    public static void addGuocheng(Integer guochengId, double fenzhi) {
        Connection conn = null;
        PreparedStatement pStmt = null;
        try {
            DataSource ds = CachingRcdb.getInstance().getDs4Ts();
            conn = ds.getConnection();
            //取原表
            String sqlStr = "update om_pingfen_guocheng set pingfen=pingfen+" + fenzhi + " where guocheng_id=" + guochengId;
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
    }

    /**
     * 结果分
     */
    public static void addResult(Integer orgId, double fenzhi) {
        Connection conn = null;
        PreparedStatement pStmt = null;
        try {
            DataSource ds = CachingRcdb.getInstance().getDs4Ts();
            conn = ds.getConnection();
            //取原表
            String sqlStr = "update om_pingfen_result set jieguo_fen=jieguo_fen+" + fenzhi + " where org_id=" + orgId;
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
    }

    /**
     * 合计过程分、结果分.
     */
    public static void heji() {
        Connection conn = null;
        PreparedStatement pStmt = null;
        try {
            DataSource ds = CachingRcdb.getInstance().getDs4Ts();
            conn = ds.getConnection();
            //取原表
            String sqlStr = "update om_pingfen_result set heji=guocheng_fen+jieguo_fen";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
    }

    /**
     * 初始化评分表（包括过程分表与结果分表）。
     */
    public void initPingfen() {
        try {
            DataSource ds = CachingRcdb.getInstance().getDs4Ts();
            Dao dao = new NutDao(ds);
            int qi = dao.clear(OmPingfenResult.class);
            System.out.println("清理结果表" + qi + "条记录。");
            //获取部门列表
            List deptList = dao.query(CodeAttribute.class, Cnd.where("code_type", "=", "ss_object").asc("code"), null);
            //依部门循环
            OmPingfenResult ddt = null;
            CodeAttribute dept = null;
            int di = 0;
            for (int i = 0; i < deptList.size(); i++) {
                dept = (CodeAttribute) deptList.get(i);
                ddt = new OmPingfenResult();
                ddt.setOrgId(new Integer(dept.getCode()));
                ddt.setOrgName(dept.getDescription());
                ddt.setGuochengFen(new Double(0));
                ddt.setJieguoFen(new Double(0));
                ddt.setHeji(new Double(0));
                dao.insert(ddt);
                //初始化记录数
                di++;
            }
            System.out.println("初始化结果记录：" + di);
            List gList = dao.query(Guocheng.class, Cnd.where("status", "!=", "-1"), null);
            Guocheng g = null;
            OmPingfenGuocheng pgc = null;
            int ci = 0;
            for (int i = 0; i < gList.size(); i++) {
                g = (Guocheng) gList.get(i);
                pgc = new OmPingfenGuocheng();
                pgc.setGuochengId(g.getId());
                pgc.setPingfen(new Double(0));
                pgc.setOrgId(g.getOrgId());
                pgc.setGuochengName(g.getName());
                dao.insert(pgc);
                //初始化记录数
                ci++;
            }
            System.out.println("初始化过程记录：" + ci);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 归档评分表（包括过程分表与结果分表）。
     */
    public void guidangPingfen() {
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            DataSource ds = CachingRcdb.getInstance().getDs4Ts();
            int period = 1;
            conn = ds.getConnection();
            String sqlStr = "SELECT max(period) FROM om_pingfen_result_history";
            pStmt = conn.prepareStatement(sqlStr);
            rs = pStmt.executeQuery();
            if (rs.next()) {
                if (rs.getString(1) == null) {
                    period = 1;
                } else {
                    period = rs.getInt(1) + 1;
                }
            }
            Dao dao = new NutDao(ds);
            List dList = dao.query(OmPingfenResult.class, null, null);
            OmPingfenResult ddt = null;
            OmPingfenResultHistory dd = null;
            int di = 0;
            for (int i = 0; i < dList.size(); i++) {
                ddt = (OmPingfenResult) dList.get(i);
                dd = new OmPingfenResultHistory();
                dd.setOrgId(ddt.getOrgId());
                dd.setOrgName(ddt.getOrgName());
                dd.setGuochengFen(ddt.getGuochengFen());
                dd.setJieguoFen(ddt.getJieguoFen());
                dd.setHeji(ddt.getHeji());
                dd.setPeriod(period);
                //插入得分记录表
                dao.insert(dd);
                di++;
            }
            System.out.println("归档结果记录：" + di);
            dList = dao.query(OmPingfenGuocheng.class, null, null);
            OmPingfenGuocheng pg = null;
            OmPingfenGuochengHistory pgh = null;
            int dig = 0;
            for (int i = 0; i < dList.size(); i++) {
                pg = (OmPingfenGuocheng) dList.get(i);
                pgh = new OmPingfenGuochengHistory();
                pgh.setGuochengId(pg.getGuochengId());
                pgh.setPingfen(pg.getPingfen());
                pgh.setPeriod(period);
                pgh.setGuochengName(pg.getGuochengName());
                pgh.setOrgId(pg.getOrgId());
                //插入得分记录表
                dao.insert(pgh);
                dig++;
            }
            System.out.println("归档过程记录：" + dig);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
    }
}
