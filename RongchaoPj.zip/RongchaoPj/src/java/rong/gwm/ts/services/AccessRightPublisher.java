/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.services;

import javax.jms.Destination;
import javax.jms.MapMessage;
import javax.jms.MessageProducer;
import javax.jms.QueueSession;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicSession;
import javax.naming.NamingException;
import rong.gwm.ts.util.MDBServiceLocator;

/**
 *
 * @author ZhouRongChao
 */
public class AccessRightPublisher {

    private static AccessRightPublisher me;

    static {
        try {
            me = new AccessRightPublisher();
        } catch (Exception se) {
            throw new RuntimeException(se);
        }
    }

    public AccessRightPublisher() {
    }

    public static AccessRightPublisher getInstance() {
        return me;
    }

    /**
     * 谁在什么地方对哪个数据项的哪个单据做了什么事情，发布此事件主题以供监听者响应。
     * @param operNo 用户
     * @param orderNo 单据编号
     * @param accessPage 数据项
     * @param doRight 执行了的权限
     * @param doDate 执行时间
     * @param doIp 执行来自的IP地址
     */
    public void publish(String operNo, String orderNo, String accessPage, String doRight, String doDate, String doIp) {
        try {
            MDBServiceLocator mdbsl = new MDBServiceLocator();
            //连接工厂
            TopicConnectionFactory factory = (TopicConnectionFactory) mdbsl.getConnectionFactory("ConnectionFactory");
            TopicConnection topicConnection = factory.createTopicConnection();
            TopicSession topicSession = topicConnection.createTopicSession(false, QueueSession.AUTO_ACKNOWLEDGE);
            //目标地址
            Destination destination = mdbsl.getDestination("topic/accessRightNoticeService");
            MessageProducer producer = topicSession.createProducer(destination);
            MapMessage map = topicSession.createMapMessage();
            map.setString("operNo", operNo);
            map.setString("orderNo", orderNo);
            map.setString("accessPage", accessPage);
            map.setString("doRight", doRight);
            map.setString("doDate", doDate);
            map.setString("doIp", doIp);
            producer.send(map);
            topicSession.close();
            topicConnection.close();//实际中这个关闭应该统一由链接工厂或者相应的链接池来关闭
        } catch (NamingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 谁在什么地方对哪个数据项的哪个单据做了什么事情，执行结果,发布此事件主题以供监听者响应。
     * @param boo
     * @param operNo
     * @param orderNo
     * @param accessPage
     * @param doRight
     * @param doDate
     * @param doIp
     */
    public void publish(boolean boo, String operNo, String orderNo, String accessPage, String doRight, String doDate, String doIp) {
        try {
            MDBServiceLocator mdbsl = new MDBServiceLocator();
            //连接工厂
            TopicConnectionFactory factory = (TopicConnectionFactory) mdbsl.getConnectionFactory("ConnectionFactory");
            TopicConnection topicConnection = factory.createTopicConnection();
            TopicSession topicSession = topicConnection.createTopicSession(false, QueueSession.AUTO_ACKNOWLEDGE);
            //目标地址
            Destination destination = mdbsl.getDestination("topic/accessRightNoticeService");
            MessageProducer producer = topicSession.createProducer(destination);
            MapMessage map = topicSession.createMapMessage();
            map.setBoolean("boo", boo);
            map.setString("operNo", operNo);
            map.setString("orderNo", orderNo);
            map.setString("accessPage", accessPage);
            map.setString("doRight", doRight);
            map.setString("doDate", doDate);
            map.setString("doIp", doIp);
            producer.send(map);
            topicSession.close();
            topicConnection.close();//实际中这个关闭应该统一由链接工厂或者相应的链接池来关闭
        } catch (NamingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
