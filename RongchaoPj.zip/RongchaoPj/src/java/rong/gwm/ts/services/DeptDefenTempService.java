/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.services;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import javax.sql.DataSource;
import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rong.gwm.ts.dto.CodeAttribute;
import rong.gwm.ts.dto.CodeData;
import rong.gwm.ts.dto.DeptDefen;
import rong.gwm.ts.dto.DeptDefenTemp;

/**
 *
 * @author zhourongchao
 */
public class DeptDefenTempService {

    public DeptDefenTemp fetch(DataSource ds, String codeType, String code) {
        DeptDefenTemp cd = null;
        try {
            Dao dao = new NutDao(ds);
            cd = dao.fetchx(DeptDefenTemp.class, codeType, code);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cd;
    }

    public int delete(DataSource ds, DeptDefenTemp cd) {
        int di = 0;
        try {
            Dao dao = new NutDao(ds);
            di = dao.deletex(DeptDefenTemp.class, cd.getBfhTkCode(), cd.getDeptNo());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return di;
    }

    /**
     * 初始化部门得分表，只保存本季度的数据。
     * @param ds
     * @return
     */
    public int initDeptDefenTemp(DataSource ds) {
        int di = 0;
        //插入部门与条款对应数据
        try {
            Dao dao = new NutDao(ds);
            int qi = dao.clear(DeptDefenTemp.class);
            System.out.println("清理得分表" + qi + "条记录。");
            //获取部门列表
            List deptList = dao.query(CodeAttribute.class, Cnd.where("code_type", "=", "ss_object").asc("code"), null);
            //获取条款列表
            List bfhTkList = dao.query(CodeAttribute.class, Cnd.where("code_type", "=", "bfh_tk").asc("code"), null);
            //依部门循环
            DeptDefenTemp ddt = null;
            CodeAttribute dept = null;
            for (int i = 0; i < deptList.size(); i++) {
                dept = (CodeAttribute) deptList.get(i);
                //依条款循环
                CodeAttribute bfh = null;
                for (int j = 0; j < bfhTkList.size(); j++) {
                    bfh = (CodeAttribute) bfhTkList.get(j);
                    //将对应条目写入数据库
                    ddt = new DeptDefenTemp();
                    ddt.setBfhTkCode(bfh.getCode());
                    ddt.setBfhTk(bfh.getDescription());
                    ddt.setDeptNo(dept.getCode());
                    ddt.setDeptName(dept.getDescription());
                    //不符合条款分值
                    ddt.setPingjia(bfh.getAttribute6());
                    ddt.setPinci(0);
                    ddt.setHeji(new BigDecimal(0));
                    dao.insert(ddt);
                    //初始化记录数
                    di++;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return di;
    }

    /**
     * 更新频次，合计也随之计算。
     * @param ds
     * @param bfhTkCode
     * @param deptNo
     * @return
     */
    public int updatePinciHeji(DataSource ds, String bfhTkCode, String deptNo) {
        int di = 0;
        try {
            //
            Dao dao = new NutDao(ds);
            DeptDefenTemp ddt = (DeptDefenTemp) this.fetch(ds, bfhTkCode, deptNo);
            ddt.setPinci(ddt.getPinci() + 1);
            ddt.setHeji(ddt.getPingjia().multiply(new BigDecimal(ddt.getPinci())));
            dao.update(ddt);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return di;
    }

    /**
     * 获得部门总分
     * @param ds
     * @param deptNo
     * @return
     */
    public BigDecimal getDeptZongfen(DataSource ds, String deptNo) {
        BigDecimal dBd = new BigDecimal(0);
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            String sqlStr = "SELECT sum(heji) FROM dept_defen_temp where dept_no=?";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, deptNo);
            rs = pStmt.executeQuery();
            if (rs.next()) {
                dBd = rs.getBigDecimal(1);
            }
            if (dBd == null) {
                dBd = new BigDecimal(0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return dBd;
    }

    /**
     * 归档得分记录
     * @param ds
     * @return
     */
    public int guidangJilu(DataSource ds) {
        int di = 0;
        try {
            //
            Dao dao = new NutDao(ds);
            //获取季度与季度所在年份
            CodeDataServices cds = new CodeDataServices();
            CodeData cde_jidu = cds.fetch(ds, "my_code", "pingfen_jidu");
            int jidu = Integer.parseInt(cde_jidu.getDescription());
            CodeData cde_jidu_year = cds.fetch(ds, "my_code", "pingfen_jidu_year");
            String jidu_year = cde_jidu_year.getDescription();
            //
            List dList = dao.query(DeptDefenTemp.class, null, null);
            DeptDefenTemp ddt = null;
            DeptDefen dd = null;
            for (int i = 0; i < dList.size(); i++) {
                ddt = (DeptDefenTemp) dList.get(i);
                dd = new DeptDefen();
                dd.setBfhTk(ddt.getBfhTk());
                dd.setBfhTkCode(ddt.getBfhTkCode());
                dd.setDeptName(ddt.getDeptName());
                dd.setDeptNo(ddt.getDeptNo());
                dd.setHeji(ddt.getHeji());
                dd.setPinci(ddt.getPinci());
                dd.setPingjia(ddt.getPingjia());
                dd.setStatus(0);
                dd.setYear(jidu_year);
                dd.setJidu(jidu);
                dd.setDuanNo(jidu_year + "_" + jidu);
                //总分
                dd.setZongfen(getDeptZongfen(ds, ddt.getDeptNo()));
                //插入得分记录表
                dao.insert(dd);
                di++;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return di;
    }
}
