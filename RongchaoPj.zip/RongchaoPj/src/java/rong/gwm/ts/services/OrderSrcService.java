/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;
import javax.sql.DataSource;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rong.gwm.ts.dto.BfhDc;
import rong.gwm.ts.dto.BfhDcBg;
import rong.gwm.ts.dto.BfhJietiSq;
import rong.gwm.ts.dto.BfhJinduJilu;
import rong.gwm.ts.dto.BfhYanzhengJilu;

/**
 *
 * @author zhourongchao
 */
public class OrderSrcService {

    /**
     * 获取不符合项对策或对策变更里的纠正措施实施完成最终节点日期。
     * @param ds
     * @param orderStart
     * @return
     */
    public Date getLastDcOrDcBgDate(DataSource ds, String orderStart) {
        Date myDate = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            Dao dao = new NutDao(ds);
            conn = ds.getConnection();
            //
            String sqlStr = "SELECT * FROM order_src where order_start= ?"
                    + " and (order_type='bfh_dc' or order_type='bfh_dc_bg') order by input_date desc";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, orderStart);
            rs = pStmt.executeQuery();
            String orderNo = null;
            String orderType = null;
            while (rs.next()) {
                orderNo = rs.getString("order_no");
                orderType = rs.getString("order_type");
                if (orderType.equals("bfh_dc")) {
                    BfhDc dc = dao.fetch(BfhDc.class, orderNo);
                    if (dc.getStatus() != -1) {
                        myDate = dc.getCuoshiJiedianDate();
                    }
                } else if (orderType.equals("bfh_dc_bg")) {
                    BfhDcBg dcBg = dao.fetch(BfhDcBg.class, orderNo);
                    if (dcBg.getStatus() != -1) {
                        myDate = dcBg.getBghJihuaDate();
                    }
                }
                if (myDate != null) {
                    rs.afterLast();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return myDate;
    }

    /**
     * 获取最近的对策编号
     * @param ds
     * @param orderStart
     * @return
     */
    public String getLastDcNo(DataSource ds, String orderStart) {
        //Date myDate = null;
        String dcNo = null;
        BfhDc dc = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            Dao dao = new NutDao(ds);
            conn = ds.getConnection();
            //
            String sqlStr = "SELECT * FROM order_src where order_start= ?"
                    + " and (order_type='bfh_dc') order by input_date desc";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, orderStart);
            rs = pStmt.executeQuery();
            String orderNo = null;
            String orderType = null;
            while (rs.next()) {
                orderNo = rs.getString("order_no");
                orderType = rs.getString("order_type");
                if (orderType.equals("bfh_dc")) {
                    dc = dao.fetch(BfhDc.class, orderNo);
                    if (dc.getStatus() != -1) {
                        dcNo = dc.getDcNo();
                    }
                }
                if (dcNo != null) {
                    rs.afterLast();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return dcNo;
    }

    /**
     * 获取最近的对策变更单号
     * @param ds
     * @param orderStart
     * @return
     */
    public String getLastDcBgNo(DataSource ds, String orderStart) {
        //Date myDate = null;
        String dcNo = null;
        BfhDcBg dc = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            Dao dao = new NutDao(ds);
            conn = ds.getConnection();
            //
            String sqlStr = "SELECT * FROM order_src where order_start= ?"
                    + " and (order_type='bfh_dc_bg') order by input_date desc";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, orderStart);
            rs = pStmt.executeQuery();
            String orderNo = null;
            String orderType = null;
            while (rs.next()) {
                orderNo = rs.getString("order_no");
                orderType = rs.getString("order_type");
                if (orderType.equals("bfh_dc_bg")) {
                    dc = dao.fetch(BfhDcBg.class, orderNo);
                    if (dc.getStatus() != -1) {
                        dcNo = dc.getDcBgNo();
                    }
                }
                if (dcNo != null) {
                    rs.afterLast();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return dcNo;
    }

    /**
     * 获取最近的结题申请单号
     * @param ds
     * @param orderStart
     * @return
     */
    public String getLastJietiSqNo(DataSource ds, String orderStart) {
        //Date myDate = null;
        String dcNo = null;
        BfhJietiSq dc = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            Dao dao = new NutDao(ds);
            conn = ds.getConnection();
            //
            String sqlStr = "SELECT * FROM order_src where order_start= ?"
                    + " and (order_type='bfh_jieti_sq') order by input_date desc";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, orderStart);
            rs = pStmt.executeQuery();
            String orderNo = null;
            String orderType = null;
            while (rs.next()) {
                orderNo = rs.getString("order_no");
                orderType = rs.getString("order_type");
                if (orderType.equals("bfh_jieti_sq")) {
                    dc = dao.fetch(BfhJietiSq.class, orderNo);
                    if (dc.getStatus() != -1) {
                        dcNo = dc.getJietiSqNo();
                    }
                }
                if (dcNo != null) {
                    rs.afterLast();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return dcNo;
    }

    /**
     * 获取最近的进度记录编号
     * @param ds
     * @param orderStart
     * @return
     */
    public String getLastJinduJiluNo(DataSource ds, String orderStart) {
        //Date myDate = null;
        String dcNo = null;
        BfhJinduJilu dc = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            Dao dao = new NutDao(ds);
            conn = ds.getConnection();
            //
            String sqlStr = "SELECT * FROM order_src where order_start= ?"
                    + " and (order_type='bfh_jindu_jilu') order by input_date desc";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, orderStart);
            rs = pStmt.executeQuery();
            String orderNo = null;
            String orderType = null;
            while (rs.next()) {
                orderNo = rs.getString("order_no");
                orderType = rs.getString("order_type");
                if (orderType.equals("bfh_jindu_jilu")) {
                    dc = dao.fetch(BfhJinduJilu.class, orderNo);
                    if (dc.getStatus() != -1) {
                        dcNo = dc.getJinduBiaozNo();
                    }
                }
                if (dcNo != null) {
                    rs.afterLast();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return dcNo;
    }

    /**
     * 获得最近的验证记录编号
     * @param ds
     * @param orderStart
     * @return
     */
    public String getLastYanzhengJiluNo(DataSource ds, String orderStart) {
        //Date myDate = null;
        String dcNo = null;
        BfhYanzhengJilu dc = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            Dao dao = new NutDao(ds);
            conn = ds.getConnection();
            //
            String sqlStr = "SELECT * FROM order_src where order_start= ?"
                    + " and (order_type='bfh_yanzheng_jilu') order by input_date desc";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, orderStart);
            rs = pStmt.executeQuery();
            String orderNo = null;
            String orderType = null;
            while (rs.next()) {
                orderNo = rs.getString("order_no");
                orderType = rs.getString("order_type");
                if (orderType.equals("bfh_yanzheng_jilu")) {
                    dc = dao.fetch(BfhYanzhengJilu.class, orderNo);
                    if (dc.getStatus() != -1) {
                        dcNo = dc.getYanzhengNo();
                    }
                }
                if (dcNo != null) {
                    rs.afterLast();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return dcNo;
    }
}
