/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import javax.sql.DataSource;
import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rong.gwm.ts.dto.QPProblemInfo;
import rong.gwm.ts.dto.QPProblemReply;
import rong.gwm.ts.dto.QmsWenti;
import rong.gwm.ts.dto.ShenheJihua;
import rong.gwm.ts.util.DadaoUse;

/**
 *
 * @author zhourongchao
 */
public class QmsWentiService {

    /**
     * 提取问题信息
     * @param ds2
     * @return
     */
    public List tiquQPProblemInfo(DataSource ds2) {
        List al = null;
        try {
            Dao dao = new NutDao(ds2);
            al = dao.query(QPProblemInfo.class, Cnd.where("CreateDate", ">=", "2011-3-25").and("QP1_IsDelete", "=", "false").asc("CreateDate"), null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return al;
    }

    /**
     * 根据问题信息得到问题回复
     * @param ds2
     * @param qi
     * @return
     */
    public QPProblemReply getQPProblemReply(DataSource ds2, QPProblemInfo qi) {
        List al = null;
        QPProblemReply qir = null;
        try {
            Dao dao = new NutDao(ds2);
            int QP1_ID = qi.getQp1Id();
            al = dao.query(QPProblemReply.class, Cnd.where("QP1_ID", "=", QP1_ID), null);
            for (int i = 0; i < al.size(); i++) {
                qir = (QPProblemReply) al.get(i);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return qir;
    }

    /**
     * 提取QMS系统问题
     */
    public int tiquQmsWenti(DataSource ds, DataSource ds2) {
        int wtn = 0;
        try {
            //提取问题
            List al = this.tiquQPProblemInfo(ds2);
            String sourceOrder = "";
            QmsWenti order = null;
            Dao dao = new NutDao(ds);
            for (int i = 0; i < al.size(); i++) {
                QPProblemInfo qi = (QPProblemInfo) al.get(i);
                sourceOrder = qi.getqP1Code();
                //如果已经导入此单就跳出本次循环继续
                List ilist = dao.query(QmsWenti.class, Cnd.where("source_order", "=", sourceOrder), null);
                if (ilist.size() >= 1) {
                    continue;
                }
                order = new QmsWenti();
                //
                order.setSourceOrder(sourceOrder);
                order.setWentiNo(this.getNextNo(ds));
                order.setSsDept(qi.getqP1ReplyOUName());
                order.setWentiMiaoshu(qi.getqP1Description());
                order.setYanzhongdu(qi.getqP1Severity());
                //原因分析
                QPProblemReply qir = this.getQPProblemReply(ds2, qi);
                if (qir != null) {
                    order.setYuanyinFenxi(qir.getqP3ReasonAnalyse() + "");
                }
                //状态与录入信息
                order.setStatus(0);
                order.setInputDate(DadaoUse.getInstance().getNow());
                //System.out.println(order.getSourceOrder() + "-" + order.getWentiNo() + order.getWentiMiaoshu());
                dao.insert(order);
                wtn += 1;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return wtn;
    }

    /**
     * 提取问题信息A类
     * @param ds2
     * @return
     */
    public List tiquQPProblemInfo_A(DataSource ds2) {
        List al = null;
        try {
            Dao dao = new NutDao(ds2);
            al = dao.query(QPProblemInfo.class, Cnd.where("CreateDate", ">=", "2011-6-13").and("QP1_IsDelete", "=", "false").and("QP1_Severity", "=", "A").asc("CreateDate"), null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return al;
    }

    /**
     * 提取问题信息V1+类
     * @param ds2
     * @return
     */
    public List tiquQPProblemInfo_V1jia(DataSource ds2) {
        List al = null;
        try {
            Dao dao = new NutDao(ds2);
            al = dao.query(QPProblemInfo.class, Cnd.where("CreateDate", ">=", "2011-6-13").and("QP1_IsDelete", "=", "false").and("QP1_Severity", "=", "V1+").asc("CreateDate"), null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return al;
    }

    /**
     * 提取QMS系统A,V1+问题
     */
    public int tiquQmsWenti_A_V1jia(DataSource ds, DataSource ds2) {
        int wtn = 0;
        try {
            //提取问题
            List al = new ArrayList();
            List al_A = this.tiquQPProblemInfo_A(ds2);
            List al_V1jia = this.tiquQPProblemInfo_V1jia(ds2);
            al.addAll(al_A);
            al.addAll(al_V1jia);
            String sourceOrder = "";
            QmsWenti order = null;
            Dao dao = new NutDao(ds);
            for (int i = 0; i < al.size(); i++) {
                QPProblemInfo qi = (QPProblemInfo) al.get(i);
                sourceOrder = qi.getqP1Code();
                //如果已经导入此单就跳出本次循环继续
                List ilist = dao.query(QmsWenti.class, Cnd.where("source_order", "=", sourceOrder), null);
                if (ilist.size() >= 1) {
                    continue;
                }
                order = new QmsWenti();
                //
                order.setSourceOrder(sourceOrder);
                order.setWentiNo(this.getNextNo(ds));
                order.setSsDept(qi.getqP1ReplyOUName());
                order.setWentiMiaoshu(qi.getqP1Description());
                order.setYanzhongdu(qi.getqP1Severity());
                //原因分析
                QPProblemReply qir = this.getQPProblemReply(ds2, qi);
                if (qir != null) {
                    order.setYuanyinFenxi(qir.getqP3ReasonAnalyse() + "");
                }
                //状态与录入信息
                order.setStatus(0);
                order.setInputDate(DadaoUse.getInstance().getNow());
                //System.out.println(order.getSourceOrder() + "-" + order.getWentiNo() + order.getWentiMiaoshu());
                dao.insert(order);
                wtn += 1;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return wtn;
    }

    /**
     * 提取QMS系统A,V1+问题，是否需要原因分析以及原因分析的字数限制。
     * @param ds
     * @param ds2
     * @param boo
     * @param zishu
     * @return
     */
    public int tiquQmsWenti_A_V1jia(DataSource ds, DataSource ds2, boolean boo, int zishu) {
        int wtn = 0;
        try {
            //提取问题
            List al = new ArrayList();
            List al_A = this.tiquQPProblemInfo_A(ds2);
            List al_V1jia = this.tiquQPProblemInfo_V1jia(ds2);
            al.addAll(al_A);
            al.addAll(al_V1jia);
            String sourceOrder = "";
            QmsWenti order = null;
            Dao dao = new NutDao(ds);
            for (int i = 0; i < al.size(); i++) {
                QPProblemInfo qi = (QPProblemInfo) al.get(i);
                sourceOrder = qi.getqP1Code();
                //如果已经导入此单就跳出本次循环继续
                List ilist = dao.query(QmsWenti.class, Cnd.where("source_order", "=", sourceOrder), null);
                if (ilist.size() >= 1) {
                    continue;
                }
                order = new QmsWenti();
                //
                order.setSourceOrder(sourceOrder);
                order.setWentiNo(this.getNextNo(ds));
                order.setSsDept(qi.getqP1ReplyOUName());
                order.setWentiMiaoshu(qi.getqP1Description());
                order.setYanzhongdu(qi.getqP1Severity());
                //原因分析
                QPProblemReply qir = this.getQPProblemReply(ds2, qi);
                //要求原因分析、没有原因分析。跳出。
                if (boo && (qir == null)) {
                    continue;
                }
                if (boo && (qir.getqP3ReasonAnalyse() == null || qir.getqP3ReasonAnalyse().trim().length() < zishu)) {
                    continue;
                }
                if (qir != null) {
                    order.setYuanyinFenxi(qir.getqP3ReasonAnalyse() + "");
                }
                //状态与录入信息
                order.setStatus(0);
                order.setInputDate(DadaoUse.getInstance().getNow());
                //System.out.println(order.getSourceOrder() + "-" + order.getWentiNo() + order.getWentiMiaoshu());
                dao.insert(order);
                wtn += 1;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return wtn;
    }

    /**
     * 提取QMS系统A,V1+问题，是否需要原因分析以及原因分析的字数限制,是否需要整改对策以及整改对策的字数限制.
     * @param ds
     * @param ds2
     * @param boo 是否需要原因分析
     * @param zishu 原因分析的字数限制
     * @param boo2 是否需要整改对策
     * @param zishu2 整改对策的字数限制
     * @return
     */
    public int tiquQmsWenti_A_V1jia(DataSource ds, DataSource ds2, boolean boo, int zishu, boolean boo2, int zishu2) {
        int wtn = 0;
        try {
            //提取问题
            List al = new ArrayList();
            List al_A = this.tiquQPProblemInfo_A(ds2);
            List al_V1jia = this.tiquQPProblemInfo_V1jia(ds2);
            al.addAll(al_A);
            al.addAll(al_V1jia);
            String sourceOrder = "";
            QmsWenti order = null;
            Dao dao = new NutDao(ds);
            for (int i = 0; i < al.size(); i++) {
                QPProblemInfo qi = (QPProblemInfo) al.get(i);
                sourceOrder = qi.getqP1Code();
                //如果已经导入此单就跳出本次循环继续
                List ilist = dao.query(QmsWenti.class, Cnd.where("source_order", "=", sourceOrder), null);
                if (ilist.size() >= 1) {
                    continue;
                }
                order = new QmsWenti();
                //
                order.setSourceOrder(sourceOrder);
                order.setWentiNo(this.getNextNo(ds));
                order.setSsDept(qi.getqP1ReplyOUName());
                order.setWentiMiaoshu(qi.getqP1Description());
                order.setYanzhongdu(qi.getqP1Severity());
                //原因分析
                QPProblemReply qir = this.getQPProblemReply(ds2, qi);
                //要求原因分析、没有原因分析。跳出。
                if (boo && (qir == null)) {
                    continue;
                }
                if (boo && (qir.getqP3ReasonAnalyse() == null || qir.getqP3ReasonAnalyse().trim().length() < zishu)) {
                    continue;
                }
                if (boo2 && (qir == null)) {
                    continue;
                }
                if (boo2 && (qir.getqP3ModifyPolicy() == null || qir.getqP3ModifyPolicy().trim().length() < zishu2)) {
                    continue;
                }
                if (qir != null) {
                    order.setYuanyinFenxi(qir.getqP3ReasonAnalyse() + "");
                }
                //状态与录入信息
                order.setStatus(0);
                order.setInputDate(DadaoUse.getInstance().getNow());
                //System.out.println(order.getSourceOrder() + "-" + order.getWentiNo() + order.getWentiMiaoshu());
                dao.insert(order);
                wtn += 1;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return wtn;
    }

    /**
     * 新增
     * @param ds
     * @param order
     * @return
     */
    public String create(DataSource ds, QmsWenti order) {
        //
        if (order == null) {
            return null;
        }
        //
        String orderNo = "";
        try {
            Dao dao = new NutDao(ds);
            QmsWenti po = dao.insert(order);
            orderNo = po.getWentiNo();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return orderNo;

    }

    /**
     * get the next order no.
     */
    public String getNextNo(DataSource ds) {
        String nextNo = "";
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            StringBuffer sb = new StringBuffer();
            Calendar rightNow = Calendar.getInstance();
            int y = rightNow.get(Calendar.YEAR);
            conn = ds.getConnection();
            //取原表
            String sqlStr = "select max(wenti_no) from qms_wenti";
            pStmt = conn.prepareStatement(sqlStr);
            rs = pStmt.executeQuery();
            String no = null;
            if (rs.next()) {
                no = rs.getString(1);
            }
            //根据查询结果运算
            if (no != null && no.length() > 4) {
                int lastYear = 2000 + Integer.parseInt(no.substring(2, 4));
                if (y > lastYear) {
                    nextNo = sb.append("QT").append(String.valueOf(y).substring(2)).append("000001").toString();
                } else {
                    int ino = Integer.parseInt(no.substring(4));
                    nextNo = sb.append("QT").append(String.valueOf(y).substring(2)).append(String.valueOf(1000001 + ino).substring(1)).toString();
                }
            } else {
                nextNo = sb.append("QT").append(String.valueOf(y).substring(2)).append("000001").toString();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return nextNo;
    }

    /**
     * 获取此QMS质量问题关联的审核计划
     * @param ds
     * @param wentiNo
     * @return
     */
    public List fetchWentiJihua(DataSource ds, String wentiNo) {
        List sjList = null;
        try {
            Dao dao = new NutDao(ds);
            sjList = dao.query(ShenheJihua.class, Cnd.where("source_order", "=", wentiNo), null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return sjList;
    }
}
