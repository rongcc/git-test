/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.services;

import java.util.List;
import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rcsoft.rc.db.CachingRcdb;
import rong.chao.biz.AbstractProcess;
import rong.gwm.ts.dto.OrderSrc;

/**
 *
 * @author ZhouRongChao
 */
public class OrderProcess extends AbstractProcess {

    private Dao dao = new NutDao(CachingRcdb.getInstance().getDs4Ts());

    /**
     * 给定切入点，追溯全流程。
     *
     * @param orderNo
     */
    public void loadProcess(String orderNo) {
        loadUpLink(orderNo);
        loadDownLink(orderNo);
    }

    /**
     * 向上追溯到头。
     *
     * @param orderNo
     */
    private void loadUpLink(String orderNo) {
        List sonList = dao.query(OrderSrc.class, Cnd.where("order_no", "=", orderNo), null);
        for (int i = 0; i < sonList.size(); i++) {
            OrderSrc link = (OrderSrc) sonList.get(i);
            this.addFirst(link);
            loadUpLink(link.getSrcOrder());
        }
    }

    /**
     * 向下追溯到头。
     *
     * @param orderNo
     */
    private void loadDownLink(String orderNo) {
        List sonList = dao.query(OrderSrc.class, Cnd.where("src_order", "=", orderNo), null);
        for (int i = 0; i < sonList.size(); i++) {
            OrderSrc link = (OrderSrc) sonList.get(i);
            this.addFirst(link);
            loadDownLink(link.getOrderNo());
        }
    }
}
