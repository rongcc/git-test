/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import javax.sql.DataSource;

/**
 *
 * @author zhourongchao
 */
public class BfhDcService {

    /**
     * get the next order no.
     */
    public String getNextNo(DataSource ds) {
        String nextNo = "";
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            StringBuffer sb = new StringBuffer();
            Calendar rightNow = Calendar.getInstance();
            int y = rightNow.get(Calendar.YEAR);
            conn = ds.getConnection();
            //取原表
            String sqlStr = "select max(dc_no) from bfh_dc";
            pStmt = conn.prepareStatement(sqlStr);
            rs = pStmt.executeQuery();
            String no = null;
            if (rs.next()) {
                no = rs.getString(1);
            }
            //根据查询结果运算
            if (no != null && no.length() > 4) {
                int lastYear = 2000 + Integer.parseInt(no.substring(2, 4));
                if (y > lastYear) {
                    nextNo = sb.append("DC").append(String.valueOf(y).substring(2)).append("000001").toString();
                } else {
                    int ino = Integer.parseInt(no.substring(4));
                    nextNo = sb.append("DC").append(String.valueOf(y).substring(2)).append(String.valueOf(1000001 + ino).substring(1)).toString();
                }
            } else {
                nextNo = sb.append("DC").append(String.valueOf(y).substring(2)).append("000001").toString();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return nextNo;
    }

    /**
     * 获得对策的所有对策变更
     * @param ds
     * @param orderNo
     * @return
     */
    public List getDcBgList(DataSource ds, String orderNo) {
        List dList = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            //
            String sqlStr = "SELECT dc_bg_no FROM bfh_dc_bg where dc_nor='" + orderNo + "' and status<>-1";
            pStmt = conn.prepareStatement(sqlStr);
            rs = pStmt.executeQuery();
            dList = new ArrayList();
            while (rs.next()) {
                dList.add(rs.getString(1));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return dList;
    }

    /**
     * 获得该对策下的所有验证
     * @param ds
     * @param orderNo
     * @return
     */
    public List getYanzhengList(DataSource ds, String orderNo) {
        List dList = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            //
            String sqlStr = "SELECT yanzheng_no FROM bfh_yanzheng_jilu where is_jietihou is false and source_orde='" + orderNo + "' and status<>-1";
            pStmt = conn.prepareStatement(sqlStr);
            rs = pStmt.executeQuery();
            dList = new ArrayList();
            while (rs.next()) {
                dList.add(rs.getString(1));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return dList;
    }

    /**
     * 该对策下的所有进度记录
     * @param ds
     * @param orderNo
     * @return
     */
    public List getJinduList(DataSource ds, String orderNo) {
        List dList = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            //
            String sqlStr = "SELECT jindu_biaoz_no FROM bfh_jindu_jilu where source_orde='" + orderNo + "' and status<>-1";
            pStmt = conn.prepareStatement(sqlStr);
            rs = pStmt.executeQuery();
            dList = new ArrayList();
            while (rs.next()) {
                dList.add(rs.getString(1));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return dList;
    }
}
