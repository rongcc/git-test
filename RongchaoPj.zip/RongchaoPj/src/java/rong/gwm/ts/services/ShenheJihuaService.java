/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.services;

import java.util.List;
import javax.sql.DataSource;
import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rong.gwm.ts.dto.ShenheJihuaItem;

/**
 *
 * @author zhourongchao
 */
public class ShenheJihuaService {

    /**
     * 获取审核计划下的具体安排表
     * @param ds
     * @param orderNo
     * @return
     */
    public List findItemList(DataSource ds, int orderNo) {
        List al = null;
        try {
            Dao dao = new NutDao(ds);
            al = dao.query(ShenheJihuaItem.class, Cnd.where("shenhe_jihua_no", "=", orderNo).asc("item_no"), null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return al;
    }
   
}
