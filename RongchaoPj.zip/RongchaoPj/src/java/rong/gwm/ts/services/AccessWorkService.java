/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.sql.DataSource;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rong.gwm.ts.dto.AccessWork;

/**
 *
 * @author ZhouRongChao
 */
public class AccessWorkService {

    public AccessWork fetch(DataSource ds, String codeType, String code) {
        AccessWork cd = null;
        try {
            Dao dao = new NutDao(ds);
            cd = dao.fetchx(AccessWork.class, codeType, code);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cd;
    }

    public int delete(DataSource ds, AccessWork cd) {
        int di = 0;
        try {
            Dao dao = new NutDao(ds);
            di = dao.deletex(AccessWork.class, cd.getOperNo(), cd.getAccessWork());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return di;
    }

    /**
     * 删除一个用户所有的‘我的工作’
     * @param ds
     * @param cd
     * @return
     */
    public int deleteOperWorks(DataSource ds, String oper) {
        int di = 0;
        Connection conn = null;
        PreparedStatement pStmt = null;
        try {
            conn = ds.getConnection();
            String sqlStr = "delete FROM access_work where oper_no=? ";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, oper);
            di = pStmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return di;
    }

    /**
     * 是否定制了此工作项。
     * @param ds
     * @param operNo
     * @param accessWork
     * @return
     */
    public boolean isChecked(DataSource ds, String operNo, String accessWork) {
        boolean boo = false;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            String sqlStr = "SELECT count(1) FROM access_work where oper_no=? and access_work=? ";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, operNo);
            pStmt.setString(2, accessWork);
            rs = pStmt.executeQuery();
            if (rs.next()) {
                if (1 <= rs.getInt(1)) {
                    boo = true;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return boo;
    }
}
