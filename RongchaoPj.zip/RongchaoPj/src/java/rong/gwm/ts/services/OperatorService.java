/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.Date;
import javax.sql.DataSource;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rong.gwm.ts.dto.AccessMenu;
import rong.gwm.ts.dto.AccessRight;
import rong.gwm.ts.dto.Operator;

/**
 *
 * @author zhourongchao
 */
public class OperatorService {

    /**
     * 获取用户详细信息
     * @param ds
     * @param orderNo
     * @return
     */
    public Operator findOperator(DataSource ds, String orderNo) {
        Operator order = null;
        try {
            Dao dao = new NutDao(ds);
            order = dao.fetch(Operator.class, orderNo);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return order;
    }

    /**
     * 获取用户姓名
     * @param ds
     * @param orderNo
     * @return
     */
    public String getOperName(DataSource ds, String orderNo) {
        if (orderNo == null) {
            return null;
        }
        String dStr = "";
        Operator order = null;
        try {
            Dao dao = new NutDao(ds);
            order = dao.fetch(Operator.class, orderNo);
            if (order != null) {
                dStr = order.getOperName();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return dStr;
    }

    /**
     * 获取用户所在部门编号
     * @param ds
     * @param orderNo
     * @return
     */
    public String getOperDeptNo(DataSource ds, String orderNo) {
        String dStr = "";
        Operator order = null;
        try {
            Dao dao = new NutDao(ds);
            order = dao.fetch(Operator.class, orderNo);
            if (order != null) {
                dStr = order.getDeptNo();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return dStr;
    }

    /**
     * 获取用户所在部门名称
     * @param ds
     * @param orderNo
     * @return
     */
    public String getOperDeptName(DataSource ds, String orderNo) {
        String dStr = "";
        Operator order = null;
        try {
            Dao dao = new NutDao(ds);
            order = dao.fetch(Operator.class, orderNo);
            if (order != null) {
                dStr = order.getDeptName();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return dStr;
    }

    /**
     * 验证用户是否有此页面的权限
     * @param ds
     * @param ur
     * @param ap
     * @return
     */
    public boolean hasRight(DataSource ds, String ur, String ap) {
        boolean dBoo = false;
        try {
            Dao dao = new NutDao(ds);
            if (dao.fetchx(AccessRight.class, ur, ap) != null) {
                dBoo = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return dBoo;
    }

    /**
     * 验证用户是否有此页面的此项功能的权限
     * @param ds
     * @param ur
     * @param ap
     * @param apd
     * @return
     */
    public boolean hasRight(DataSource ds, String ur, String ap, String apr) {
        boolean dBoo = false;
        int di = 0;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            String sqlStr = "SELECT count(1) FROM access_right where oper_no=? and "
                    + "access_page=? and "
                    + apr + " = 'Y'";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, ur);
            pStmt.setString(2, ap);
            rs = pStmt.executeQuery();
            if (rs.next()) {
                di = rs.getInt(1);
            }
            if (di >= 1) {
                dBoo = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return dBoo;
    }

    /**
     * 用户登录，如果成功返回1否则返回0。
     * @param ds
     * @param u
     * @param p
     * @return
     */
    public int doLogin(DataSource ds, String u, String p) {
        int di = 0;
        Operator order = null;
        try {
            Dao dao = new NutDao(ds);
            order = dao.fetch(Operator.class, u);
            //比较区分一下大小写
            if (order.getOperNo().equals(u)) {
                if (order != null && order.getStatus() != -1) {
                    if (order.getPasswd().equals(p)) {
                        di = 1;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return di;
    }

    /**
     * 记录下用户最后登录的IP与时间。
     * @param ds
     * @param u
     * @param ip
     */
    public void upIpDate(DataSource ds, String u, String ip) {
        Operator order = null;
        try {
            Date now = null;
            Calendar rightNow = Calendar.getInstance();
            now = rightNow.getTime();
            Dao dao = new NutDao(ds);
            order = dao.fetch(Operator.class, u);
            if (order != null && order.getStatus() != -1) {
                order.setLastLoginDate(order.getCurrentLoginDate());
                order.setLastLoginIp(order.getCurrentLoginIp());
                order.setCurrentLoginDate(now);
                order.setCurrentLoginIp(ip);
                dao.update(order);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 是否有此菜单权限
     * @param ds
     * @param ur
     * @param menu
     * @return
     */
    public boolean hasMenuRight(DataSource ds, String ur, String menu) {
        boolean dBoo = false;
        try {
            Dao dao = new NutDao(ds);
            if (dao.fetchx(AccessMenu.class, ur, menu) != null) {
                dBoo = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return dBoo;
    }

    /**
     * 获取此用户在此数据项的数据访问范围。0表示彻底没有权限，
     * 10表示个人录入的数据，20表示本部门录入的数据，30表示所有数据不限制。
     * @param ds
     * @param ur
     * @param ap
     * @return
     */
    public int getDataScope(DataSource ds, String ur, String ap) {
        int di = 0;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            String sqlStr = "SELECT data_scope FROM access_right where oper_no=? and access_page=?";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, ur);
            pStmt.setString(2, ap);
            rs = pStmt.executeQuery();
            if (rs.next()) {
                di = rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return di;
    }

    /**
     * 获得用户的种类，0为普通用户1为一级管理员2为各部门管理员。
     * @param ds
     * @param ur
     * @return
     */
    public int getOperStatus(DataSource ds, String ur) {
        int di = 0;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            String sqlStr = "SELECT oper_status FROM operator where oper_no=? ";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, ur);
            rs = pStmt.executeQuery();
            if (rs.next()) {
                di = rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return di;
    }
}
