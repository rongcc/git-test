/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.util;

/**
 *
 * @author zhourongchao
 */
public class Sys2Sys {

    /**
     * 获得尾字符。
     * @param str
     * @return
     */
    public char getTailChar(String str) {
        char iChar = ' ';
        try {
            iChar = str.charAt(str.length() - 1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return iChar;
    }

    /**
     * 用户名加密尾字符。
     * @param str
     * @return
     */
    public char gushuEmOne(char c) {
        char miChar = '0';
        try {
            switch (c) {
                case '1':
                    miChar = 'j';
                    break;
                case '2':
                    miChar = 'y';
                    break;
                case '3':
                    miChar = 'b';
                    break;
                case '4':
                    miChar = 'd';
                    break;
                case '5':
                    miChar = 'w';
                    break;
                case '6':
                    miChar = 'i';
                    break;
                case '7':
                    miChar = 'g';
                    break;
                case '8':
                    miChar = 'x';
                    break;
                case '9':
                    miChar = 'r';
                    break;
                case '0':
                    miChar = 'u';
                    break;
                default:
                    miChar = c;
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return miChar;
    }

    /**
     * 用户名解密尾字符
     * @param c
     * @return
     */
    public char gushuDmOne(char c) {
        char miChar = c;
        try {
            switch (c) {
                case 'j':
                    miChar = '1';
                    break;
                case 'y':
                    miChar = '2';
                    break;
                case 'b':
                    miChar = '3';
                    break;
                case 'd':
                    miChar = '4';
                    break;
                case 'w':
                    miChar = '5';
                    break;
                case 'i':
                    miChar = '6';
                    break;
                case 'g':
                    miChar = '7';
                    break;
                case 'x':
                    miChar = '8';
                    break;
                case 'r':
                    miChar = '9';
                    break;
                case 'u':
                    miChar = '0';
                    break;
                default:
                    miChar = c;
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return miChar;
    }

    /**
     * 适用于IP地址与long时间。
     * 解密加密后的IP地址。
     * 时间参数传递毫秒数即可。将毫秒数字符串加密为字母。
     * @param str
     * @return
     */
    public String gushuEm(String str) {
        StringBuilder miStr = new StringBuilder();
        //IP地址加密方法
        try {
            char iChar;
            for (int i = 0; i < str.length(); i++) {
                iChar = str.charAt(i);
                switch (iChar) {
                    case '1':
                        miStr.append('j');
                        break;
                    case '2':
                        miStr.append('y');
                        break;
                    case '3':
                        miStr.append('b');
                        break;
                    case '4':
                        miStr.append('d');
                        break;
                    case '5':
                        miStr.append('w');
                        break;
                    case '6':
                        miStr.append('i');
                        break;
                    case '7':
                        miStr.append('g');
                        break;
                    case '8':
                        miStr.append('x');
                        break;
                    case '9':
                        miStr.append('r');
                        break;
                    case '0':
                        miStr.append('u');
                        break;
                    case '.':
                        miStr.append('o');
                        break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return miStr.toString();
    }

    /**
     * 适用于IP地址与long时间。
     * 解密加密后的IP地址。
     * 时间参数传递毫秒数即可。将毫秒数字符串加密为字母。
     * @param str
     * @return
     */
    public String gushuDm(String str) {
        StringBuilder miStr = new StringBuilder();
        //IP地址加密方法
        try {
            char iChar;
            for (int i = 0; i < str.length(); i++) {
                iChar = str.charAt(i);
                switch (iChar) {
                    case 'j':
                        miStr.append('1');
                        break;
                    case 'y':
                        miStr.append('2');
                        break;
                    case 'b':
                        miStr.append('3');
                        break;
                    case 'd':
                        miStr.append('4');
                        break;
                    case 'w':
                        miStr.append('5');
                        break;
                    case 'i':
                        miStr.append('6');
                        break;
                    case 'g':
                        miStr.append('7');
                        break;
                    case 'x':
                        miStr.append('8');
                        break;
                    case 'r':
                        miStr.append('9');
                        break;
                    case 'u':
                        miStr.append('0');
                        break;
                    case 'o':
                        miStr.append('.');
                        break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return miStr.toString();
    }

    /**
     * 用此方法把用户名中的数字加密为符号。
     * @param str
     * @return
     */
    public String sfuEm(String str) {
        StringBuilder miStr = new StringBuilder();
        //数字变符号的加密方法
        try {
            char iChar;
            for (int i = 0; i < str.length(); i++) {
                iChar = str.charAt(i);
                switch (iChar) {
                    case '1':
                        miStr.append(',');
                        break;
                    case '2':
                        miStr.append('.');
                        break;
                    case '3':
                        miStr.append('!');
                        break;
                    case '4':
                        miStr.append(':');
                        break;
                    case '5':
                        miStr.append('^');
                        break;
                    case '6':
                        miStr.append('*');
                        break;
                    case '7':
                        miStr.append('(');
                        break;
                    case '8':
                        miStr.append(')');
                        break;
                    case '9':
                        miStr.append('[');
                        break;
                    case '0':
                        miStr.append(']');
                        break;
                    default:
                        miStr.append(iChar);
                        break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return miStr.toString();
    }

    /**
     * 把用户名中的符号解密出数字。
     * @param str
     * @return
     */
    public String sfuDm(String str) {
        StringBuilder miStr = new StringBuilder();
        //IP地址加密方法
        try {
            char iChar;
            for (int i = 0; i < str.length(); i++) {
                iChar = str.charAt(i);
                switch (iChar) {
                    case ',':
                        miStr.append('1');
                        break;
                    case '.':
                        miStr.append('2');
                        break;
                    case '!':
                        miStr.append('3');
                        break;
                    case ':':
                        miStr.append('4');
                        break;
                    case '^':
                        miStr.append('5');
                        break;
                    case '*':
                        miStr.append('6');
                        break;
                    case '(':
                        miStr.append('7');
                        break;
                    case ')':
                        miStr.append('8');
                        break;
                    case '[':
                        miStr.append('9');
                        break;
                    case ']':
                        miStr.append('0');
                        break;
                    default:
                        miStr.append(iChar);
                        break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return miStr.toString();
    }
}
