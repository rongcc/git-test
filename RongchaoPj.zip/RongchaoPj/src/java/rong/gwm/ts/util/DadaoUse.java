/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.util;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 *
 * @author zhourongchao
 */
public class DadaoUse {

    private static DadaoUse me;

    static {
        try {
            me = new DadaoUse();
        } catch (Exception se) {
            throw new RuntimeException(se);
        }
    }

    /** Creates a new instance of DadaoUse */
    public DadaoUse() {
    }

    public static DadaoUse getInstance() {
        return me;
    }

    /**
     * 获得现在的日期时间
     * @return
     */
    public Date getNow() {
        Date now = null;
        Calendar rightNow = Calendar.getInstance();
        now = rightNow.getTime();
        // now=new Date();
        return now;
    }

    /**
     * Get today and time as a String E.g. "2006/8/26 17:24:23"
     */
    public String getDateTime() {
        Calendar rightNow = Calendar.getInstance();
        int y = rightNow.get(Calendar.YEAR);
        int m = rightNow.get(Calendar.MONTH);
        int d = rightNow.get(Calendar.DAY_OF_MONTH);
        int h = rightNow.get(Calendar.HOUR_OF_DAY);
        int minute = rightNow.get(Calendar.MINUTE);
        int s = rightNow.get(Calendar.SECOND);
        StringBuffer sb = new StringBuffer();
        return sb.append(y).append("/").append(m + 1).append("/").append(d).append(" ").append(h).append(":").append(minute).append(":").append(s).toString();
    }

    /**
     * Get today as a String E.g. "2006/8/26"
     */
    public String getToday() {
        //TODO implement getToday
        Calendar rightNow = Calendar.getInstance();
        int y = rightNow.get(Calendar.YEAR);
        int m = rightNow.get(Calendar.MONTH);
        int d = rightNow.get(Calendar.DAY_OF_MONTH);
        StringBuffer sb = new StringBuffer();
        return sb.append(y).append("/").append(m + 1).append("/").append(d).toString();
    }

    /**
     * Get today as a String E.g. "2006-8-26"
     */
    public String getFormatToday() {
        Date now = new Date();
        DateFormat df = DateFormat.getDateInstance();
        return df.format(now);
    }

    public String formatRiQiDate(Date dt) {
        if (dt == null) {
            return "";
        }
        //DateFormat df = DateFormat.getDateInstance(DateFormat.DEFAULT);
        //return df.format(dt);
        java.text.DateFormat format1 = new java.text.SimpleDateFormat("yyyy-MM-dd");
        return format1.format(dt);
    }

    public String formatRiQiShiJianDate(Date dt) {
        if (dt == null) {
            return "";
        }
        java.text.DateFormat format1 = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return format1.format(dt);
    }

    /**
     *
     * @param str
     * @return
     */
    public String takeString(String str) {
        String myStr = "";
        if (str != null && !str.equals("null")) {
            myStr = str;
        }
        return myStr;
    }

    /**
     * 计算所剩天数
     * @param pdate 开始日期时间
     * @param xDay 设限天数
     * @return 到现在所剩天数
     */
    public int getRemantDay(Date pdate, int xDay) {
        int rd = 0;
        try {
            Calendar rightNow = Calendar.getInstance();
            long nl = rightNow.getTimeInMillis();
            long tl = pdate.getTime();
            //从毫秒换算成天
            float ntf = nl / 86400000 - tl / 86400000;
            //System.out.println(ntf);
            //取最接近的整数
            int nti = Math.round(ntf);
            //用设限天数减去已经过去的天数
            rd = xDay - nti;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rd;
    }

    /**
     * MD5 加密
     */
    public String getMD5Str(String str) {
        MessageDigest messageDigest = null;

        try {
            messageDigest = MessageDigest.getInstance("MD5");

            messageDigest.reset();

            messageDigest.update(str.getBytes("UTF-8"));
        } catch (NoSuchAlgorithmException e) {
            System.out.println("NoSuchAlgorithmException caught!");
            System.exit(-1);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        byte[] byteArray = messageDigest.digest();

        StringBuffer md5StrBuff = new StringBuffer();

        for (int i = 0; i < byteArray.length; i++) {
            if (Integer.toHexString(0xFF & byteArray[i]).length() == 1) {
                md5StrBuff.append("0").append(Integer.toHexString(0xFF & byteArray[i]));
            } else {
                md5StrBuff.append(Integer.toHexString(0xFF & byteArray[i]));
            }
        }

        return md5StrBuff.toString();
    }
}
