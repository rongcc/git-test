/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.dto;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.PK;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("om_pingfen_guocheng_history")
@PK({"guochengId", "period"})
public class OmPingfenGuochengHistory {

    @Column("guocheng_id")
    private Integer guochengId;
    @Column("pingfen")
    private double pingfen;
    @Column("period")
    private int period;
    @Column("guocheng_name")
    private String guochengName;
    @Column("org_id")
    private Integer orgId;

    /**
     * @return the guochengId
     */
    public Integer getGuochengId() {
        return guochengId;
    }

    /**
     * @param guochengId the guochengId to set
     */
    public void setGuochengId(Integer guochengId) {
        this.guochengId = guochengId;
    }

    /**
     * @return the pingfen
     */
    public double getPingfen() {
        return pingfen;
    }

    /**
     * @param pingfen the pingfen to set
     */
    public void setPingfen(double pingfen) {
        this.pingfen = pingfen;
    }

    /**
     * @return the period
     */
    public int getPeriod() {
        return period;
    }

    /**
     * @param period the period to set
     */
    public void setPeriod(int period) {
        this.period = period;
    }

    /**
     * @return the guochengName
     */
    public String getGuochengName() {
        return guochengName;
    }

    /**
     * @param guochengName the guochengName to set
     */
    public void setGuochengName(String guochengName) {
        this.guochengName = guochengName;
    }

    /**
     * @return the orgId
     */
    public Integer getOrgId() {
        return orgId;
    }

    /**
     * @param orgId the orgId to set
     */
    public void setOrgId(Integer orgId) {
        this.orgId = orgId;
    }
}
