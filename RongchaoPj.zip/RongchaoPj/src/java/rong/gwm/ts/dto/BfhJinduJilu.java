/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package rong.gwm.ts.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Name;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("bfh_jindu_jilu")
public class BfhJinduJilu {


    @Column("jindu_biaoz_no")
    @Name
    private String jinduBiaozNo;
    @Column("now_jindu")
    private String nowJindu;
    @Column("jindu_shuoming")
    private String jinduShuoming;
    @Column("biaoz_ren")
    private String biaozRen;
    @Column("bfh_no")
    private String bfhNo;
    @Column("biaoz_date")
    private Date biaozDate;
    @Column("remark")
    private String remark;
    @Column("status")
    private int status;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;
    @Column("edit_date")
    private Date editDate;
    @Column("edit_name")
    private String editName;
    @Column("post_date")
    private Date postDate;
    @Column("post_name")
    private String postName;
    @Column("source_order")
    private String sourceOrder;
    @Column("status_tj")
    private boolean statusTj;
    @Column("tj_post")
    private String tjPost;
    @Column("tj_post2")
    private String tjPost2;

    /**
     * @return the jinduBiaozNo
     */
    public String getJinduBiaozNo() {
        return jinduBiaozNo;
    }

    /**
     * @param jinduBiaozNo the jinduBiaozNo to set
     */
    public void setJinduBiaozNo(String jinduBiaozNo) {
        this.jinduBiaozNo = jinduBiaozNo;
    }

    /**
     * @return the nowJindu
     */
    public String getNowJindu() {
        return nowJindu;
    }

    /**
     * @param nowJindu the nowJindu to set
     */
    public void setNowJindu(String nowJindu) {
        this.nowJindu = nowJindu;
    }

    /**
     * @return the jinduShuoming
     */
    public String getJinduShuoming() {
        return jinduShuoming;
    }

    /**
     * @param jinduShuoming the jinduShuoming to set
     */
    public void setJinduShuoming(String jinduShuoming) {
        this.jinduShuoming = jinduShuoming;
    }

    /**
     * @return the biaozRen
     */
    public String getBiaozRen() {
        return biaozRen;
    }

    /**
     * @param biaozRen the biaozRen to set
     */
    public void setBiaozRen(String biaozRen) {
        this.biaozRen = biaozRen;
    }

    /**
     * @return the bfhNo
     */
    public String getBfhNo() {
        return bfhNo;
    }

    /**
     * @param bfhNo the bfhNo to set
     */
    public void setBfhNo(String bfhNo) {
        this.bfhNo = bfhNo;
    }

    /**
     * @return the biaozDate
     */
    public Date getBiaozDate() {
        return biaozDate;
    }

    /**
     * @param biaozDate the biaozDate to set
     */
    public void setBiaozDate(Date biaozDate) {
        this.biaozDate = biaozDate;
    }

    /**
     * @return the remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * @param remark the remark to set
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    /**
     * @return the editDate
     */
    public Date getEditDate() {
        return editDate;
    }

    /**
     * @param editDate the editDate to set
     */
    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }

    /**
     * @return the editName
     */
    public String getEditName() {
        return editName;
    }

    /**
     * @param editName the editName to set
     */
    public void setEditName(String editName) {
        this.editName = editName;
    }

    /**
     * @return the postDate
     */
    public Date getPostDate() {
        return postDate;
    }

    /**
     * @param postDate the postDate to set
     */
    public void setPostDate(Date postDate) {
        this.postDate = postDate;
    }

    /**
     * @return the postName
     */
    public String getPostName() {
        return postName;
    }

    /**
     * @param postName the postName to set
     */
    public void setPostName(String postName) {
        this.postName = postName;
    }

    /**
     * @return the sourceOrder
     */
    public String getSourceOrder() {
        return sourceOrder;
    }

    /**
     * @param sourceOrder the sourceOrder to set
     */
    public void setSourceOrder(String sourceOrder) {
        this.sourceOrder = sourceOrder;
    }

    /**
     * @return the statusTj
     */
    public boolean isStatusTj() {
        return statusTj;
    }

    /**
     * @param statusTj the statusTj to set
     */
    public void setStatusTj(boolean statusTj) {
        this.statusTj = statusTj;
    }

    /**
     * @return the tjPost
     */
    public String getTjPost() {
        return tjPost;
    }

    /**
     * @param tjPost the tjPost to set
     */
    public void setTjPost(String tjPost) {
        this.tjPost = tjPost;
    }

    /**
     * @return the tjPost2
     */
    public String getTjPost2() {
        return tjPost2;
    }

    /**
     * @param tjPost2 the tjPost2 to set
     */
    public void setTjPost2(String tjPost2) {
        this.tjPost2 = tjPost2;
    }

}
