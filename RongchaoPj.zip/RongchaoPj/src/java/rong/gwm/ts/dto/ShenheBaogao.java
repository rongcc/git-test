/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("shenhe_baogao")
public class ShenheBaogao {

    @Column("shenhe_baogao_no")
    @Id
    private Integer shenheBaogaoNo;
    @Column("title")
    private String title;
    @Column("zhuti")
    private String zhuti;
    @Column("bianhao")
    private String bianhao;
    @Column("shibiehao")
    private String shibiehao;
    @Column("shenhe_mudi")
    private String shenheMudi;
    @Column("shenhe_fanwei")
    private String shenheFanwei;
    @Column("shenhe_yiju")
    private String shenheYiju;
    @Column("shenhe_date")
    private Date shenheDate;
    @Column("shenhezu_anpai")
    private String shenhezuAnpai;
    @Column("shenhe_leixing")
    private String shenheLeixing;
    @Column("shenhe_fangfa")
    private String shenheFangfa;
    @Column("shenhe_guoch_zshu")
    private String shenheGuochZshu;
    @Column("dui_tixi_pingjia")
    private String duiTixiPingjia;
    @Column("shenhe_jielun")
    private String shenheJielun;
    @Column("zhenggai_yaoqiu")
    private String zhenggaiYaoqiu;
    @Column("bianzhi")
    private String bianzhi;
    @Column("shenhe")
    private String shenhe;
    @Column("pizhun")
    private String pizhun;
    @Column("riqi")
    private Date riqi;
    @Column("remark")
    private String remark;
    @Column("status")
    private int status;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;
    @Column("edit_date")
    private Date editDate;
    @Column("edit_name")
    private String editName;
    @Column("post_date")
    private Date postDate;
    @Column("post_name")
    private String postName;
    @Column("source_order")
    private String sourceOrder;
    @Column("shenhe_renyuan")
    private String shenheRenyuan;
    @Column("shenhe_riqi")
    private String shenheRiqi;
    @Column("post2_date")
    private Date post2Date;
    @Column("post2_name")
    private String post2Name;
    @Column("status_tj")
    private boolean statusTj;
    @Column("tj_post")
    private String tjPost;
    @Column("tj_post2")
    private String tjPost2;

    /**
     * @return the shenheBaogaoNo
     */
    public Integer getShenheBaogaoNo() {
        return shenheBaogaoNo;
    }

    /**
     * @param shenheBaogaoNo the shenheBaogaoNo to set
     */
    public void setShenheBaogaoNo(Integer shenheBaogaoNo) {
        this.shenheBaogaoNo = shenheBaogaoNo;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @return the zhuti
     */
    public String getZhuti() {
        return zhuti;
    }

    /**
     * @param zhuti the zhuti to set
     */
    public void setZhuti(String zhuti) {
        this.zhuti = zhuti;
    }

    /**
     * @return the bianhao
     */
    public String getBianhao() {
        return bianhao;
    }

    /**
     * @param bianhao the bianhao to set
     */
    public void setBianhao(String bianhao) {
        this.bianhao = bianhao;
    }

    /**
     * @return the shibiehao
     */
    public String getShibiehao() {
        return shibiehao;
    }

    /**
     * @param shibiehao the shibiehao to set
     */
    public void setShibiehao(String shibiehao) {
        this.shibiehao = shibiehao;
    }

    /**
     * @return the shenheMudi
     */
    public String getShenheMudi() {
        return shenheMudi;
    }

    /**
     * @param shenheMudi the shenheMudi to set
     */
    public void setShenheMudi(String shenheMudi) {
        this.shenheMudi = shenheMudi;
    }

    /**
     * @return the shenheFanwei
     */
    public String getShenheFanwei() {
        return shenheFanwei;
    }

    /**
     * @param shenheFanwei the shenheFanwei to set
     */
    public void setShenheFanwei(String shenheFanwei) {
        this.shenheFanwei = shenheFanwei;
    }

    /**
     * @return the shenheYiju
     */
    public String getShenheYiju() {
        return shenheYiju;
    }

    /**
     * @param shenheYiju the shenheYiju to set
     */
    public void setShenheYiju(String shenheYiju) {
        this.shenheYiju = shenheYiju;
    }

    /**
     * @return the shenheDate
     */
    public Date getShenheDate() {
        return shenheDate;
    }

    /**
     * @param shenheDate the shenheDate to set
     */
    public void setShenheDate(Date shenheDate) {
        this.shenheDate = shenheDate;
    }

    /**
     * @return the shenhezuAnpai
     */
    public String getShenhezuAnpai() {
        return shenhezuAnpai;
    }

    /**
     * @param shenhezuAnpai the shenhezuAnpai to set
     */
    public void setShenhezuAnpai(String shenhezuAnpai) {
        this.shenhezuAnpai = shenhezuAnpai;
    }

    /**
     * @return the shenheLeixing
     */
    public String getShenheLeixing() {
        return shenheLeixing;
    }

    /**
     * @param shenheLeixing the shenheLeixing to set
     */
    public void setShenheLeixing(String shenheLeixing) {
        this.shenheLeixing = shenheLeixing;
    }

    /**
     * @return the shenheFangfa
     */
    public String getShenheFangfa() {
        return shenheFangfa;
    }

    /**
     * @param shenheFangfa the shenheFangfa to set
     */
    public void setShenheFangfa(String shenheFangfa) {
        this.shenheFangfa = shenheFangfa;
    }

    /**
     * @return the shenheGuochZshu
     */
    public String getShenheGuochZshu() {
        return shenheGuochZshu;
    }

    /**
     * @param shenheGuochZshu the shenheGuochZshu to set
     */
    public void setShenheGuochZshu(String shenheGuochZshu) {
        this.shenheGuochZshu = shenheGuochZshu;
    }

    /**
     * @return the duiTixiPingjia
     */
    public String getDuiTixiPingjia() {
        return duiTixiPingjia;
    }

    /**
     * @param duiTixiPingjia the duiTixiPingjia to set
     */
    public void setDuiTixiPingjia(String duiTixiPingjia) {
        this.duiTixiPingjia = duiTixiPingjia;
    }

    /**
     * @return the shenheJielun
     */
    public String getShenheJielun() {
        return shenheJielun;
    }

    /**
     * @param shenheJielun the shenheJielun to set
     */
    public void setShenheJielun(String shenheJielun) {
        this.shenheJielun = shenheJielun;
    }

    /**
     * @return the zhenggaiYaoqiu
     */
    public String getZhenggaiYaoqiu() {
        return zhenggaiYaoqiu;
    }

    /**
     * @param zhenggaiYaoqiu the zhenggaiYaoqiu to set
     */
    public void setZhenggaiYaoqiu(String zhenggaiYaoqiu) {
        this.zhenggaiYaoqiu = zhenggaiYaoqiu;
    }

    /**
     * @return the bianzhi
     */
    public String getBianzhi() {
        return bianzhi;
    }

    /**
     * @param bianzhi the bianzhi to set
     */
    public void setBianzhi(String bianzhi) {
        this.bianzhi = bianzhi;
    }

    /**
     * @return the shenhe
     */
    public String getShenhe() {
        return shenhe;
    }

    /**
     * @param shenhe the shenhe to set
     */
    public void setShenhe(String shenhe) {
        this.shenhe = shenhe;
    }

    /**
     * @return the pizhun
     */
    public String getPizhun() {
        return pizhun;
    }

    /**
     * @param pizhun the pizhun to set
     */
    public void setPizhun(String pizhun) {
        this.pizhun = pizhun;
    }

    /**
     * @return the riqi
     */
    public Date getRiqi() {
        return riqi;
    }

    /**
     * @param riqi the riqi to set
     */
    public void setRiqi(Date riqi) {
        this.riqi = riqi;
    }

    /**
     * @return the remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * @param remark the remark to set
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    /**
     * @return the editDate
     */
    public Date getEditDate() {
        return editDate;
    }

    /**
     * @param editDate the editDate to set
     */
    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }

    /**
     * @return the editName
     */
    public String getEditName() {
        return editName;
    }

    /**
     * @param editName the editName to set
     */
    public void setEditName(String editName) {
        this.editName = editName;
    }

    /**
     * @return the postDate
     */
    public Date getPostDate() {
        return postDate;
    }

    /**
     * @param postDate the postDate to set
     */
    public void setPostDate(Date postDate) {
        this.postDate = postDate;
    }

    /**
     * @return the postName
     */
    public String getPostName() {
        return postName;
    }

    /**
     * @param postName the postName to set
     */
    public void setPostName(String postName) {
        this.postName = postName;
    }

    /**
     * @return the sourceOrder
     */
    public String getSourceOrder() {
        return sourceOrder;
    }

    /**
     * @param sourceOrder the sourceOrder to set
     */
    public void setSourceOrder(String sourceOrder) {
        this.sourceOrder = sourceOrder;
    }

    /**
     * @return the shenheRenyuan
     */
    public String getShenheRenyuan() {
        return shenheRenyuan;
    }

    /**
     * @param shenheRenyuan the shenheRenyuan to set
     */
    public void setShenheRenyuan(String shenheRenyuan) {
        this.shenheRenyuan = shenheRenyuan;
    }

    /**
     * @return the shenheRiqi
     */
    public String getShenheRiqi() {
        return shenheRiqi;
    }

    /**
     * @param shenheRiqi the shenheRiqi to set
     */
    public void setShenheRiqi(String shenheRiqi) {
        this.shenheRiqi = shenheRiqi;
    }

   

    /**
     * @return the post2Name
     */
    public String getPost2Name() {
        return post2Name;
    }

    /**
     * @param post2Name the post2Name to set
     */
    public void setPost2Name(String post2Name) {
        this.post2Name = post2Name;
    }

    /**
     * @return the post2Date
     */
    public Date getPost2Date() {
        return post2Date;
    }

    /**
     * @param post2Date the post2Date to set
     */
    public void setPost2Date(Date post2Date) {
        this.post2Date = post2Date;
    }

    /**
     * @return the statusTj
     */
    public boolean isStatusTj() {
        return statusTj;
    }

    /**
     * @param statusTj the statusTj to set
     */
    public void setStatusTj(boolean statusTj) {
        this.statusTj = statusTj;
    }

    /**
     * @return the tjPost
     */
    public String getTjPost() {
        return tjPost;
    }

    /**
     * @param tjPost the tjPost to set
     */
    public void setTjPost(String tjPost) {
        this.tjPost = tjPost;
    }

    /**
     * @return the tjPost2
     */
    public String getTjPost2() {
        return tjPost2;
    }

    /**
     * @param tjPost2 the tjPost2 to set
     */
    public void setTjPost2(String tjPost2) {
        this.tjPost2 = tjPost2;
    }
}
