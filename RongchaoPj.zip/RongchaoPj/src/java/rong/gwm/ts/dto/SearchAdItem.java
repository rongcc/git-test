/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.dto;

/**
 *
 * @author zhourongchao
 */
public class SearchAdItem {

    private int itemNo;
    private String ao;
    private String kh;
    private String tbCol;
    private String bj;
    private String kwType;
    private Object kw;

    /**
     * @return the itemNo
     */
    public int getItemNo() {
        return itemNo;
    }

    /**
     * @param itemNo the itemNo to set
     */
    public void setItemNo(int itemNo) {
        this.itemNo = itemNo;
    }

    /**
     * @return the ao
     */
    public String getAo() {
        return ao;
    }

    /**
     * @param ao the ao to set
     */
    public void setAo(String ao) {
        this.ao = ao;
    }

    /**
     * @return the kh
     */
    public String getKh() {
        return kh;
    }

    /**
     * @param kh the kh to set
     */
    public void setKh(String kh) {
        this.kh = kh;
    }

    /**
     * @return the tbCol
     */
    public String getTbCol() {
        return tbCol;
    }

    /**
     * @param tbCol the tbCol to set
     */
    public void setTbCol(String tbCol) {
        this.tbCol = tbCol;
    }

    /**
     * @return the bj
     */
    public String getBj() {
        return bj;
    }

    /**
     * @param bj the bj to set
     */
    public void setBj(String bj) {
        this.bj = bj;
    }

    /**
     * @return the kwType
     */
    public String getKwType() {
        return kwType;
    }

    /**
     * @param kwType the kwType to set
     */
    public void setKwType(String kwType) {
        this.kwType = kwType;
    }

    /**
     * @return the kw
     */
    public Object getKw() {
        return kw;
    }

    /**
     * @param kw the kw to set
     */
    public void setKw(Object kw) {
        this.kw = kw;
    }
}
