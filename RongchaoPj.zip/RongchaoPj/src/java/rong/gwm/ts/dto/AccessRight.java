/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.PK;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("access_right")
@PK({"operNo", "accessPage"})
public class AccessRight {

    @Column("oper_no")
    private String operNo;
    @Column("access_page")
    private String accessPage;
    @Column("dept_no")
    private String deptNo;
    @Column("create_right")
    private Character createRight;
    @Column("list_right")
    private Character listRight;
    @Column("detail_right")
    private Character detailRight;
    @Column("edit_right")
    private Character editRight;
    @Column("destroy_right")
    private Character destroyRight;
    @Column("delete_right")
    private Character deleteRight;
    @Column("post_right")
    private Character postRight;
    @Column("post2_right")
    private Character post2Right;
    @Column("cancel_post_right")
    private Character cancelPostRight;
    @Column("cancel_post2_right")
    private Character cancelPost2Right;
    @Column("take1_right")
    private Character take1Right;
    @Column("take2_right")
    private Character take2Right;
    @Column("take3_right")
    private Character take3Right;
    @Column("take4_right")
    private Character take4Right;
    @Column("take5_right")
    private Character take5Right;
    @Column("status")
    private int status;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;
    @Column("post_date")
    private Date postDate;
    @Column("post_name")
    private String postName;
    @Column("post2_date")
    private Date post2Date;
    @Column("post2_name")
    private String post2Name;
    @Column("data_scope")
    private int dataScope;
    @Column("print_right")
    private Character printRight;

    public AccessRight() {
    }

    public AccessRight(String operNo, String accessPage) {
        this.operNo = operNo;
        this.accessPage = accessPage;
    }

    /**
     * @return the operNo
     */
    public String getOperNo() {
        return operNo;
    }

    /**
     * @param operNo the operNo to set
     */
    public void setOperNo(String operNo) {
        this.operNo = operNo;
    }

    /**
     * @return the accessPage
     */
    public String getAccessPage() {
        return accessPage;
    }

    /**
     * @param accessPage the accessPage to set
     */
    public void setAccessPage(String accessPage) {
        this.accessPage = accessPage;
    }

    /**
     * @return the deptNo
     */
    public String getDeptNo() {
        return deptNo;
    }

    /**
     * @param deptNo the deptNo to set
     */
    public void setDeptNo(String deptNo) {
        this.deptNo = deptNo;
    }

    /**
     * @return the createRight
     */
    public Character getCreateRight() {
        return createRight;
    }

    /**
     * @param createRight the createRight to set
     */
    public void setCreateRight(Character createRight) {
        this.createRight = createRight;
    }

    /**
     * @return the listRight
     */
    public Character getListRight() {
        return listRight;
    }

    /**
     * @param listRight the listRight to set
     */
    public void setListRight(Character listRight) {
        this.listRight = listRight;
    }

    /**
     * @return the detailRight
     */
    public Character getDetailRight() {
        return detailRight;
    }

    /**
     * @param detailRight the detailRight to set
     */
    public void setDetailRight(Character detailRight) {
        this.detailRight = detailRight;
    }

    /**
     * @return the editRight
     */
    public Character getEditRight() {
        return editRight;
    }

    /**
     * @param editRight the editRight to set
     */
    public void setEditRight(Character editRight) {
        this.editRight = editRight;
    }

    /**
     * @return the destroyRight
     */
    public Character getDestroyRight() {
        return destroyRight;
    }

    /**
     * @param destroyRight the destroyRight to set
     */
    public void setDestroyRight(Character destroyRight) {
        this.destroyRight = destroyRight;
    }

    /**
     * @return the deleteRight
     */
    public Character getDeleteRight() {
        return deleteRight;
    }

    /**
     * @param deleteRight the deleteRight to set
     */
    public void setDeleteRight(Character deleteRight) {
        this.deleteRight = deleteRight;
    }

    /**
     * @return the postRight
     */
    public Character getPostRight() {
        return postRight;
    }

    /**
     * @param postRight the postRight to set
     */
    public void setPostRight(Character postRight) {
        this.postRight = postRight;
    }

    /**
     * @return the post2Right
     */
    public Character getPost2Right() {
        return post2Right;
    }

    /**
     * @param post2Right the post2Right to set
     */
    public void setPost2Right(Character post2Right) {
        this.post2Right = post2Right;
    }

    /**
     * @return the cancelPostRight
     */
    public Character getCancelPostRight() {
        return cancelPostRight;
    }

    /**
     * @param cancelPostRight the cancelPostRight to set
     */
    public void setCancelPostRight(Character cancelPostRight) {
        this.cancelPostRight = cancelPostRight;
    }

    /**
     * @return the cancelPost2Right
     */
    public Character getCancelPost2Right() {
        return cancelPost2Right;
    }

    /**
     * @param cancelPost2Right the cancelPost2Right to set
     */
    public void setCancelPost2Right(Character cancelPost2Right) {
        this.cancelPost2Right = cancelPost2Right;
    }

    /**
     * @return the take1Right
     */
    public Character getTake1Right() {
        return take1Right;
    }

    /**
     * @param take1Right the take1Right to set
     */
    public void setTake1Right(Character take1Right) {
        this.take1Right = take1Right;
    }

    /**
     * @return the take2Right
     */
    public Character getTake2Right() {
        return take2Right;
    }

    /**
     * @param take2Right the take2Right to set
     */
    public void setTake2Right(Character take2Right) {
        this.take2Right = take2Right;
    }

    /**
     * @return the take3Right
     */
    public Character getTake3Right() {
        return take3Right;
    }

    /**
     * @param take3Right the take3Right to set
     */
    public void setTake3Right(Character take3Right) {
        this.take3Right = take3Right;
    }

    /**
     * @return the take4Right
     */
    public Character getTake4Right() {
        return take4Right;
    }

    /**
     * @param take4Right the take4Right to set
     */
    public void setTake4Right(Character take4Right) {
        this.take4Right = take4Right;
    }

    /**
     * @return the take5Right
     */
    public Character getTake5Right() {
        return take5Right;
    }

    /**
     * @param take5Right the take5Right to set
     */
    public void setTake5Right(Character take5Right) {
        this.take5Right = take5Right;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    /**
     * @return the postDate
     */
    public Date getPostDate() {
        return postDate;
    }

    /**
     * @param postDate the postDate to set
     */
    public void setPostDate(Date postDate) {
        this.postDate = postDate;
    }

    /**
     * @return the postName
     */
    public String getPostName() {
        return postName;
    }

    /**
     * @param postName the postName to set
     */
    public void setPostName(String postName) {
        this.postName = postName;
    }

    /**
     * @return the post2Date
     */
    public Date getPost2Date() {
        return post2Date;
    }

    /**
     * @param post2Date the post2Date to set
     */
    public void setPost2Date(Date post2Date) {
        this.post2Date = post2Date;
    }

    /**
     * @return the post2Name
     */
    public String getPost2Name() {
        return post2Name;
    }

    /**
     * @param post2Name the post2Name to set
     */
    public void setPost2Name(String post2Name) {
        this.post2Name = post2Name;
    }

    /**
     * @return the dataScope
     */
    public int getDataScope() {
        return dataScope;
    }

    /**
     * @param dataScope the dataScope to set
     */
    public void setDataScope(int dataScope) {
        this.dataScope = dataScope;
    }

    /**
     * @return the printRight
     */
    public Character getPrintRight() {
        return printRight;
    }

    /**
     * @param printRight the printRight to set
     */
    public void setPrintRight(Character printRight) {
        this.printRight = printRight;
    }
}
