/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("QP_ProblemReply")
public class QPProblemReply {

    @Column("QP3_ID")
    @Id
    private Integer qp3Id;
    @Column("QP3_OUID")
    private Integer qp3Ouid;
    @Column("QP3_OUCode")
    private String qP3OUCode;
    @Column("QP3_OUName")
    private String qP3OUName;
    @Column("QP3_DepartID")
    private Integer qP3DepartID;
    @Column("QP3_DepartCode")
    private String qP3DepartCode;
    @Column("QP3_DepartName")
    private String qP3DepartName;
    @Column("QP3_UserID")
    private Integer qP3UserID;
    @Column("QP3_UserLoginID")
    private String qP3UserLoginID;
    @Column("QP3_UserName")
    private String qP3UserName;
    @Column("QP3_UserPhone")
    private String qP3UserPhone;
    @Column("QP3_RestrainStep")
    private String qP3RestrainStep;
    @Column("QP3_InspectProcess")
    private String qP3InspectProcess;
    @Column("QP3_ReasonAnalyse")
    private String qP3ReasonAnalyse;
    @Column("QP3_WorkPlan")
    private String qP3WorkPlan;
    @Column("QP3_ModifyPolicy")
    private String qP3ModifyPolicy;
    @Column("QP3_Reflection")
    private String qP3Reflection;
    @Column("QP3_InsideSpread")
    private String qP3InsideSpread;
    @Column("QP3_Standard")
    private String qP3Standard;
    @Column("AD2_ID")
    private Integer ad2Id;
    @Column("QP3_TechnicClose")
    private Boolean qP3TechnicClose;
    @Column("QP3_CancelTimes")
    private Integer qP3CancelTimes;
    @Column("QP3_CancelReason")
    private String qP3CancelReason;
    @Column("CreateDate")
    private Date createDate;
    @Column("CreateUser")
    private String createUser;
    @Column("ReplyDate")
    private String replyDate;
    @Column("ModifyDate")
    private String modifyDate;
    @Column("ModifyUser")
    private String modifyUser;

    /**
     * @return the qp3Id
     */
    public Integer getQp3Id() {
        return qp3Id;
    }

    /**
     * @param qp3Id the qp3Id to set
     */
    public void setQp3Id(Integer qp3Id) {
        this.qp3Id = qp3Id;
    }

    /**
     * @return the qp3Ouid
     */
    public Integer getQp3Ouid() {
        return qp3Ouid;
    }

    /**
     * @param qp3Ouid the qp3Ouid to set
     */
    public void setQp3Ouid(Integer qp3Ouid) {
        this.qp3Ouid = qp3Ouid;
    }

    /**
     * @return the qP3OUCode
     */
    public String getqP3OUCode() {
        return qP3OUCode;
    }

    /**
     * @param qP3OUCode the qP3OUCode to set
     */
    public void setqP3OUCode(String qP3OUCode) {
        this.qP3OUCode = qP3OUCode;
    }

    /**
     * @return the qP3OUName
     */
    public String getqP3OUName() {
        return qP3OUName;
    }

    /**
     * @param qP3OUName the qP3OUName to set
     */
    public void setqP3OUName(String qP3OUName) {
        this.qP3OUName = qP3OUName;
    }

    /**
     * @return the qP3DepartID
     */
    public Integer getqP3DepartID() {
        return qP3DepartID;
    }

    /**
     * @param qP3DepartID the qP3DepartID to set
     */
    public void setqP3DepartID(Integer qP3DepartID) {
        this.qP3DepartID = qP3DepartID;
    }

    /**
     * @return the qP3DepartCode
     */
    public String getqP3DepartCode() {
        return qP3DepartCode;
    }

    /**
     * @param qP3DepartCode the qP3DepartCode to set
     */
    public void setqP3DepartCode(String qP3DepartCode) {
        this.qP3DepartCode = qP3DepartCode;
    }

    /**
     * @return the qP3DepartName
     */
    public String getqP3DepartName() {
        return qP3DepartName;
    }

    /**
     * @param qP3DepartName the qP3DepartName to set
     */
    public void setqP3DepartName(String qP3DepartName) {
        this.qP3DepartName = qP3DepartName;
    }

    /**
     * @return the qP3UserID
     */
    public Integer getqP3UserID() {
        return qP3UserID;
    }

    /**
     * @param qP3UserID the qP3UserID to set
     */
    public void setqP3UserID(Integer qP3UserID) {
        this.qP3UserID = qP3UserID;
    }

    /**
     * @return the qP3UserLoginID
     */
    public String getqP3UserLoginID() {
        return qP3UserLoginID;
    }

    /**
     * @param qP3UserLoginID the qP3UserLoginID to set
     */
    public void setqP3UserLoginID(String qP3UserLoginID) {
        this.qP3UserLoginID = qP3UserLoginID;
    }

    /**
     * @return the qP3UserName
     */
    public String getqP3UserName() {
        return qP3UserName;
    }

    /**
     * @param qP3UserName the qP3UserName to set
     */
    public void setqP3UserName(String qP3UserName) {
        this.qP3UserName = qP3UserName;
    }

    /**
     * @return the qP3UserPhone
     */
    public String getqP3UserPhone() {
        return qP3UserPhone;
    }

    /**
     * @param qP3UserPhone the qP3UserPhone to set
     */
    public void setqP3UserPhone(String qP3UserPhone) {
        this.qP3UserPhone = qP3UserPhone;
    }

    /**
     * @return the qP3RestrainStep
     */
    public String getqP3RestrainStep() {
        return qP3RestrainStep;
    }

    /**
     * @param qP3RestrainStep the qP3RestrainStep to set
     */
    public void setqP3RestrainStep(String qP3RestrainStep) {
        this.qP3RestrainStep = qP3RestrainStep;
    }

    /**
     * @return the qP3InspectProcess
     */
    public String getqP3InspectProcess() {
        return qP3InspectProcess;
    }

    /**
     * @param qP3InspectProcess the qP3InspectProcess to set
     */
    public void setqP3InspectProcess(String qP3InspectProcess) {
        this.qP3InspectProcess = qP3InspectProcess;
    }

    /**
     * @return the qP3ReasonAnalyse
     */
    public String getqP3ReasonAnalyse() {
        return qP3ReasonAnalyse;
    }

    /**
     * @param qP3ReasonAnalyse the qP3ReasonAnalyse to set
     */
    public void setqP3ReasonAnalyse(String qP3ReasonAnalyse) {
        this.qP3ReasonAnalyse = qP3ReasonAnalyse;
    }

    /**
     * @return the qP3WorkPlan
     */
    public String getqP3WorkPlan() {
        return qP3WorkPlan;
    }

    /**
     * @param qP3WorkPlan the qP3WorkPlan to set
     */
    public void setqP3WorkPlan(String qP3WorkPlan) {
        this.qP3WorkPlan = qP3WorkPlan;
    }

    /**
     * @return the qP3ModifyPolicy
     */
    public String getqP3ModifyPolicy() {
        return qP3ModifyPolicy;
    }

    /**
     * @param qP3ModifyPolicy the qP3ModifyPolicy to set
     */
    public void setqP3ModifyPolicy(String qP3ModifyPolicy) {
        this.qP3ModifyPolicy = qP3ModifyPolicy;
    }

    /**
     * @return the qP3Reflection
     */
    public String getqP3Reflection() {
        return qP3Reflection;
    }

    /**
     * @param qP3Reflection the qP3Reflection to set
     */
    public void setqP3Reflection(String qP3Reflection) {
        this.qP3Reflection = qP3Reflection;
    }

    /**
     * @return the qP3InsideSpread
     */
    public String getqP3InsideSpread() {
        return qP3InsideSpread;
    }

    /**
     * @param qP3InsideSpread the qP3InsideSpread to set
     */
    public void setqP3InsideSpread(String qP3InsideSpread) {
        this.qP3InsideSpread = qP3InsideSpread;
    }

    /**
     * @return the qP3Standard
     */
    public String getqP3Standard() {
        return qP3Standard;
    }

    /**
     * @param qP3Standard the qP3Standard to set
     */
    public void setqP3Standard(String qP3Standard) {
        this.qP3Standard = qP3Standard;
    }

    /**
     * @return the ad2Id
     */
    public Integer getAd2Id() {
        return ad2Id;
    }

    /**
     * @param ad2Id the ad2Id to set
     */
    public void setAd2Id(Integer ad2Id) {
        this.ad2Id = ad2Id;
    }

    /**
     * @return the qP3TechnicClose
     */
    public Boolean getqP3TechnicClose() {
        return qP3TechnicClose;
    }

    /**
     * @param qP3TechnicClose the qP3TechnicClose to set
     */
    public void setqP3TechnicClose(Boolean qP3TechnicClose) {
        this.qP3TechnicClose = qP3TechnicClose;
    }

    /**
     * @return the qP3CancelTimes
     */
    public Integer getqP3CancelTimes() {
        return qP3CancelTimes;
    }

    /**
     * @param qP3CancelTimes the qP3CancelTimes to set
     */
    public void setqP3CancelTimes(Integer qP3CancelTimes) {
        this.qP3CancelTimes = qP3CancelTimes;
    }

    /**
     * @return the qP3CancelReason
     */
    public String getqP3CancelReason() {
        return qP3CancelReason;
    }

    /**
     * @param qP3CancelReason the qP3CancelReason to set
     */
    public void setqP3CancelReason(String qP3CancelReason) {
        this.qP3CancelReason = qP3CancelReason;
    }

    /**
     * @return the createDate
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * @param createDate the createDate to set
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    /**
     * @return the createUser
     */
    public String getCreateUser() {
        return createUser;
    }

    /**
     * @param createUser the createUser to set
     */
    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    /**
     * @return the replyDate
     */
    public String getReplyDate() {
        return replyDate;
    }

    /**
     * @param replyDate the replyDate to set
     */
    public void setReplyDate(String replyDate) {
        this.replyDate = replyDate;
    }

    /**
     * @return the modifyDate
     */
    public String getModifyDate() {
        return modifyDate;
    }

    /**
     * @param modifyDate the modifyDate to set
     */
    public void setModifyDate(String modifyDate) {
        this.modifyDate = modifyDate;
    }

    /**
     * @return the modifyUser
     */
    public String getModifyUser() {
        return modifyUser;
    }

    /**
     * @param modifyUser the modifyUser to set
     */
    public void setModifyUser(String modifyUser) {
        this.modifyUser = modifyUser;
    }
}
