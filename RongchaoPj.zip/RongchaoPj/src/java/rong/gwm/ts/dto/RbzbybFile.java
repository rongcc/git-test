/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author ZhouRongChao
 */
@Table("rbzbyb_file")
public class RbzbybFile {

    @Column("id")
    @Id
    private Integer id;
    @Column("rbzbyb_no")
    private String rbzbybNo;
    @Column("physical_filename")
    private String physicalFilename;
    @Column("real_filename")
    private String realFilename;
    @Column("download_count")
    private Integer downloadCount;
    @Column("description")
    private String description;
    @Column("minetype")
    private String minetype;
    @Column("file_size")
    private Integer fileSize;
    @Column("upload_time")
    private Date uploadTime;
    @Column("input_name")
    private String inputName;
    @Column("dept_no")
    private String deptNo;
    @Column("dept_name")
    private String deptName;
    @Column("b_type")
    private String bType;
    @Column("b_type_value")
    private String bTypeValue;
    @Column("remark")
    private String remark;
    @Column("status")
    private Integer status;
    @Column("last_down_date")
    private Date lastDownDate;
    @Column("last_down_name")
    private String lastDownName;
    @Column("b_type_time")
    private Date bTypeTime;
    @Column("is_jishi")
    private boolean isJishi;

    /**
     * @return the id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return the rbzbybNo
     */
    public String getRbzbybNo() {
        return rbzbybNo;
    }

    /**
     * @param rbzbybNo the rbzbybNo to set
     */
    public void setRbzbybNo(String rbzbybNo) {
        this.rbzbybNo = rbzbybNo;
    }

    /**
     * @return the physicalFilename
     */
    public String getPhysicalFilename() {
        return physicalFilename;
    }

    /**
     * @param physicalFilename the physicalFilename to set
     */
    public void setPhysicalFilename(String physicalFilename) {
        this.physicalFilename = physicalFilename;
    }

    /**
     * @return the realFilename
     */
    public String getRealFilename() {
        return realFilename;
    }

    /**
     * @param realFilename the realFilename to set
     */
    public void setRealFilename(String realFilename) {
        this.realFilename = realFilename;
    }

    /**
     * @return the downloadCount
     */
    public Integer getDownloadCount() {
        return downloadCount;
    }

    /**
     * @param downloadCount the downloadCount to set
     */
    public void setDownloadCount(Integer downloadCount) {
        this.downloadCount = downloadCount;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the minetype
     */
    public String getMinetype() {
        return minetype;
    }

    /**
     * @param minetype the minetype to set
     */
    public void setMinetype(String minetype) {
        this.minetype = minetype;
    }

    /**
     * @return the fileSize
     */
    public Integer getFileSize() {
        return fileSize;
    }

    /**
     * @param fileSize the fileSize to set
     */
    public void setFileSize(Integer fileSize) {
        this.fileSize = fileSize;
    }

    /**
     * @return the uploadTime
     */
    public Date getUploadTime() {
        return uploadTime;
    }

    /**
     * @param uploadTime the uploadTime to set
     */
    public void setUploadTime(Date uploadTime) {
        this.uploadTime = uploadTime;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    /**
     * @return the deptNo
     */
    public String getDeptNo() {
        return deptNo;
    }

    /**
     * @param deptNo the deptNo to set
     */
    public void setDeptNo(String deptNo) {
        this.deptNo = deptNo;
    }

    /**
     * @return the deptName
     */
    public String getDeptName() {
        return deptName;
    }

    /**
     * @param deptName the deptName to set
     */
    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    /**
     * @return the bType
     */
    public String getbType() {
        return bType;
    }

    /**
     * @param bType the bType to set
     */
    public void setbType(String bType) {
        this.bType = bType;
    }

    /**
     * @return the bTypeValue
     */
    public String getbTypeValue() {
        return bTypeValue;
    }

    /**
     * @param bTypeValue the bTypeValue to set
     */
    public void setbTypeValue(String bTypeValue) {
        this.bTypeValue = bTypeValue;
    }

    /**
     * @return the remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * @param remark the remark to set
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * @return the status
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * @return the lastDownDate
     */
    public Date getLastDownDate() {
        return lastDownDate;
    }

    /**
     * @param lastDownDate the lastDownDate to set
     */
    public void setLastDownDate(Date lastDownDate) {
        this.lastDownDate = lastDownDate;
    }

    /**
     * @return the lastDownName
     */
    public String getLastDownName() {
        return lastDownName;
    }

    /**
     * @param lastDownName the lastDownName to set
     */
    public void setLastDownName(String lastDownName) {
        this.lastDownName = lastDownName;
    }

    /**
     * @return the bTypeTime
     */
    public Date getbTypeTime() {
        return bTypeTime;
    }

    /**
     * @param bTypeTime the bTypeTime to set
     */
    public void setbTypeTime(Date bTypeTime) {
        this.bTypeTime = bTypeTime;
    }

    /**
     * @return the isJishi
     */
    public boolean isIsJishi() {
        return isJishi;
    }

    /**
     * @param isJishi the isJishi to set
     */
    public void setIsJishi(boolean isJishi) {
        this.isJishi = isJishi;
    }


}
