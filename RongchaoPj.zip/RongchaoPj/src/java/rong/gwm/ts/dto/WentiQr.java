/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package rong.gwm.ts.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Name;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("wenti_qr")
public class WentiQr {

    @Column("wenti_qr_no")
    @Name
    private String wentiQrNo;
    @Column("beipingjia_dept_code")
    private String beipingjiaDeptCode;
    @Column("beipingjia_dept")
    private String beipingjiaDept;
    @Column("bfh_tk_id")
    private String bfhTkId;
    @Column("bfh_tk")
    private String bfhTk;
    @Column("jilei_pingjia_chuli")
    private String jileiPingjiaChuli;
    @Column("jishi_pingjia_chuli")
    private String jishiPingjiaChuli;
    @Column("pingjia_dept_code")
    private String pingjiaDeptCode;
    @Column("pingjia_dept")
    private String pingjiaDept;
    @Column("pingjia_ren")
    private String pingjiaRen;
    @Column("remark")
    private String remark;
    @Column("status")
    private int status;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;
    @Column("edit_date")
    private Date editDate;
    @Column("edit_name")
    private String editName;
    @Column("post_date")
    private Date postDate;
    @Column("post_name")
    private String postName;
    @Column("source_order")
    private String sourceOrder;
    @Column("wenti_description")
    private String wentiDescription;
    @Column("wenti_date")
    private Date wentiDate;
    @Column("peitong_ren")
    private String peitongRen;
    @Column("post2_date")
    private Date post2Date;
    @Column("post2_name")
    private String post2Name;

    /**
     * @return the wentiQrNo
     */
    public String getWentiQrNo() {
        return wentiQrNo;
    }

    /**
     * @param wentiQrNo the wentiQrNo to set
     */
    public void setWentiQrNo(String wentiQrNo) {
        this.wentiQrNo = wentiQrNo;
    }

    /**
     * @return the beipingjiaDeptCode
     */
    public String getBeipingjiaDeptCode() {
        return beipingjiaDeptCode;
    }

    /**
     * @param beipingjiaDeptCode the beipingjiaDeptCode to set
     */
    public void setBeipingjiaDeptCode(String beipingjiaDeptCode) {
        this.beipingjiaDeptCode = beipingjiaDeptCode;
    }

    /**
     * @return the beipingjiaDept
     */
    public String getBeipingjiaDept() {
        return beipingjiaDept;
    }

    /**
     * @param beipingjiaDept the beipingjiaDept to set
     */
    public void setBeipingjiaDept(String beipingjiaDept) {
        this.beipingjiaDept = beipingjiaDept;
    }

    /**
     * @return the bfhTkId
     */
    public String getBfhTkId() {
        return bfhTkId;
    }

    /**
     * @param bfhTkId the bfhTkId to set
     */
    public void setBfhTkId(String bfhTkId) {
        this.bfhTkId = bfhTkId;
    }

    /**
     * @return the bfhTk
     */
    public String getBfhTk() {
        return bfhTk;
    }

    /**
     * @param bfhTk the bfhTk to set
     */
    public void setBfhTk(String bfhTk) {
        this.bfhTk = bfhTk;
    }

    /**
     * @return the jileiPingjiaChuli
     */
    public String getJileiPingjiaChuli() {
        return jileiPingjiaChuli;
    }

    /**
     * @param jileiPingjiaChuli the jileiPingjiaChuli to set
     */
    public void setJileiPingjiaChuli(String jileiPingjiaChuli) {
        this.jileiPingjiaChuli = jileiPingjiaChuli;
    }

    /**
     * @return the jishiPingjiaChuli
     */
    public String getJishiPingjiaChuli() {
        return jishiPingjiaChuli;
    }

    /**
     * @param jishiPingjiaChuli the jishiPingjiaChuli to set
     */
    public void setJishiPingjiaChuli(String jishiPingjiaChuli) {
        this.jishiPingjiaChuli = jishiPingjiaChuli;
    }

    /**
     * @return the pingjiaDeptCode
     */
    public String getPingjiaDeptCode() {
        return pingjiaDeptCode;
    }

    /**
     * @param pingjiaDeptCode the pingjiaDeptCode to set
     */
    public void setPingjiaDeptCode(String pingjiaDeptCode) {
        this.pingjiaDeptCode = pingjiaDeptCode;
    }

    /**
     * @return the pingjiaDept
     */
    public String getPingjiaDept() {
        return pingjiaDept;
    }

    /**
     * @param pingjiaDept the pingjiaDept to set
     */
    public void setPingjiaDept(String pingjiaDept) {
        this.pingjiaDept = pingjiaDept;
    }

    /**
     * @return the pingjiaRen
     */
    public String getPingjiaRen() {
        return pingjiaRen;
    }

    /**
     * @param pingjiaRen the pingjiaRen to set
     */
    public void setPingjiaRen(String pingjiaRen) {
        this.pingjiaRen = pingjiaRen;
    }

    /**
     * @return the remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * @param remark the remark to set
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    /**
     * @return the editDate
     */
    public Date getEditDate() {
        return editDate;
    }

    /**
     * @param editDate the editDate to set
     */
    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }

    /**
     * @return the editName
     */
    public String getEditName() {
        return editName;
    }

    /**
     * @param editName the editName to set
     */
    public void setEditName(String editName) {
        this.editName = editName;
    }

    /**
     * @return the postDate
     */
    public Date getPostDate() {
        return postDate;
    }

    /**
     * @param postDate the postDate to set
     */
    public void setPostDate(Date postDate) {
        this.postDate = postDate;
    }

    /**
     * @return the postName
     */
    public String getPostName() {
        return postName;
    }

    /**
     * @param postName the postName to set
     */
    public void setPostName(String postName) {
        this.postName = postName;
    }

    /**
     * @return the sourceOrder
     */
    public String getSourceOrder() {
        return sourceOrder;
    }

    /**
     * @param sourceOrder the sourceOrder to set
     */
    public void setSourceOrder(String sourceOrder) {
        this.sourceOrder = sourceOrder;
    }

    /**
     * @return the wentiDescription
     */
    public String getWentiDescription() {
        return wentiDescription;
    }

    /**
     * @param wentiDescription the wentiDescription to set
     */
    public void setWentiDescription(String wentiDescription) {
        this.wentiDescription = wentiDescription;
    }

    /**
     * @return the wentiDate
     */
    public Date getWentiDate() {
        return wentiDate;
    }

    /**
     * @param wentiDate the wentiDate to set
     */
    public void setWentiDate(Date wentiDate) {
        this.wentiDate = wentiDate;
    }

    /**
     * @return the peitongRen
     */
    public String getPeitongRen() {
        return peitongRen;
    }

    /**
     * @param peitongRen the peitongRen to set
     */
    public void setPeitongRen(String peitongRen) {
        this.peitongRen = peitongRen;
    }

    /**
     * @return the post2Date
     */
    public Date getPost2Date() {
        return post2Date;
    }

    /**
     * @param post2Date the post2Date to set
     */
    public void setPost2Date(Date post2Date) {
        this.post2Date = post2Date;
    }

    /**
     * @return the post2Name
     */
    public String getPost2Name() {
        return post2Name;
    }

    /**
     * @param post2Name the post2Name to set
     */
    public void setPost2Name(String post2Name) {
        this.post2Name = post2Name;
    }

}
