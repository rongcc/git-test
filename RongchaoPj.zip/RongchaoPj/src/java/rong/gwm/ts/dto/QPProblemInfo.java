/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.dto;

import java.math.BigDecimal;
import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("QP_ProblemInfo")
public class QPProblemInfo {

    @Column("QP1_ID")
    @Id
    private Integer qp1Id;
    @Column("QP1_Code")
    private String qP1Code;
    @Column("QP1_ImproveNum")
    private String qP1ImproveNum;
    @Column("QP1_Description")
    private String qP1Description;
    @Column("QP1_AfterEffect")
    private String qP1AfterEffect;
    @Column("QP1_Country")
    private String qP1Country;
    @Column("AD11_ID")
    private Integer ad11Id;
    @Column("AD1_ID")
    private Integer ad1Id;
    @Column("QP1_CarNumber")
    private String qP1CarNumber;
    @Column("QP1_EngineNumber")
    private String qP1EngineNumber;
    @Column("QP1_ChassisNumber")
    private String qP1ChassisNumber;
    @Column("QP1_BodyNumber")
    private String qP1BodyNumber;
    @Column("QP1_ProductDate")
    private Date qP1ProductDate;
    @Column("QP1_BreakKM")
    private BigDecimal qP1BreakKM;
    @Column("QP1_Quantity")
    private Integer qP1Quantity;
    @Column("AD5_ID")
    private Integer ad5Id;
    @Column("QP1_Urgency")
    private Integer qP1Urgency;
    @Column("QP1_Frequency")
    private BigDecimal qP1Frequency;
    @Column("QP1_FrequencyValue")
    private Integer qP1FrequencyValue;
    @Column("QP1_Severity")
    private String qP1Severity;
    @Column("QP1_severityValue")
    private Integer qP1severityValue;
    @Column("QP1_Priority")
    private Integer qP1Priority;
    @Column("QP1_IsInner")
    private Boolean qP1IsInner;
    @Column("QP1_ReplyOUCode")
    private String qP1ReplyOUCode;
    @Column("QP1_ReplyOUName")
    private String qP1ReplyOUName;
    @Column("QP1_ReplyLimit")
    private Date qP1ReplyLimit;
    @Column("QP1_Remark")
    private String qP1Remark;
    @Column("QP1_State")
    private String qP1State;
    @Column("QP1_RecenseTimes")
    private Integer qP1RecenseTimes;
    @Column("QP1_ReadTimes")
    private Integer qP1ReadTimes;
    @Column("QP1_ReferenceTimes")
    private Integer qP1ReferenceTimes;
    @Column("US_ID")
    private Integer usId;
    @Column("US_Phone")
    private String uSPhone;
    @Column("QP1_ReleaseDepCode")
    private String qP1ReleaseDepCode;
    @Column("QP1_ReleaseDepName")
    private String qP1ReleaseDepName;
    @Column("QP1_IsDelete")
    private Boolean qP1IsDelete;
    @Column("QP1_BCS")
    private Boolean qp1Bcs;
    @Column("QP1_ManageType")
    private String qP1ManageType;
    @Column("QP1_ProcessMark")
    private String qP1ProcessMark;
    @Column("QP1_ProcessRemark")
    private String qP1ProcessRemark;
    @Column("QP1_MarkUser")
    private String qP1MarkUser;
    @Column("QP1_MarkDate")
    private String qP1MarkDate;
    @Column("QP1_FinalClose")
    private Boolean qP1FinalClose;
    @Column("QP1_ProblemType")
    private String qP1ProblemType;
    @Column("OU_ID")
    private Integer ouId;
    @Column("CreateUser")
    private String createUser;
    @Column("CreateDate")
    private Date createDate;
    @Column("ModifyUser")
    private String modifyUser;
    @Column("ModifyDate")
    private String modifyDate;
    @Column("DeleteUser")
    private String deleteUser;
    @Column("DeleteDate")
    private String deleteDate;

    /**
     * @return the qp1Id
     */
    public Integer getQp1Id() {
        return qp1Id;
    }

    /**
     * @param qp1Id the qp1Id to set
     */
    public void setQp1Id(Integer qp1Id) {
        this.qp1Id = qp1Id;
    }

    /**
     * @return the qP1Code
     */
    public String getqP1Code() {
        return qP1Code;
    }

    /**
     * @param qP1Code the qP1Code to set
     */
    public void setqP1Code(String qP1Code) {
        this.qP1Code = qP1Code;
    }

    /**
     * @return the qP1ImproveNum
     */
    public String getqP1ImproveNum() {
        return qP1ImproveNum;
    }

    /**
     * @param qP1ImproveNum the qP1ImproveNum to set
     */
    public void setqP1ImproveNum(String qP1ImproveNum) {
        this.qP1ImproveNum = qP1ImproveNum;
    }

    /**
     * @return the qP1Description
     */
    public String getqP1Description() {
        return qP1Description;
    }

    /**
     * @param qP1Description the qP1Description to set
     */
    public void setqP1Description(String qP1Description) {
        this.qP1Description = qP1Description;
    }

    /**
     * @return the qP1AfterEffect
     */
    public String getqP1AfterEffect() {
        return qP1AfterEffect;
    }

    /**
     * @param qP1AfterEffect the qP1AfterEffect to set
     */
    public void setqP1AfterEffect(String qP1AfterEffect) {
        this.qP1AfterEffect = qP1AfterEffect;
    }

    /**
     * @return the qP1Country
     */
    public String getqP1Country() {
        return qP1Country;
    }

    /**
     * @param qP1Country the qP1Country to set
     */
    public void setqP1Country(String qP1Country) {
        this.qP1Country = qP1Country;
    }

    /**
     * @return the ad11Id
     */
    public Integer getAd11Id() {
        return ad11Id;
    }

    /**
     * @param ad11Id the ad11Id to set
     */
    public void setAd11Id(Integer ad11Id) {
        this.ad11Id = ad11Id;
    }

    /**
     * @return the ad1Id
     */
    public Integer getAd1Id() {
        return ad1Id;
    }

    /**
     * @param ad1Id the ad1Id to set
     */
    public void setAd1Id(Integer ad1Id) {
        this.ad1Id = ad1Id;
    }

    /**
     * @return the qP1CarNumber
     */
    public String getqP1CarNumber() {
        return qP1CarNumber;
    }

    /**
     * @param qP1CarNumber the qP1CarNumber to set
     */
    public void setqP1CarNumber(String qP1CarNumber) {
        this.qP1CarNumber = qP1CarNumber;
    }

    /**
     * @return the qP1EngineNumber
     */
    public String getqP1EngineNumber() {
        return qP1EngineNumber;
    }

    /**
     * @param qP1EngineNumber the qP1EngineNumber to set
     */
    public void setqP1EngineNumber(String qP1EngineNumber) {
        this.qP1EngineNumber = qP1EngineNumber;
    }

    /**
     * @return the qP1ChassisNumber
     */
    public String getqP1ChassisNumber() {
        return qP1ChassisNumber;
    }

    /**
     * @param qP1ChassisNumber the qP1ChassisNumber to set
     */
    public void setqP1ChassisNumber(String qP1ChassisNumber) {
        this.qP1ChassisNumber = qP1ChassisNumber;
    }

    /**
     * @return the qP1BodyNumber
     */
    public String getqP1BodyNumber() {
        return qP1BodyNumber;
    }

    /**
     * @param qP1BodyNumber the qP1BodyNumber to set
     */
    public void setqP1BodyNumber(String qP1BodyNumber) {
        this.qP1BodyNumber = qP1BodyNumber;
    }

    /**
     * @return the qP1ProductDate
     */
    public Date getqP1ProductDate() {
        return qP1ProductDate;
    }

    /**
     * @param qP1ProductDate the qP1ProductDate to set
     */
    public void setqP1ProductDate(Date qP1ProductDate) {
        this.qP1ProductDate = qP1ProductDate;
    }

    /**
     * @return the qP1BreakKM
     */
    public BigDecimal getqP1BreakKM() {
        return qP1BreakKM;
    }

    /**
     * @param qP1BreakKM the qP1BreakKM to set
     */
    public void setqP1BreakKM(BigDecimal qP1BreakKM) {
        this.qP1BreakKM = qP1BreakKM;
    }

    /**
     * @return the qP1Quantity
     */
    public Integer getqP1Quantity() {
        return qP1Quantity;
    }

    /**
     * @param qP1Quantity the qP1Quantity to set
     */
    public void setqP1Quantity(Integer qP1Quantity) {
        this.qP1Quantity = qP1Quantity;
    }

    /**
     * @return the ad5Id
     */
    public Integer getAd5Id() {
        return ad5Id;
    }

    /**
     * @param ad5Id the ad5Id to set
     */
    public void setAd5Id(Integer ad5Id) {
        this.ad5Id = ad5Id;
    }

    /**
     * @return the qP1Urgency
     */
    public Integer getqP1Urgency() {
        return qP1Urgency;
    }

    /**
     * @param qP1Urgency the qP1Urgency to set
     */
    public void setqP1Urgency(Integer qP1Urgency) {
        this.qP1Urgency = qP1Urgency;
    }

    /**
     * @return the qP1Frequency
     */
    public BigDecimal getqP1Frequency() {
        return qP1Frequency;
    }

    /**
     * @param qP1Frequency the qP1Frequency to set
     */
    public void setqP1Frequency(BigDecimal qP1Frequency) {
        this.qP1Frequency = qP1Frequency;
    }

    /**
     * @return the qP1FrequencyValue
     */
    public Integer getqP1FrequencyValue() {
        return qP1FrequencyValue;
    }

    /**
     * @param qP1FrequencyValue the qP1FrequencyValue to set
     */
    public void setqP1FrequencyValue(Integer qP1FrequencyValue) {
        this.qP1FrequencyValue = qP1FrequencyValue;
    }

    /**
     * @return the qP1Severity
     */
    public String getqP1Severity() {
        return qP1Severity;
    }

    /**
     * @param qP1Severity the qP1Severity to set
     */
    public void setqP1Severity(String qP1Severity) {
        this.qP1Severity = qP1Severity;
    }

    /**
     * @return the qP1severityValue
     */
    public Integer getqP1severityValue() {
        return qP1severityValue;
    }

    /**
     * @param qP1severityValue the qP1severityValue to set
     */
    public void setqP1severityValue(Integer qP1severityValue) {
        this.qP1severityValue = qP1severityValue;
    }

    /**
     * @return the qP1Priority
     */
    public Integer getqP1Priority() {
        return qP1Priority;
    }

    /**
     * @param qP1Priority the qP1Priority to set
     */
    public void setqP1Priority(Integer qP1Priority) {
        this.qP1Priority = qP1Priority;
    }

    /**
     * @return the qP1IsInner
     */
    public Boolean getqP1IsInner() {
        return qP1IsInner;
    }

    /**
     * @param qP1IsInner the qP1IsInner to set
     */
    public void setqP1IsInner(Boolean qP1IsInner) {
        this.qP1IsInner = qP1IsInner;
    }

    /**
     * @return the qP1ReplyOUCode
     */
    public String getqP1ReplyOUCode() {
        return qP1ReplyOUCode;
    }

    /**
     * @param qP1ReplyOUCode the qP1ReplyOUCode to set
     */
    public void setqP1ReplyOUCode(String qP1ReplyOUCode) {
        this.qP1ReplyOUCode = qP1ReplyOUCode;
    }

    /**
     * @return the qP1ReplyOUName
     */
    public String getqP1ReplyOUName() {
        return qP1ReplyOUName;
    }

    /**
     * @param qP1ReplyOUName the qP1ReplyOUName to set
     */
    public void setqP1ReplyOUName(String qP1ReplyOUName) {
        this.qP1ReplyOUName = qP1ReplyOUName;
    }

    /**
     * @return the qP1ReplyLimit
     */
    public Date getqP1ReplyLimit() {
        return qP1ReplyLimit;
    }

    /**
     * @param qP1ReplyLimit the qP1ReplyLimit to set
     */
    public void setqP1ReplyLimit(Date qP1ReplyLimit) {
        this.qP1ReplyLimit = qP1ReplyLimit;
    }

    /**
     * @return the qP1Remark
     */
    public String getqP1Remark() {
        return qP1Remark;
    }

    /**
     * @param qP1Remark the qP1Remark to set
     */
    public void setqP1Remark(String qP1Remark) {
        this.qP1Remark = qP1Remark;
    }

    /**
     * @return the qP1State
     */
    public String getqP1State() {
        return qP1State;
    }

    /**
     * @param qP1State the qP1State to set
     */
    public void setqP1State(String qP1State) {
        this.qP1State = qP1State;
    }

    /**
     * @return the qP1RecenseTimes
     */
    public Integer getqP1RecenseTimes() {
        return qP1RecenseTimes;
    }

    /**
     * @param qP1RecenseTimes the qP1RecenseTimes to set
     */
    public void setqP1RecenseTimes(Integer qP1RecenseTimes) {
        this.qP1RecenseTimes = qP1RecenseTimes;
    }

    /**
     * @return the qP1ReadTimes
     */
    public Integer getqP1ReadTimes() {
        return qP1ReadTimes;
    }

    /**
     * @param qP1ReadTimes the qP1ReadTimes to set
     */
    public void setqP1ReadTimes(Integer qP1ReadTimes) {
        this.qP1ReadTimes = qP1ReadTimes;
    }

    /**
     * @return the qP1ReferenceTimes
     */
    public Integer getqP1ReferenceTimes() {
        return qP1ReferenceTimes;
    }

    /**
     * @param qP1ReferenceTimes the qP1ReferenceTimes to set
     */
    public void setqP1ReferenceTimes(Integer qP1ReferenceTimes) {
        this.qP1ReferenceTimes = qP1ReferenceTimes;
    }

    /**
     * @return the usId
     */
    public Integer getUsId() {
        return usId;
    }

    /**
     * @param usId the usId to set
     */
    public void setUsId(Integer usId) {
        this.usId = usId;
    }

    /**
     * @return the uSPhone
     */
    public String getuSPhone() {
        return uSPhone;
    }

    /**
     * @param uSPhone the uSPhone to set
     */
    public void setuSPhone(String uSPhone) {
        this.uSPhone = uSPhone;
    }

    /**
     * @return the qP1ReleaseDepCode
     */
    public String getqP1ReleaseDepCode() {
        return qP1ReleaseDepCode;
    }

    /**
     * @param qP1ReleaseDepCode the qP1ReleaseDepCode to set
     */
    public void setqP1ReleaseDepCode(String qP1ReleaseDepCode) {
        this.qP1ReleaseDepCode = qP1ReleaseDepCode;
    }

    /**
     * @return the qP1ReleaseDepName
     */
    public String getqP1ReleaseDepName() {
        return qP1ReleaseDepName;
    }

    /**
     * @param qP1ReleaseDepName the qP1ReleaseDepName to set
     */
    public void setqP1ReleaseDepName(String qP1ReleaseDepName) {
        this.qP1ReleaseDepName = qP1ReleaseDepName;
    }

    /**
     * @return the qP1IsDelete
     */
    public Boolean getqP1IsDelete() {
        return qP1IsDelete;
    }

    /**
     * @param qP1IsDelete the qP1IsDelete to set
     */
    public void setqP1IsDelete(Boolean qP1IsDelete) {
        this.qP1IsDelete = qP1IsDelete;
    }

    /**
     * @return the qp1Bcs
     */
    public Boolean getQp1Bcs() {
        return qp1Bcs;
    }

    /**
     * @param qp1Bcs the qp1Bcs to set
     */
    public void setQp1Bcs(Boolean qp1Bcs) {
        this.qp1Bcs = qp1Bcs;
    }

    /**
     * @return the qP1ManageType
     */
    public String getqP1ManageType() {
        return qP1ManageType;
    }

    /**
     * @param qP1ManageType the qP1ManageType to set
     */
    public void setqP1ManageType(String qP1ManageType) {
        this.qP1ManageType = qP1ManageType;
    }

    /**
     * @return the qP1ProcessMark
     */
    public String getqP1ProcessMark() {
        return qP1ProcessMark;
    }

    /**
     * @param qP1ProcessMark the qP1ProcessMark to set
     */
    public void setqP1ProcessMark(String qP1ProcessMark) {
        this.qP1ProcessMark = qP1ProcessMark;
    }

    /**
     * @return the qP1ProcessRemark
     */
    public String getqP1ProcessRemark() {
        return qP1ProcessRemark;
    }

    /**
     * @param qP1ProcessRemark the qP1ProcessRemark to set
     */
    public void setqP1ProcessRemark(String qP1ProcessRemark) {
        this.qP1ProcessRemark = qP1ProcessRemark;
    }

    /**
     * @return the qP1MarkUser
     */
    public String getqP1MarkUser() {
        return qP1MarkUser;
    }

    /**
     * @param qP1MarkUser the qP1MarkUser to set
     */
    public void setqP1MarkUser(String qP1MarkUser) {
        this.qP1MarkUser = qP1MarkUser;
    }

    /**
     * @return the qP1MarkDate
     */
    public String getqP1MarkDate() {
        return qP1MarkDate;
    }

    /**
     * @param qP1MarkDate the qP1MarkDate to set
     */
    public void setqP1MarkDate(String qP1MarkDate) {
        this.qP1MarkDate = qP1MarkDate;
    }

    /**
     * @return the qP1FinalClose
     */
    public Boolean getqP1FinalClose() {
        return qP1FinalClose;
    }

    /**
     * @param qP1FinalClose the qP1FinalClose to set
     */
    public void setqP1FinalClose(Boolean qP1FinalClose) {
        this.qP1FinalClose = qP1FinalClose;
    }

    /**
     * @return the qP1ProblemType
     */
    public String getqP1ProblemType() {
        return qP1ProblemType;
    }

    /**
     * @param qP1ProblemType the qP1ProblemType to set
     */
    public void setqP1ProblemType(String qP1ProblemType) {
        this.qP1ProblemType = qP1ProblemType;
    }

    /**
     * @return the ouId
     */
    public Integer getOuId() {
        return ouId;
    }

    /**
     * @param ouId the ouId to set
     */
    public void setOuId(Integer ouId) {
        this.ouId = ouId;
    }

    /**
     * @return the createUser
     */
    public String getCreateUser() {
        return createUser;
    }

    /**
     * @param createUser the createUser to set
     */
    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    /**
     * @return the createDate
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * @param createDate the createDate to set
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    /**
     * @return the modifyUser
     */
    public String getModifyUser() {
        return modifyUser;
    }

    /**
     * @param modifyUser the modifyUser to set
     */
    public void setModifyUser(String modifyUser) {
        this.modifyUser = modifyUser;
    }

    /**
     * @return the modifyDate
     */
    public String getModifyDate() {
        return modifyDate;
    }

    /**
     * @param modifyDate the modifyDate to set
     */
    public void setModifyDate(String modifyDate) {
        this.modifyDate = modifyDate;
    }

    /**
     * @return the deleteUser
     */
    public String getDeleteUser() {
        return deleteUser;
    }

    /**
     * @param deleteUser the deleteUser to set
     */
    public void setDeleteUser(String deleteUser) {
        this.deleteUser = deleteUser;
    }

    /**
     * @return the deleteDate
     */
    public String getDeleteDate() {
        return deleteDate;
    }

    /**
     * @param deleteDate the deleteDate to set
     */
    public void setDeleteDate(String deleteDate) {
        this.deleteDate = deleteDate;
    }
}
