/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Name;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("UM_OrgUnit")
public class UMOrgUnit {

    @Column("OU_ID")
    @Name
    private Integer ouId;
    @Column("OU_ParentID")
    private Integer oUParentID;
    @Column("OU_Code")
    private String oUCode;
    @Column("OU_Name")
    private String oUName;
    @Column("OU_ShortName")
    private String oUShortName;
    @Column("AD_Path")
    private String aDPath;
    @Column("AD_RootName")
    private String aDRootName;
    @Column("OU_Phone")
    private String oUPhone;
    @Column("OU_Fax")
    private String oUFax;
    @Column("OU_IsUsed")
    private Boolean oUIsUsed;
    @Column("OU_IsDelete")
    private Boolean oUIsDelete;
    @Column("CreateUser")
    private String createUser;
    @Column("CreateDate")
    private Date createDate;
    @Column("ModifyUser")
    private String modifyUser;
    @Column("ModifyDate")
    private String modifyDate;
    @Column("DeleteUser")
    private String deleteUser;
    @Column("DeleteDate")
    private String deleteDate;

    /**
     * @return the ouId
     */
    public Integer getOuId() {
        return ouId;
    }

    /**
     * @param ouId the ouId to set
     */
    public void setOuId(Integer ouId) {
        this.ouId = ouId;
    }

    /**
     * @return the oUParentID
     */
    public Integer getoUParentID() {
        return oUParentID;
    }

    /**
     * @param oUParentID the oUParentID to set
     */
    public void setoUParentID(Integer oUParentID) {
        this.oUParentID = oUParentID;
    }

    /**
     * @return the oUCode
     */
    public String getoUCode() {
        return oUCode;
    }

    /**
     * @param oUCode the oUCode to set
     */
    public void setoUCode(String oUCode) {
        this.oUCode = oUCode;
    }

    /**
     * @return the oUName
     */
    public String getoUName() {
        return oUName;
    }

    /**
     * @param oUName the oUName to set
     */
    public void setoUName(String oUName) {
        this.oUName = oUName;
    }

    /**
     * @return the oUShortName
     */
    public String getoUShortName() {
        return oUShortName;
    }

    /**
     * @param oUShortName the oUShortName to set
     */
    public void setoUShortName(String oUShortName) {
        this.oUShortName = oUShortName;
    }

    /**
     * @return the aDPath
     */
    public String getaDPath() {
        return aDPath;
    }

    /**
     * @param aDPath the aDPath to set
     */
    public void setaDPath(String aDPath) {
        this.aDPath = aDPath;
    }

    /**
     * @return the aDRootName
     */
    public String getaDRootName() {
        return aDRootName;
    }

    /**
     * @param aDRootName the aDRootName to set
     */
    public void setaDRootName(String aDRootName) {
        this.aDRootName = aDRootName;
    }

    /**
     * @return the oUPhone
     */
    public String getoUPhone() {
        return oUPhone;
    }

    /**
     * @param oUPhone the oUPhone to set
     */
    public void setoUPhone(String oUPhone) {
        this.oUPhone = oUPhone;
    }

    /**
     * @return the oUFax
     */
    public String getoUFax() {
        return oUFax;
    }

    /**
     * @param oUFax the oUFax to set
     */
    public void setoUFax(String oUFax) {
        this.oUFax = oUFax;
    }

    /**
     * @return the oUIsUsed
     */
    public Boolean getoUIsUsed() {
        return oUIsUsed;
    }

    /**
     * @param oUIsUsed the oUIsUsed to set
     */
    public void setoUIsUsed(Boolean oUIsUsed) {
        this.oUIsUsed = oUIsUsed;
    }

    /**
     * @return the oUIsDelete
     */
    public Boolean getoUIsDelete() {
        return oUIsDelete;
    }

    /**
     * @param oUIsDelete the oUIsDelete to set
     */
    public void setoUIsDelete(Boolean oUIsDelete) {
        this.oUIsDelete = oUIsDelete;
    }

    /**
     * @return the createUser
     */
    public String getCreateUser() {
        return createUser;
    }

    /**
     * @param createUser the createUser to set
     */
    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    /**
     * @return the createDate
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * @param createDate the createDate to set
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    /**
     * @return the modifyUser
     */
    public String getModifyUser() {
        return modifyUser;
    }

    /**
     * @param modifyUser the modifyUser to set
     */
    public void setModifyUser(String modifyUser) {
        this.modifyUser = modifyUser;
    }

    /**
     * @return the modifyDate
     */
    public String getModifyDate() {
        return modifyDate;
    }

    /**
     * @param modifyDate the modifyDate to set
     */
    public void setModifyDate(String modifyDate) {
        this.modifyDate = modifyDate;
    }

    /**
     * @return the deleteUser
     */
    public String getDeleteUser() {
        return deleteUser;
    }

    /**
     * @param deleteUser the deleteUser to set
     */
    public void setDeleteUser(String deleteUser) {
        this.deleteUser = deleteUser;
    }

    /**
     * @return the deleteDate
     */
    public String getDeleteDate() {
        return deleteDate;
    }

    /**
     * @param deleteDate the deleteDate to set
     */
    public void setDeleteDate(String deleteDate) {
        this.deleteDate = deleteDate;
    }
}
