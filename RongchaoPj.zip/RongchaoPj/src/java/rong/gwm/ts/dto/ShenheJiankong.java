/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("shenhe_jiankong")
public class ShenheJiankong {

    @Column("shenhe_jk_no")
    @Id
    private Integer shenheJkNo;
    @Column("shenhe_jihua_no")
    private int shenheJihuaNo;
    @Column("shenhe_jihua_title")
    private String shenheJihuaTitle;
    @Column("jindu_status")
    private Integer jinduStatus;
    @Column("jindu")
    private String jindu;
    @Column("remark")
    private String remark;
    @Column("status")
    private int status;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;
    @Column("edit_date")
    private Date editDate;
    @Column("edit_name")
    private String editName;
    @Column("shenhe_name")
    private String shenheName;
    @Column("shibiehao")
    private String shibiehao;

    /**
     * @return the shenheJihuaNo
     */
    public int getShenheJihuaNo() {
        return shenheJihuaNo;
    }

    /**
     * @param shenheJihuaNo the shenheJihuaNo to set
     */
    public void setShenheJihuaNo(int shenheJihuaNo) {
        this.shenheJihuaNo = shenheJihuaNo;
    }

    /**
     * @return the shenheJihuaTitle
     */
    public String getShenheJihuaTitle() {
        return shenheJihuaTitle;
    }

    /**
     * @param shenheJihuaTitle the shenheJihuaTitle to set
     */
    public void setShenheJihuaTitle(String shenheJihuaTitle) {
        this.shenheJihuaTitle = shenheJihuaTitle;
    }

    /**
     * @return the jinduStatus
     */
    public Integer getJinduStatus() {
        return jinduStatus;
    }

    /**
     * @param jinduStatus the jinduStatus to set
     */
    public void setJinduStatus(Integer jinduStatus) {
        this.jinduStatus = jinduStatus;
    }

    /**
     * @return the jindu
     */
    public String getJindu() {
        return jindu;
    }

    /**
     * @param jindu the jindu to set
     */
    public void setJindu(String jindu) {
        this.jindu = jindu;
    }

    /**
     * @return the remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * @param remark the remark to set
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    /**
     * @return the editDate
     */
    public Date getEditDate() {
        return editDate;
    }

    /**
     * @param editDate the editDate to set
     */
    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }

    /**
     * @return the editName
     */
    public String getEditName() {
        return editName;
    }

    /**
     * @param editName the editName to set
     */
    public void setEditName(String editName) {
        this.editName = editName;
    }

    /**
     * @return the shenheJkNo
     */
    public Integer getShenheJkNo() {
        return shenheJkNo;
    }

    /**
     * @param shenheJkNo the shenheJkNo to set
     */
    public void setShenheJkNo(Integer shenheJkNo) {
        this.shenheJkNo = shenheJkNo;
    }

    /**
     * @return the shenheName
     */
    public String getShenheName() {
        return shenheName;
    }

    /**
     * @param shenheName the shenheName to set
     */
    public void setShenheName(String shenheName) {
        this.shenheName = shenheName;
    }

    /**
     * @return the shibiehao
     */
    public String getShibiehao() {
        return shibiehao;
    }

    /**
     * @param shibiehao the shibiehao to set
     */
    public void setShibiehao(String shibiehao) {
        this.shibiehao = shibiehao;
    }
}
