/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.dto;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.PK;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("om_pingfen_result_history")
@PK({"orgId", "period"})
public class OmPingfenResultHistory {

    @Column("org_id")
    private Integer orgId;
    @Column("org_name")
    private String orgName;
    @Column("jieguo_fen")
    private Double jieguoFen;
    @Column("guocheng_fen")
    private Double guochengFen;
    @Column("heji")
    private Double heji;
    @Column("zhengshu")
    private String zhengshu;
    @Column("period")
    private int period;

    /**
     * @return the orgId
     */
    public Integer getOrgId() {
        return orgId;
    }

    /**
     * @param orgId the orgId to set
     */
    public void setOrgId(Integer orgId) {
        this.orgId = orgId;
    }

    /**
     * @return the orgName
     */
    public String getOrgName() {
        return orgName;
    }

    /**
     * @param orgName the orgName to set
     */
    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    /**
     * @return the jieguoFen
     */
    public Double getJieguoFen() {
        return jieguoFen;
    }

    /**
     * @param jieguoFen the jieguoFen to set
     */
    public void setJieguoFen(Double jieguoFen) {
        this.jieguoFen = jieguoFen;
    }

    /**
     * @return the guochengFen
     */
    public Double getGuochengFen() {
        return guochengFen;
    }

    /**
     * @param guochengFen the guochengFen to set
     */
    public void setGuochengFen(Double guochengFen) {
        this.guochengFen = guochengFen;
    }

    /**
     * @return the heji
     */
    public Double getHeji() {
        return heji;
    }

    /**
     * @param heji the heji to set
     */
    public void setHeji(Double heji) {
        this.heji = heji;
    }

    /**
     * @return the zhengshu
     */
    public String getZhengshu() {
        return zhengshu;
    }

    /**
     * @param zhengshu the zhengshu to set
     */
    public void setZhengshu(String zhengshu) {
        this.zhengshu = zhengshu;
    }

    /**
     * @return the period
     */
    public int getPeriod() {
        return period;
    }

    /**
     * @param period the period to set
     */
    public void setPeriod(int period) {
        this.period = period;
    }
}
