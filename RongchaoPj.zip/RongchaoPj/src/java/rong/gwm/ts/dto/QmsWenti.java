/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Name;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("qms_wenti")
public class QmsWenti {

    @Column("wenti_no")
    @Name
    private String wentiNo;
    @Column("wenti_miaoshu")
    private String wentiMiaoshu;
    @Column("yuanyin_fenxi")
    private String yuanyinFenxi;
    @Column("zhuangtai_biaoz")
    private String zhuangtaiBiaoz;
    @Column("zhuangtai_status")
    private Integer zhuangtaiStatus;
    @Column("remark")
    private String remark;
    @Column("status")
    private Integer status;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;
    @Column("edit_date")
    private Date editDate;
    @Column("edit_name")
    private String editName;
    @Column("post_date")
    private Date postDate;
    @Column("post_name")
    private String postName;
    @Column("source_order")
    private String sourceOrder;
    @Column("ss_dept")
    private String ssDept;
    @Column("yanzhongdu")
    private String yanzhongdu;


    /**
     * @return the wentiNo
     */
    public String getWentiNo() {
        return wentiNo;
    }

    /**
     * @param wentiNo the wentiNo to set
     */
    public void setWentiNo(String wentiNo) {
        this.wentiNo = wentiNo;
    }

    /**
     * @return the wentiMiaoshu
     */
    public String getWentiMiaoshu() {
        return wentiMiaoshu;
    }

    /**
     * @param wentiMiaoshu the wentiMiaoshu to set
     */
    public void setWentiMiaoshu(String wentiMiaoshu) {
        this.wentiMiaoshu = wentiMiaoshu;
    }

    /**
     * @return the yuanyinFenxi
     */
    public String getYuanyinFenxi() {
        return yuanyinFenxi;
    }

    /**
     * @param yuanyinFenxi the yuanyinFenxi to set
     */
    public void setYuanyinFenxi(String yuanyinFenxi) {
        this.yuanyinFenxi = yuanyinFenxi;
    }

    /**
     * @return the zhuangtaiBiaoz
     */
    public String getZhuangtaiBiaoz() {
        return zhuangtaiBiaoz;
    }

    /**
     * @param zhuangtaiBiaoz the zhuangtaiBiaoz to set
     */
    public void setZhuangtaiBiaoz(String zhuangtaiBiaoz) {
        this.zhuangtaiBiaoz = zhuangtaiBiaoz;
    }

    /**
     * @return the zhuangtaiStatus
     */
    public Integer getZhuangtaiStatus() {
        return zhuangtaiStatus;
    }

    /**
     * @param zhuangtaiStatus the zhuangtaiStatus to set
     */
    public void setZhuangtaiStatus(Integer zhuangtaiStatus) {
        this.zhuangtaiStatus = zhuangtaiStatus;
    }

    /**
     * @return the remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * @param remark the remark to set
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * @return the status
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    /**
     * @return the editDate
     */
    public Date getEditDate() {
        return editDate;
    }

    /**
     * @param editDate the editDate to set
     */
    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }

    /**
     * @return the editName
     */
    public String getEditName() {
        return editName;
    }

    /**
     * @param editName the editName to set
     */
    public void setEditName(String editName) {
        this.editName = editName;
    }

    /**
     * @return the postDate
     */
    public Date getPostDate() {
        return postDate;
    }

    /**
     * @param postDate the postDate to set
     */
    public void setPostDate(Date postDate) {
        this.postDate = postDate;
    }

    /**
     * @return the postName
     */
    public String getPostName() {
        return postName;
    }

    /**
     * @param postName the postName to set
     */
    public void setPostName(String postName) {
        this.postName = postName;
    }

    /**
     * @return the sourceOrder
     */
    public String getSourceOrder() {
        return sourceOrder;
    }

    /**
     * @param sourceOrder the sourceOrder to set
     */
    public void setSourceOrder(String sourceOrder) {
        this.sourceOrder = sourceOrder;
    }

    /**
     * @return the ssDept
     */
    public String getSsDept() {
        return ssDept;
    }

    /**
     * @param ssDept the ssDept to set
     */
    public void setSsDept(String ssDept) {
        this.ssDept = ssDept;
    }

    /**
     * @return the yanzhongdu
     */
    public String getYanzhongdu() {
        return yanzhongdu;
    }

    /**
     * @param yanzhongdu the yanzhongdu to set
     */
    public void setYanzhongdu(String yanzhongdu) {
        this.yanzhongdu = yanzhongdu;
    }
}
