/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author ZhouRongChao
 */
@Table("access_right_message")
public class AccessRightMessage {

    @Column("id")
    @Id
    private Integer id;
    @Column("oper_no")
    private String operNo;
    @Column("order_no")
    private String orderNo;
    @Column("access_page")
    private String accessPage;
    @Column("do_right")
    private String doRight;
    @Column("do_date")
    private Date doDate;
    @Column("do_ip")
    private String doIp;
    @Column("status")
    private int status;
    @Column("pin_type")
    private String pinType;
    @Column("input_date")
    private Date inputDate;
    @Column("read_date")
    private Date readDate;
    @Column("read_last_date")
    private Date readLastDate;
    @Column("done_date")
    private Date doneDate;
    @Column("done_log_id")
    private Integer doneLogId;

    /**
     * @return the id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return the operNo
     */
    public String getOperNo() {
        return operNo;
    }

    /**
     * @param operNo the operNo to set
     */
    public void setOperNo(String operNo) {
        this.operNo = operNo;
    }

    /**
     * @return the orderNo
     */
    public String getOrderNo() {
        return orderNo;
    }

    /**
     * @param orderNo the orderNo to set
     */
    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    /**
     * @return the accessPage
     */
    public String getAccessPage() {
        return accessPage;
    }

    /**
     * @param accessPage the accessPage to set
     */
    public void setAccessPage(String accessPage) {
        this.accessPage = accessPage;
    }

    /**
     * @return the doRight
     */
    public String getDoRight() {
        return doRight;
    }

    /**
     * @param doRight the doRight to set
     */
    public void setDoRight(String doRight) {
        this.doRight = doRight;
    }

    /**
     * @return the doDate
     */
    public Date getDoDate() {
        return doDate;
    }

    /**
     * @param doDate the doDate to set
     */
    public void setDoDate(Date doDate) {
        this.doDate = doDate;
    }

    /**
     * @return the doIp
     */
    public String getDoIp() {
        return doIp;
    }

    /**
     * @param doIp the doIp to set
     */
    public void setDoIp(String doIp) {
        this.doIp = doIp;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the pinType
     */
    public String getPinType() {
        return pinType;
    }

    /**
     * @param pinType the pinType to set
     */
    public void setPinType(String pinType) {
        this.pinType = pinType;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the readDate
     */
    public Date getReadDate() {
        return readDate;
    }

    /**
     * @param readDate the readDate to set
     */
    public void setReadDate(Date readDate) {
        this.readDate = readDate;
    }

    /**
     * @return the readLastDate
     */
    public Date getReadLastDate() {
        return readLastDate;
    }

    /**
     * @param readLastDate the readLastDate to set
     */
    public void setReadLastDate(Date readLastDate) {
        this.readLastDate = readLastDate;
    }

    /**
     * @return the doneDate
     */
    public Date getDoneDate() {
        return doneDate;
    }

    /**
     * @param doneDate the doneDate to set
     */
    public void setDoneDate(Date doneDate) {
        this.doneDate = doneDate;
    }

    /**
     * @return the doneLogId
     */
    public Integer getDoneLogId() {
        return doneLogId;
    }

    /**
     * @param doneLogId the doneLogId to set
     */
    public void setDoneLogId(Integer doneLogId) {
        this.doneLogId = doneLogId;
    }
}
