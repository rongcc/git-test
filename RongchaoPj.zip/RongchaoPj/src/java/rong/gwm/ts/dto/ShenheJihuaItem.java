/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.PK;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("shenhe_jihua_item")
@PK({"itemNo", "shenheJihuaNo"})
public class ShenheJihuaItem {

    @Column("item_no")
    private int itemNo;
    @Column("shenhe_jihua_no")
    private int shenheJihuaNo;
    @Column("riqi")
    private Date riqi;
    @Column("shijian")
    private String shijian;
    @Column("shijian_start")
    private Date shijianStart;
    @Column("shijian_end")
    private Date shijianEnd;
    @Column("beishenhe_dept_main")
    private String beishenheDeptMain;
    @Column("shenhe_yuan")
    private String shenheYuan;
    @Column("beishenhe_guocheng")
    private String beishenheGuocheng;
    @Column("didian")
    private String didian;
    @Column("remark")
    private String remark;
    @Column("status")
    private Integer status;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;
    @Column("edit_date")
    private Date editDate;
    @Column("edit_name")
    private String editName;

    /**
     * @return the itemNo
     */
    public int getItemNo() {
        return itemNo;
    }

    /**
     * @param itemNo the itemNo to set
     */
    public void setItemNo(int itemNo) {
        this.itemNo = itemNo;
    }

    /**
     * @return the riqi
     */
    public Date getRiqi() {
        return riqi;
    }

    /**
     * @param riqi the riqi to set
     */
    public void setRiqi(Date riqi) {
        this.riqi = riqi;
    }

    /**
     * @return the shijian
     */
    public String getShijian() {
        return shijian;
    }

    /**
     * @param shijian the shijian to set
     */
    public void setShijian(String shijian) {
        this.shijian = shijian;
    }

    /**
     * @return the shijianStart
     */
    public Date getShijianStart() {
        return shijianStart;
    }

    /**
     * @param shijianStart the shijianStart to set
     */
    public void setShijianStart(Date shijianStart) {
        this.shijianStart = shijianStart;
    }

    /**
     * @return the shijianEnd
     */
    public Date getShijianEnd() {
        return shijianEnd;
    }

    /**
     * @param shijianEnd the shijianEnd to set
     */
    public void setShijianEnd(Date shijianEnd) {
        this.shijianEnd = shijianEnd;
    }

    /**
     * @return the beishenheDeptMain
     */
    public String getBeishenheDeptMain() {
        return beishenheDeptMain;
    }

    /**
     * @param beishenheDeptMain the beishenheDeptMain to set
     */
    public void setBeishenheDeptMain(String beishenheDeptMain) {
        this.beishenheDeptMain = beishenheDeptMain;
    }

    /**
     * @return the shenheYuan
     */
    public String getShenheYuan() {
        return shenheYuan;
    }

    /**
     * @param shenheYuan the shenheYuan to set
     */
    public void setShenheYuan(String shenheYuan) {
        this.shenheYuan = shenheYuan;
    }

    /**
     * @return the beishenheGuocheng
     */
    public String getBeishenheGuocheng() {
        return beishenheGuocheng;
    }

    /**
     * @param beishenheGuocheng the beishenheGuocheng to set
     */
    public void setBeishenheGuocheng(String beishenheGuocheng) {
        this.beishenheGuocheng = beishenheGuocheng;
    }

    /**
     * @return the didian
     */
    public String getDidian() {
        return didian;
    }

    /**
     * @param didian the didian to set
     */
    public void setDidian(String didian) {
        this.didian = didian;
    }

    /**
     * @return the remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * @param remark the remark to set
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * @return the status
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    /**
     * @return the editDate
     */
    public Date getEditDate() {
        return editDate;
    }

    /**
     * @param editDate the editDate to set
     */
    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }

    /**
     * @return the editName
     */
    public String getEditName() {
        return editName;
    }

    /**
     * @param editName the editName to set
     */
    public void setEditName(String editName) {
        this.editName = editName;
    }

    /**
     * @return the shenheJihuaNo
     */
    public int getShenheJihuaNo() {
        return shenheJihuaNo;
    }

    /**
     * @param shenheJihuaNo the shenheJihuaNo to set
     */
    public void setShenheJihuaNo(int shenheJihuaNo) {
        this.shenheJihuaNo = shenheJihuaNo;
    }
}
