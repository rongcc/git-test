/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package rong.gwm.ts.dto;

/**
 *
 * @author zhourongchao
 */
public class ShenheJihuaReport {

}
