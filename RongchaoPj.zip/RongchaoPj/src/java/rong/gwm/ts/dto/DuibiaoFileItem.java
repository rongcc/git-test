/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.dto;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.PK;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("duibiao_file_item")
@PK({"duibiaoId", "itemNo"})
public class DuibiaoFileItem {

    @Column("duibiao_id")
    private int duibiaoId;
    @Column("item_no")
    private int itemNo;
    @Column("item_name")
    private String itemName;
    @Column("file_name")
    private String fileName;
    @Column("content_type")
    private String contentType;

    public DuibiaoFileItem() {
    }

    public DuibiaoFileItem(int duibiaoId, int itemNo, String itemName, String fileName) {
        this.duibiaoId = duibiaoId;
        this.itemNo = itemNo;
        this.itemName = itemName;
        this.fileName = fileName;
    }

    public DuibiaoFileItem(int duibiaoId, int itemNo, String itemName, String fileName, String contentType) {
        this.duibiaoId = duibiaoId;
        this.itemNo = itemNo;
        this.itemName = itemName;
        this.fileName = fileName;
        this.contentType = contentType;
    }

    /**
     * @return the duibiaoId
     */
    public int getDuibiaoId() {
        return duibiaoId;
    }

    /**
     * @param duibiaoId the duibiaoId to set
     */
    public void setDuibiaoId(int duibiaoId) {
        this.duibiaoId = duibiaoId;
    }

    /**
     * @return the itemNo
     */
    public int getItemNo() {
        return itemNo;
    }

    /**
     * @param itemNo the itemNo to set
     */
    public void setItemNo(int itemNo) {
        this.itemNo = itemNo;
    }

    /**
     * @return the itemName
     */
    public String getItemName() {
        return itemName;
    }

    /**
     * @param itemName the itemName to set
     */
    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    /**
     * @return the fileName
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * @param fileName the fileName to set
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    /**
     * @return the contentType
     */
    public String getContentType() {
        return contentType;
    }

    /**
     * @param contentType the contentType to set
     */
    public void setContentType(String contentType) {
        this.contentType = contentType;
    }
}
