/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author ZhouRongChao
 */
@Table("access_right_log")
public class AccessRightLog {

    @Column("id")
    @Id
    private Integer id;
    @Column("oper_no")
    private String operNo;
    @Column("order_no")
    private String orderNo;
    @Column("access_page")
    private String accessPage;
    @Column("do_right")
    private String doRight;
    @Column("do_date")
    private Date doDate;
    @Column("do_ip")
    private String doIp;

    /**
     * @return the id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return the operNo
     */
    public String getOperNo() {
        return operNo;
    }

    /**
     * @param operNo the operNo to set
     */
    public void setOperNo(String operNo) {
        this.operNo = operNo;
    }

    /**
     * @return the orderNo
     */
    public String getOrderNo() {
        return orderNo;
    }

    /**
     * @param orderNo the orderNo to set
     */
    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    /**
     * @return the accessPage
     */
    public String getAccessPage() {
        return accessPage;
    }

    /**
     * @param accessPage the accessPage to set
     */
    public void setAccessPage(String accessPage) {
        this.accessPage = accessPage;
    }

    /**
     * @return the doRight
     */
    public String getDoRight() {
        return doRight;
    }

    /**
     * @param doRight the doRight to set
     */
    public void setDoRight(String doRight) {
        this.doRight = doRight;
    }

    /**
     * @return the doDate
     */
    public Date getDoDate() {
        return doDate;
    }

    /**
     * @param doDate the doDate to set
     */
    public void setDoDate(Date doDate) {
        this.doDate = doDate;
    }

    /**
     * @return the doIp
     */
    public String getDoIp() {
        return doIp;
    }

    /**
     * @param doIp the doIp to set
     */
    public void setDoIp(String doIp) {
        this.doIp = doIp;
    }
}
