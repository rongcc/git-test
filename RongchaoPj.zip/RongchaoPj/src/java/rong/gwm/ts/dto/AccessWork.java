/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.PK;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author ZhouRongChao
 */
@Table("access_work")
@PK({"operNo", "accessWork"})
public class AccessWork {

    @Column("oper_no")
    private String operNo;
    @Column("access_work")
    private String accessWork;
    @Column("access_work_name")
    private String accessWorkName;
    @Column("status")
    private int status;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;

    public AccessWork() {
    }

    public AccessWork(String operNo, String accessWork) {
        this.operNo = operNo;
        this.accessWork = accessWork;
    }

    /**
     * @return the operNo
     */
    public String getOperNo() {
        return operNo;
    }

    /**
     * @param operNo the operNo to set
     */
    public void setOperNo(String operNo) {
        this.operNo = operNo;
    }

    /**
     * @return the accessWork
     */
    public String getAccessWork() {
        return accessWork;
    }

    /**
     * @param accessWork the accessWork to set
     */
    public void setAccessWork(String accessWork) {
        this.accessWork = accessWork;
    }

    /**
     * @return the accessWorkName
     */
    public String getAccessWorkName() {
        return accessWorkName;
    }

    /**
     * @param accessWorkName the accessWorkName to set
     */
    public void setAccessWorkName(String accessWorkName) {
        this.accessWorkName = accessWorkName;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }
}
