/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Name;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("bfh_jieti_sq")
public class BfhJietiSq {

    @Column("jieti_sq_no")
    @Name
    private String jietiSqNo;
    @Column("zipingjia")
    private String zipingjia;
    @Column("remark")
    private String remark;
    @Column("status")
    private int status;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;
    @Column("edit_date")
    private Date editDate;
    @Column("edit_name")
    private String editName;
    @Column("post_date")
    private Date postDate;
    @Column("post_name")
    private String postName;
    @Column("source_order")
    private String sourceOrder;
    @Column("post2_date")
    private Date post2Date;
    @Column("post2_name")
    private String post2Name;
    @Column("status_tj")
    private boolean statusTj;
    @Column("tj_post")
    private String tjPost;
    @Column("tj_post2")
    private String tjPost2;

    /**
     * @return the jietiSqNo
     */
    public String getJietiSqNo() {
        return jietiSqNo;
    }

    /**
     * @param jietiSqNo the jietiSqNo to set
     */
    public void setJietiSqNo(String jietiSqNo) {
        this.jietiSqNo = jietiSqNo;
    }

    /**
     * @return the zipingjia
     */
    public String getZipingjia() {
        return zipingjia;
    }

    /**
     * @param zipingjia the zipingjia to set
     */
    public void setZipingjia(String zipingjia) {
        this.zipingjia = zipingjia;
    }

    /**
     * @return the remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * @param remark the remark to set
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    /**
     * @return the editDate
     */
    public Date getEditDate() {
        return editDate;
    }

    /**
     * @param editDate the editDate to set
     */
    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }

    /**
     * @return the editName
     */
    public String getEditName() {
        return editName;
    }

    /**
     * @param editName the editName to set
     */
    public void setEditName(String editName) {
        this.editName = editName;
    }

    /**
     * @return the postDate
     */
    public Date getPostDate() {
        return postDate;
    }

    /**
     * @param postDate the postDate to set
     */
    public void setPostDate(Date postDate) {
        this.postDate = postDate;
    }

    /**
     * @return the postName
     */
    public String getPostName() {
        return postName;
    }

    /**
     * @param postName the postName to set
     */
    public void setPostName(String postName) {
        this.postName = postName;
    }

    /**
     * @return the sourceOrder
     */
    public String getSourceOrder() {
        return sourceOrder;
    }

    /**
     * @param sourceOrder the sourceOrder to set
     */
    public void setSourceOrder(String sourceOrder) {
        this.sourceOrder = sourceOrder;
    }


    /**
     * @return the post2Name
     */
    public String getPost2Name() {
        return post2Name;
    }

    /**
     * @param post2Name the post2Name to set
     */
    public void setPost2Name(String post2Name) {
        this.post2Name = post2Name;
    }

    /**
     * @return the post2Date
     */
    public Date getPost2Date() {
        return post2Date;
    }

    /**
     * @param post2Date the post2Date to set
     */
    public void setPost2Date(Date post2Date) {
        this.post2Date = post2Date;
    }

    /**
     * @return the statusTj
     */
    public boolean isStatusTj() {
        return statusTj;
    }

    /**
     * @param statusTj the statusTj to set
     */
    public void setStatusTj(boolean statusTj) {
        this.statusTj = statusTj;
    }

    /**
     * @return the tjPost
     */
    public String getTjPost() {
        return tjPost;
    }

    /**
     * @param tjPost the tjPost to set
     */
    public void setTjPost(String tjPost) {
        this.tjPost = tjPost;
    }

    /**
     * @return the tjPost2
     */
    public String getTjPost2() {
        return tjPost2;
    }

    /**
     * @param tjPost2 the tjPost2 to set
     */
    public void setTjPost2(String tjPost2) {
        this.tjPost2 = tjPost2;
    }
}
