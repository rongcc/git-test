/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Name;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("bfh_dc")
public class BfhDc {

    @Column("dc_no")
    @Name
    private String dcNo;
    @Column("yuanyin_fenxi")
    private String yuanyinFenxi;
    @Column("jiuzheng")
    private String jiuzheng;
    @Column("jiuzheng_jiedian_date")
    private Date jiuzhengJiedianDate;
    @Column("jiuzheng_cuoshi")
    private String jiuzhengCuoshi;
    @Column("cuoshi_jiedian_date")
    private Date cuoshiJiedianDate;
    @Column("fzr")
    private String fzr;
    @Column("qianzi_date")
    private Date qianziDate;
    @Column("remark")
    private String remark;
    @Column("status")
    private int status;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;
    @Column("edit_date")
    private Date editDate;
    @Column("edit_name")
    private String editName;
    @Column("post_date")
    private Date postDate;
    @Column("post_name")
    private String postName;
    @Column("source_order")
    private String sourceOrder;
    @Column("reply_name")
    private String replyName;
    @Column("reply_date")
    private Date replyDate;
    @Column("zeren_dept")
    private String zerenDept;
    @Column("zeren_dept_name")
    private String zerenDeptName;
    @Column("post2_date")
    private Date post2Date;
    @Column("post2_name")
    private String post2Name;
    @Column("status_tj")
    private boolean statusTj;
    @Column("tj_post")
    private String tjPost;
    @Column("tj_post2")
    private String tjPost2;

    /**
     * @return the dcNo
     */
    public String getDcNo() {
        return dcNo;
    }

    /**
     * @param dcNo the dcNo to set
     */
    public void setDcNo(String dcNo) {
        this.dcNo = dcNo;
    }

    /**
     * @return the yuanyinFenxi
     */
    public String getYuanyinFenxi() {
        return yuanyinFenxi;
    }

    /**
     * @param yuanyinFenxi the yuanyinFenxi to set
     */
    public void setYuanyinFenxi(String yuanyinFenxi) {
        this.yuanyinFenxi = yuanyinFenxi;
    }

    /**
     * @return the jiuzheng
     */
    public String getJiuzheng() {
        return jiuzheng;
    }

    /**
     * @param jiuzheng the jiuzheng to set
     */
    public void setJiuzheng(String jiuzheng) {
        this.jiuzheng = jiuzheng;
    }

    /**
     * @return the jiuzhengCuoshi
     */
    public String getJiuzhengCuoshi() {
        return jiuzhengCuoshi;
    }

    /**
     * @param jiuzhengCuoshi the jiuzhengCuoshi to set
     */
    public void setJiuzhengCuoshi(String jiuzhengCuoshi) {
        this.jiuzhengCuoshi = jiuzhengCuoshi;
    }

    /**
     * @return the cuoshiJiedianDate
     */
    public Date getCuoshiJiedianDate() {
        return cuoshiJiedianDate;
    }

    /**
     * @param cuoshiJiedianDate the cuoshiJiedianDate to set
     */
    public void setCuoshiJiedianDate(Date cuoshiJiedianDate) {
        this.cuoshiJiedianDate = cuoshiJiedianDate;
    }

    /**
     * @return the fzr
     */
    public String getFzr() {
        return fzr;
    }

    /**
     * @param fzr the fzr to set
     */
    public void setFzr(String fzr) {
        this.fzr = fzr;
    }

    /**
     * @return the qianziDate
     */
    public Date getQianziDate() {
        return qianziDate;
    }

    /**
     * @param qianziDate the qianziDate to set
     */
    public void setQianziDate(Date qianziDate) {
        this.qianziDate = qianziDate;
    }

    /**
     * @return the remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * @param remark the remark to set
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    /**
     * @return the editDate
     */
    public Date getEditDate() {
        return editDate;
    }

    /**
     * @param editDate the editDate to set
     */
    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }

    /**
     * @return the editName
     */
    public String getEditName() {
        return editName;
    }

    /**
     * @param editName the editName to set
     */
    public void setEditName(String editName) {
        this.editName = editName;
    }

    /**
     * @return the postDate
     */
    public Date getPostDate() {
        return postDate;
    }

    /**
     * @param postDate the postDate to set
     */
    public void setPostDate(Date postDate) {
        this.postDate = postDate;
    }

    /**
     * @return the postName
     */
    public String getPostName() {
        return postName;
    }

    /**
     * @param postName the postName to set
     */
    public void setPostName(String postName) {
        this.postName = postName;
    }

    /**
     * @return the sourceOrder
     */
    public String getSourceOrder() {
        return sourceOrder;
    }

    /**
     * @param sourceOrder the sourceOrder to set
     */
    public void setSourceOrder(String sourceOrder) {
        this.sourceOrder = sourceOrder;
    }

    /**
     * @return the jiuzhengJiedianDate
     */
    public Date getJiuzhengJiedianDate() {
        return jiuzhengJiedianDate;
    }

    /**
     * @param jiuzhengJiedianDate the jiuzhengJiedianDate to set
     */
    public void setJiuzhengJiedianDate(Date jiuzhengJiedianDate) {
        this.jiuzhengJiedianDate = jiuzhengJiedianDate;
    }

    /**
     * @return the replyName
     */
    public String getReplyName() {
        return replyName;
    }

    /**
     * @param replyName the replyName to set
     */
    public void setReplyName(String replyName) {
        this.replyName = replyName;
    }

    /**
     * @return the replyDate
     */
    public Date getReplyDate() {
        return replyDate;
    }

    /**
     * @param replyDate the replyDate to set
     */
    public void setReplyDate(Date replyDate) {
        this.replyDate = replyDate;
    }

    /**
     * @return the zerenDept
     */
    public String getZerenDept() {
        return zerenDept;
    }

    /**
     * @param zerenDept the zerenDept to set
     */
    public void setZerenDept(String zerenDept) {
        this.zerenDept = zerenDept;
    }

    /**
     * @return the zerenDeptName
     */
    public String getZerenDeptName() {
        return zerenDeptName;
    }

    /**
     * @param zerenDeptName the zerenDeptName to set
     */
    public void setZerenDeptName(String zerenDeptName) {
        this.zerenDeptName = zerenDeptName;
    }

    /**
     * @return the post2Date
     */
    public Date getPost2Date() {
        return post2Date;
    }

    /**
     * @param post2Date the post2Date to set
     */
    public void setPost2Date(Date post2Date) {
        this.post2Date = post2Date;
    }

    /**
     * @return the post2Name
     */
    public String getPost2Name() {
        return post2Name;
    }

    /**
     * @param post2Name the post2Name to set
     */
    public void setPost2Name(String post2Name) {
        this.post2Name = post2Name;
    }

    /**
     * @return the statusTj
     */
    public boolean isStatusTj() {
        return statusTj;
    }

    /**
     * @param statusTj the statusTj to set
     */
    public void setStatusTj(boolean statusTj) {
        this.statusTj = statusTj;
    }

    /**
     * @return the tjPost
     */
    public String getTjPost() {
        return tjPost;
    }

    /**
     * @param tjPost the tjPost to set
     */
    public void setTjPost(String tjPost) {
        this.tjPost = tjPost;
    }

    /**
     * @return the tjPost2
     */
    public String getTjPost2() {
        return tjPost2;
    }

    /**
     * @param tjPost2 the tjPost2 to set
     */
    public void setTjPost2(String tjPost2) {
        this.tjPost2 = tjPost2;
    }
}
