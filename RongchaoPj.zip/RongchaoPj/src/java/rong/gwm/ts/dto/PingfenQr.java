/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author ZhouRongChao
 */
@Table("om_pingfen_qr")
public class PingfenQr {

    @Column("id")
    @Id
    private Integer id;
    @Column("description")
    private String description;
    @Column("guocheng_id")
    private Integer guochengId;
    @Column("guocheng_name")
    private String guochengName;
    @Column("source_work")
    private String sourceWork;
    @Column("type")
    private String type;
    @Column("pingfen")
    private double pingfen;
    @Column("status")
    private int status;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;
    @Column("edit_date")
    private Date editDate;
    @Column("edit_name")
    private String editName;
    @Column("post_date")
    private Date postDate;
    @Column("post_name")
    private String postName;
    @Column("tj_post")
    private String tjPost;
    @Column("status_tj")
    private boolean statusTj;
    @Column("beipingjia_dept")
    private String beipingjiaDept;

    /**
     * @return the id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the guochengId
     */
    public Integer getGuochengId() {
        return guochengId;
    }

    /**
     * @param guochengId the guochengId to set
     */
    public void setGuochengId(Integer guochengId) {
        this.guochengId = guochengId;
    }

    /**
     * @return the guochengName
     */
    public String getGuochengName() {
        return guochengName;
    }

    /**
     * @param guochengName the guochengName to set
     */
    public void setGuochengName(String guochengName) {
        this.guochengName = guochengName;
    }

    /**
     * @return the sourceWork
     */
    public String getSourceWork() {
        return sourceWork;
    }

    /**
     * @param sourceWork the sourceWork to set
     */
    public void setSourceWork(String sourceWork) {
        this.sourceWork = sourceWork;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return the pingfen
     */
    public double getPingfen() {
        return pingfen;
    }

    /**
     * @param pingfen the pingfen to set
     */
    public void setPingfen(double pingfen) {
        this.pingfen = pingfen;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    /**
     * @return the editDate
     */
    public Date getEditDate() {
        return editDate;
    }

    /**
     * @param editDate the editDate to set
     */
    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }

    /**
     * @return the editName
     */
    public String getEditName() {
        return editName;
    }

    /**
     * @param editName the editName to set
     */
    public void setEditName(String editName) {
        this.editName = editName;
    }

    /**
     * @return the postDate
     */
    public Date getPostDate() {
        return postDate;
    }

    /**
     * @param postDate the postDate to set
     */
    public void setPostDate(Date postDate) {
        this.postDate = postDate;
    }

    /**
     * @return the postName
     */
    public String getPostName() {
        return postName;
    }

    /**
     * @param postName the postName to set
     */
    public void setPostName(String postName) {
        this.postName = postName;
    }

    /**
     * @return the tjPost
     */
    public String getTjPost() {
        return tjPost;
    }

    /**
     * @param tjPost the tjPost to set
     */
    public void setTjPost(String tjPost) {
        this.tjPost = tjPost;
    }

    /**
     * @return the statusTj
     */
    public boolean isStatusTj() {
        return statusTj;
    }

    /**
     * @param statusTj the statusTj to set
     */
    public void setStatusTj(boolean statusTj) {
        this.statusTj = statusTj;
    }

    /**
     * @return the beipingjiaDept
     */
    public String getBeipingjiaDept() {
        return beipingjiaDept;
    }

    /**
     * @param beipingjiaDept the beipingjiaDept to set
     */
    public void setBeipingjiaDept(String beipingjiaDept) {
        this.beipingjiaDept = beipingjiaDept;
    }
}
