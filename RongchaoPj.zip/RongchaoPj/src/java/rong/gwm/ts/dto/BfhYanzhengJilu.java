/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Name;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("bfh_yanzheng_jilu")
public class BfhYanzhengJilu {

    @Column("yanzheng_no")
    @Name
    private String yanzhengNo;
    @Column("yanzheng_date")
    private Date yanzhengDate;
    @Column("yanzheng_xiaoguo")
    private String yanzhengXiaoguo;
    @Column("is_on_time")
    private boolean isOnTime;
    @Column("is_all_finish")
    private boolean isAllFinish;
    @Column("shishi_qk_sf_jilu")
    private boolean shishiQkSfJilu;
    @Column("yanzheng_ren")
    private String yanzhengRen;
    @Column("remark")
    private String remark;
    @Column("status")
    private int status;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;
    @Column("edit_date")
    private Date editDate;
    @Column("edit_name")
    private String editName;
    @Column("post_date")
    private Date postDate;
    @Column("post_name")
    private String postName;
    @Column("source_order")
    private String sourceOrder;
    @Column("yanzheng_qingkuang")
    private String yanzhengQingkuang;
    @Column("qita_wenti_jilu")
    private String qitaWentiJilu;
    @Column("is_jietihou")
    private boolean isJietihou;
    @Column("bfh_no")
    private String bfhNo;
    @Column("status_tj")
    private boolean statusTj;
    @Column("tj_post")
    private String tjPost;
    @Column("tj_post2")
    private String tjPost2;

    /**
     * @return the yanzhengNo
     */
    public String getYanzhengNo() {
        return yanzhengNo;
    }

    /**
     * @param yanzhengNo the yanzhengNo to set
     */
    public void setYanzhengNo(String yanzhengNo) {
        this.yanzhengNo = yanzhengNo;
    }

    /**
     * @return the yanzhengDate
     */
    public Date getYanzhengDate() {
        return yanzhengDate;
    }

    /**
     * @param yanzhengDate the yanzhengDate to set
     */
    public void setYanzhengDate(Date yanzhengDate) {
        this.yanzhengDate = yanzhengDate;
    }

    /**
     * @return the yanzhengXiaoguo
     */
    public String getYanzhengXiaoguo() {
        return yanzhengXiaoguo;
    }

    /**
     * @param yanzhengXiaoguo the yanzhengXiaoguo to set
     */
    public void setYanzhengXiaoguo(String yanzhengXiaoguo) {
        this.yanzhengXiaoguo = yanzhengXiaoguo;
    }

    /**
     * @return the isOnTime
     */
    public boolean isIsOnTime() {
        return isOnTime;
    }

    /**
     * @param isOnTime the isOnTime to set
     */
    public void setIsOnTime(boolean isOnTime) {
        this.isOnTime = isOnTime;
    }

    /**
     * @return the isAllFinish
     */
    public boolean isIsAllFinish() {
        return isAllFinish;
    }

    /**
     * @param isAllFinish the isAllFinish to set
     */
    public void setIsAllFinish(boolean isAllFinish) {
        this.isAllFinish = isAllFinish;
    }

    /**
     * @return the shishiQkSfJilu
     */
    public boolean isShishiQkSfJilu() {
        return shishiQkSfJilu;
    }

    /**
     * @param shishiQkSfJilu the shishiQkSfJilu to set
     */
    public void setShishiQkSfJilu(boolean shishiQkSfJilu) {
        this.shishiQkSfJilu = shishiQkSfJilu;
    }

    /**
     * @return the yanzhengRen
     */
    public String getYanzhengRen() {
        return yanzhengRen;
    }

    /**
     * @param yanzhengRen the yanzhengRen to set
     */
    public void setYanzhengRen(String yanzhengRen) {
        this.yanzhengRen = yanzhengRen;
    }

    /**
     * @return the remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * @param remark the remark to set
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    /**
     * @return the editDate
     */
    public Date getEditDate() {
        return editDate;
    }

    /**
     * @param editDate the editDate to set
     */
    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }

    /**
     * @return the editName
     */
    public String getEditName() {
        return editName;
    }

    /**
     * @param editName the editName to set
     */
    public void setEditName(String editName) {
        this.editName = editName;
    }

    /**
     * @return the postDate
     */
    public Date getPostDate() {
        return postDate;
    }

    /**
     * @param postDate the postDate to set
     */
    public void setPostDate(Date postDate) {
        this.postDate = postDate;
    }

    /**
     * @return the postName
     */
    public String getPostName() {
        return postName;
    }

    /**
     * @param postName the postName to set
     */
    public void setPostName(String postName) {
        this.postName = postName;
    }

    /**
     * @return the sourceOrder
     */
    public String getSourceOrder() {
        return sourceOrder;
    }

    /**
     * @param sourceOrder the sourceOrder to set
     */
    public void setSourceOrder(String sourceOrder) {
        this.sourceOrder = sourceOrder;
    }

    /**
     * @return the yanzhengQingkuang
     */
    public String getYanzhengQingkuang() {
        return yanzhengQingkuang;
    }

    /**
     * @param yanzhengQingkuang the yanzhengQingkuang to set
     */
    public void setYanzhengQingkuang(String yanzhengQingkuang) {
        this.yanzhengQingkuang = yanzhengQingkuang;
    }

    /**
     * @return the qitaWentiJilu
     */
    public String getQitaWentiJilu() {
        return qitaWentiJilu;
    }

    /**
     * @param qitaWentiJilu the qitaWentiJilu to set
     */
    public void setQitaWentiJilu(String qitaWentiJilu) {
        this.qitaWentiJilu = qitaWentiJilu;
    }

    /**
     * @return the isJietihou
     */
    public boolean isIsJietihou() {
        return isJietihou;
    }

    /**
     * @param isJietihou the isJietihou to set
     */
    public void setIsJietihou(boolean isJietihou) {
        this.isJietihou = isJietihou;
    }

    /**
     * @return the bfhNo
     */
    public String getBfhNo() {
        return bfhNo;
    }

    /**
     * @param bfhNo the bfhNo to set
     */
    public void setBfhNo(String bfhNo) {
        this.bfhNo = bfhNo;
    }

    /**
     * @return the statusTj
     */
    public boolean isStatusTj() {
        return statusTj;
    }

    /**
     * @param statusTj the statusTj to set
     */
    public void setStatusTj(boolean statusTj) {
        this.statusTj = statusTj;
    }

    /**
     * @return the tjPost
     */
    public String getTjPost() {
        return tjPost;
    }

    /**
     * @param tjPost the tjPost to set
     */
    public void setTjPost(String tjPost) {
        this.tjPost = tjPost;
    }

    /**
     * @return the tjPost2
     */
    public String getTjPost2() {
        return tjPost2;
    }

    /**
     * @param tjPost2 the tjPost2 to set
     */
    public void setTjPost2(String tjPost2) {
        this.tjPost2 = tjPost2;
    }
}
