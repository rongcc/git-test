/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.dto;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Name;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("access_right_take")
public class AccessRightTake {

    @Column("access_page")
    @Name
    private String accessPage;
    @Column("take1_name")
    private String take1Name;
    @Column("take2_name")
    private String take2Name;
    @Column("take3_name")
    private String take3Name;
    @Column("take4_name")
    private String take4Name;
    @Column("take5_name")
    private String take5Name;
    @Column("create_name")
    private String createName;
    @Column("list_name")
    private String listName;
    @Column("detail_name")
    private String detailName;
    @Column("edit_name")
    private String editName;
    @Column("destroy_name")
    private String destroyName;
    @Column("delete_name")
    private String deleteName;
    @Column("post_name")
    private String postName;
    @Column("post2_name")
    private String post2Name;
    @Column("cancel_post_name")
    private String cancelPostName;
    @Column("cancel_post2_name")
    private String cancelPost2Name;
    @Column("print_name")
    private String printName;

    /**
     * @return the accessPage
     */
    public String getAccessPage() {
        return accessPage;
    }

    /**
     * @param accessPage the accessPage to set
     */
    public void setAccessPage(String accessPage) {
        this.accessPage = accessPage;
    }

    /**
     * @return the take1Name
     */
    public String getTake1Name() {
        return take1Name;
    }

    /**
     * @param take1Name the take1Name to set
     */
    public void setTake1Name(String take1Name) {
        this.take1Name = take1Name;
    }

    /**
     * @return the take2Name
     */
    public String getTake2Name() {
        return take2Name;
    }

    /**
     * @param take2Name the take2Name to set
     */
    public void setTake2Name(String take2Name) {
        this.take2Name = take2Name;
    }

    /**
     * @return the take3Name
     */
    public String getTake3Name() {
        return take3Name;
    }

    /**
     * @param take3Name the take3Name to set
     */
    public void setTake3Name(String take3Name) {
        this.take3Name = take3Name;
    }

    /**
     * @return the take4Name
     */
    public String getTake4Name() {
        return take4Name;
    }

    /**
     * @param take4Name the take4Name to set
     */
    public void setTake4Name(String take4Name) {
        this.take4Name = take4Name;
    }

    /**
     * @return the take5Name
     */
    public String getTake5Name() {
        return take5Name;
    }

    /**
     * @param take5Name the take5Name to set
     */
    public void setTake5Name(String take5Name) {
        this.take5Name = take5Name;
    }

    /**
     * @return the createName
     */
    public String getCreateName() {
        return createName;
    }

    /**
     * @param createName the createName to set
     */
    public void setCreateName(String createName) {
        this.createName = createName;
    }

    /**
     * @return the listName
     */
    public String getListName() {
        return listName;
    }

    /**
     * @param listName the listName to set
     */
    public void setListName(String listName) {
        this.listName = listName;
    }

    /**
     * @return the detailName
     */
    public String getDetailName() {
        return detailName;
    }

    /**
     * @param detailName the detailName to set
     */
    public void setDetailName(String detailName) {
        this.detailName = detailName;
    }

    /**
     * @return the editName
     */
    public String getEditName() {
        return editName;
    }

    /**
     * @param editName the editName to set
     */
    public void setEditName(String editName) {
        this.editName = editName;
    }

    /**
     * @return the destroyName
     */
    public String getDestroyName() {
        return destroyName;
    }

    /**
     * @param destroyName the destroyName to set
     */
    public void setDestroyName(String destroyName) {
        this.destroyName = destroyName;
    }

    /**
     * @return the deleteName
     */
    public String getDeleteName() {
        return deleteName;
    }

    /**
     * @param deleteName the deleteName to set
     */
    public void setDeleteName(String deleteName) {
        this.deleteName = deleteName;
    }

    /**
     * @return the postName
     */
    public String getPostName() {
        return postName;
    }

    /**
     * @param postName the postName to set
     */
    public void setPostName(String postName) {
        this.postName = postName;
    }

    /**
     * @return the post2Name
     */
    public String getPost2Name() {
        return post2Name;
    }

    /**
     * @param post2Name the post2Name to set
     */
    public void setPost2Name(String post2Name) {
        this.post2Name = post2Name;
    }

    /**
     * @return the cancelPostName
     */
    public String getCancelPostName() {
        return cancelPostName;
    }

    /**
     * @param cancelPostName the cancelPostName to set
     */
    public void setCancelPostName(String cancelPostName) {
        this.cancelPostName = cancelPostName;
    }

    /**
     * @return the cancelPost2Name
     */
    public String getCancelPost2Name() {
        return cancelPost2Name;
    }

    /**
     * @param cancelPost2Name the cancelPost2Name to set
     */
    public void setCancelPost2Name(String cancelPost2Name) {
        this.cancelPost2Name = cancelPost2Name;
    }

    /**
     * @return the printName
     */
    public String getPrintName() {
        return printName;
    }

    /**
     * @param printName the printName to set
     */
    public void setPrintName(String printName) {
        this.printName = printName;
    }
}
