/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.dto;

import java.math.BigDecimal;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.PK;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("dept_defen")
@PK({"bfhTkCode", "deptNo","duanNo"})
public class DeptDefen {

    @Column("bfh_tk_code")
    private String bfhTkCode;
    @Column("dept_no")
    private String deptNo;
    @Column("duan_no")
    private String duanNo;
    @Column("bfh_tk")
    private String bfhTk;
    @Column("dept_name")
    private String deptName;
    @Column("pingjia")
    private BigDecimal pingjia;
    @Column("pinci")
    private int pinci;
    @Column("heji")
    private BigDecimal heji;
    @Column("status")
    private int status;
    @Column("year")
    private String year;
    @Column("jidu")
    private int jidu;
    @Column("zongfen")
    private BigDecimal zongfen;

    /**
     * @return the bfhTkCode
     */
    public String getBfhTkCode() {
        return bfhTkCode;
    }

    /**
     * @param bfhTkCode the bfhTkCode to set
     */
    public void setBfhTkCode(String bfhTkCode) {
        this.bfhTkCode = bfhTkCode;
    }

    /**
     * @return the deptNo
     */
    public String getDeptNo() {
        return deptNo;
    }

    /**
     * @param deptNo the deptNo to set
     */
    public void setDeptNo(String deptNo) {
        this.deptNo = deptNo;
    }

    /**
     * @return the duanNo
     */
    public String getDuanNo() {
        return duanNo;
    }

    /**
     * @param duanNo the duanNo to set
     */
    public void setDuanNo(String duanNo) {
        this.duanNo = duanNo;
    }

    /**
     * @return the bfhTk
     */
    public String getBfhTk() {
        return bfhTk;
    }

    /**
     * @param bfhTk the bfhTk to set
     */
    public void setBfhTk(String bfhTk) {
        this.bfhTk = bfhTk;
    }

    /**
     * @return the deptName
     */
    public String getDeptName() {
        return deptName;
    }

    /**
     * @param deptName the deptName to set
     */
    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    /**
     * @return the pingjia
     */
    public BigDecimal getPingjia() {
        return pingjia;
    }

    /**
     * @param pingjia the pingjia to set
     */
    public void setPingjia(BigDecimal pingjia) {
        this.pingjia = pingjia;
    }

    /**
     * @return the pinci
     */
    public int getPinci() {
        return pinci;
    }

    /**
     * @param pinci the pinci to set
     */
    public void setPinci(int pinci) {
        this.pinci = pinci;
    }

    /**
     * @return the heji
     */
    public BigDecimal getHeji() {
        return heji;
    }

    /**
     * @param heji the heji to set
     */
    public void setHeji(BigDecimal heji) {
        this.heji = heji;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the year
     */
    public String getYear() {
        return year;
    }

    /**
     * @param year the year to set
     */
    public void setYear(String year) {
        this.year = year;
    }

    /**
     * @return the jidu
     */
    public int getJidu() {
        return jidu;
    }

    /**
     * @param jidu the jidu to set
     */
    public void setJidu(int jidu) {
        this.jidu = jidu;
    }

    /**
     * @return the zongfen
     */
    public BigDecimal getZongfen() {
        return zongfen;
    }

    /**
     * @param zongfen the zongfen to set
     */
    public void setZongfen(BigDecimal zongfen) {
        this.zongfen = zongfen;
    }
}
