/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("UM_User")
public class UMUser {

    @Column("US_ID")
    @Id
    private Integer usId;
    @Column("US_LoginID")
    private String uSLoginID;
    @Column("OU_ID")
    private Integer ouId;
    @Column("AD_UserGuid")
    private String aDUserGuid;
    @Column("OU_Code")
    private String oUCode;
    @Column("US_Name")
    private String uSName;
    @Column("US_IsADUser")
    private Boolean uSIsADUser;
    @Column("US_CurMajorID")
    private Integer uSCurMajorID;
    @Column("US_CurMajor")
    private String uSCurMajor;
    @Column("US_ExpMajor1ID")
    private Integer uSExpMajor1ID;
    @Column("US_ExpMajor1")
    private String uSExpMajor1;
    @Column("US_ExpMajor2ID")
    private Integer uSExpMajor2ID;
    @Column("US_ExpMajor2")
    private String uSExpMajor2;
    @Column("US_ExpMajor3ID")
    private Integer uSExpMajor3ID;
    @Column("US_ExpMajor3")
    private String uSExpMajor3;
    @Column("US_LastLoginTime")
    private Date uSLastLoginTime;
    @Column("US_Pwd")
    private String uSPwd;
    @Column("US_Pwdtime")
    private Date uSPwdtime;
    @Column("US_PwdLimitDay")
    private Integer uSPwdLimitDay;
    @Column("US_Position")
    private String uSPosition;
    @Column("US_Email")
    private String uSEmail;
    @Column("US_Phone")
    private String uSPhone;
    @Column("US_Mobile")
    private String uSMobile;
    @Column("US_LogNum")
    private Integer uSLogNum;
    @Column("US_IsUsed")
    private Boolean uSIsUsed;
    @Column("US_IsDelete")
    private Boolean uSIsDelete;
    @Column("US_IsOnLine")
    private Boolean uSIsOnLine;
    @Column("US_Type")
    private Integer uSType;
    @Column("US_ManOUID")
    private Integer uSManOUID;
    @Column("CreateUser")
    private String createUser;
    @Column("CreateDate")
    private Date createDate;
    @Column("ModifyUser")
    private String modifyUser;
    @Column("ModifyDate")
    private String modifyDate;
    @Column("DeleteUser")
    private String deleteUser;
    @Column("DeleteDate")
    private String deleteDate;

    /**
     * @return the usId
     */
    public Integer getUsId() {
        return usId;
    }

    /**
     * @param usId the usId to set
     */
    public void setUsId(Integer usId) {
        this.usId = usId;
    }

    /**
     * @return the uSLoginID
     */
    public String getuSLoginID() {
        return uSLoginID;
    }

    /**
     * @param uSLoginID the uSLoginID to set
     */
    public void setuSLoginID(String uSLoginID) {
        this.uSLoginID = uSLoginID;
    }

    /**
     * @return the ouId
     */
    public Integer getOuId() {
        return ouId;
    }

    /**
     * @param ouId the ouId to set
     */
    public void setOuId(Integer ouId) {
        this.ouId = ouId;
    }

    /**
     * @return the aDUserGuid
     */
    public String getaDUserGuid() {
        return aDUserGuid;
    }

    /**
     * @param aDUserGuid the aDUserGuid to set
     */
    public void setaDUserGuid(String aDUserGuid) {
        this.aDUserGuid = aDUserGuid;
    }

    /**
     * @return the oUCode
     */
    public String getoUCode() {
        return oUCode;
    }

    /**
     * @param oUCode the oUCode to set
     */
    public void setoUCode(String oUCode) {
        this.oUCode = oUCode;
    }

    /**
     * @return the uSName
     */
    public String getuSName() {
        return uSName;
    }

    /**
     * @param uSName the uSName to set
     */
    public void setuSName(String uSName) {
        this.uSName = uSName;
    }

    /**
     * @return the uSIsADUser
     */
    public Boolean getuSIsADUser() {
        return uSIsADUser;
    }

    /**
     * @param uSIsADUser the uSIsADUser to set
     */
    public void setuSIsADUser(Boolean uSIsADUser) {
        this.uSIsADUser = uSIsADUser;
    }

    /**
     * @return the uSCurMajorID
     */
    public Integer getuSCurMajorID() {
        return uSCurMajorID;
    }

    /**
     * @param uSCurMajorID the uSCurMajorID to set
     */
    public void setuSCurMajorID(Integer uSCurMajorID) {
        this.uSCurMajorID = uSCurMajorID;
    }

    /**
     * @return the uSCurMajor
     */
    public String getuSCurMajor() {
        return uSCurMajor;
    }

    /**
     * @param uSCurMajor the uSCurMajor to set
     */
    public void setuSCurMajor(String uSCurMajor) {
        this.uSCurMajor = uSCurMajor;
    }

    /**
     * @return the uSExpMajor1ID
     */
    public Integer getuSExpMajor1ID() {
        return uSExpMajor1ID;
    }

    /**
     * @param uSExpMajor1ID the uSExpMajor1ID to set
     */
    public void setuSExpMajor1ID(Integer uSExpMajor1ID) {
        this.uSExpMajor1ID = uSExpMajor1ID;
    }

    /**
     * @return the uSExpMajor1
     */
    public String getuSExpMajor1() {
        return uSExpMajor1;
    }

    /**
     * @param uSExpMajor1 the uSExpMajor1 to set
     */
    public void setuSExpMajor1(String uSExpMajor1) {
        this.uSExpMajor1 = uSExpMajor1;
    }

    /**
     * @return the uSExpMajor2ID
     */
    public Integer getuSExpMajor2ID() {
        return uSExpMajor2ID;
    }

    /**
     * @param uSExpMajor2ID the uSExpMajor2ID to set
     */
    public void setuSExpMajor2ID(Integer uSExpMajor2ID) {
        this.uSExpMajor2ID = uSExpMajor2ID;
    }

    /**
     * @return the uSExpMajor2
     */
    public String getuSExpMajor2() {
        return uSExpMajor2;
    }

    /**
     * @param uSExpMajor2 the uSExpMajor2 to set
     */
    public void setuSExpMajor2(String uSExpMajor2) {
        this.uSExpMajor2 = uSExpMajor2;
    }

    /**
     * @return the uSExpMajor3ID
     */
    public Integer getuSExpMajor3ID() {
        return uSExpMajor3ID;
    }

    /**
     * @param uSExpMajor3ID the uSExpMajor3ID to set
     */
    public void setuSExpMajor3ID(Integer uSExpMajor3ID) {
        this.uSExpMajor3ID = uSExpMajor3ID;
    }

    /**
     * @return the uSExpMajor3
     */
    public String getuSExpMajor3() {
        return uSExpMajor3;
    }

    /**
     * @param uSExpMajor3 the uSExpMajor3 to set
     */
    public void setuSExpMajor3(String uSExpMajor3) {
        this.uSExpMajor3 = uSExpMajor3;
    }

    /**
     * @return the uSLastLoginTime
     */
    public Date getuSLastLoginTime() {
        return uSLastLoginTime;
    }

    /**
     * @param uSLastLoginTime the uSLastLoginTime to set
     */
    public void setuSLastLoginTime(Date uSLastLoginTime) {
        this.uSLastLoginTime = uSLastLoginTime;
    }

    /**
     * @return the uSPwd
     */
    public String getuSPwd() {
        return uSPwd;
    }

    /**
     * @param uSPwd the uSPwd to set
     */
    public void setuSPwd(String uSPwd) {
        this.uSPwd = uSPwd;
    }

    /**
     * @return the uSPwdtime
     */
    public Date getuSPwdtime() {
        return uSPwdtime;
    }

    /**
     * @param uSPwdtime the uSPwdtime to set
     */
    public void setuSPwdtime(Date uSPwdtime) {
        this.uSPwdtime = uSPwdtime;
    }

    /**
     * @return the uSPwdLimitDay
     */
    public Integer getuSPwdLimitDay() {
        return uSPwdLimitDay;
    }

    /**
     * @param uSPwdLimitDay the uSPwdLimitDay to set
     */
    public void setuSPwdLimitDay(Integer uSPwdLimitDay) {
        this.uSPwdLimitDay = uSPwdLimitDay;
    }

    /**
     * @return the uSPosition
     */
    public String getuSPosition() {
        return uSPosition;
    }

    /**
     * @param uSPosition the uSPosition to set
     */
    public void setuSPosition(String uSPosition) {
        this.uSPosition = uSPosition;
    }

    /**
     * @return the uSEmail
     */
    public String getuSEmail() {
        return uSEmail;
    }

    /**
     * @param uSEmail the uSEmail to set
     */
    public void setuSEmail(String uSEmail) {
        this.uSEmail = uSEmail;
    }

    /**
     * @return the uSPhone
     */
    public String getuSPhone() {
        return uSPhone;
    }

    /**
     * @param uSPhone the uSPhone to set
     */
    public void setuSPhone(String uSPhone) {
        this.uSPhone = uSPhone;
    }

    /**
     * @return the uSMobile
     */
    public String getuSMobile() {
        return uSMobile;
    }

    /**
     * @param uSMobile the uSMobile to set
     */
    public void setuSMobile(String uSMobile) {
        this.uSMobile = uSMobile;
    }

    /**
     * @return the uSLogNum
     */
    public Integer getuSLogNum() {
        return uSLogNum;
    }

    /**
     * @param uSLogNum the uSLogNum to set
     */
    public void setuSLogNum(Integer uSLogNum) {
        this.uSLogNum = uSLogNum;
    }

    /**
     * @return the uSIsUsed
     */
    public Boolean getuSIsUsed() {
        return uSIsUsed;
    }

    /**
     * @param uSIsUsed the uSIsUsed to set
     */
    public void setuSIsUsed(Boolean uSIsUsed) {
        this.uSIsUsed = uSIsUsed;
    }

    /**
     * @return the uSIsDelete
     */
    public Boolean getuSIsDelete() {
        return uSIsDelete;
    }

    /**
     * @param uSIsDelete the uSIsDelete to set
     */
    public void setuSIsDelete(Boolean uSIsDelete) {
        this.uSIsDelete = uSIsDelete;
    }

    /**
     * @return the uSIsOnLine
     */
    public Boolean getuSIsOnLine() {
        return uSIsOnLine;
    }

    /**
     * @param uSIsOnLine the uSIsOnLine to set
     */
    public void setuSIsOnLine(Boolean uSIsOnLine) {
        this.uSIsOnLine = uSIsOnLine;
    }

    /**
     * @return the uSType
     */
    public Integer getuSType() {
        return uSType;
    }

    /**
     * @param uSType the uSType to set
     */
    public void setuSType(Integer uSType) {
        this.uSType = uSType;
    }

    /**
     * @return the uSManOUID
     */
    public Integer getuSManOUID() {
        return uSManOUID;
    }

    /**
     * @param uSManOUID the uSManOUID to set
     */
    public void setuSManOUID(Integer uSManOUID) {
        this.uSManOUID = uSManOUID;
    }

    /**
     * @return the createUser
     */
    public String getCreateUser() {
        return createUser;
    }

    /**
     * @param createUser the createUser to set
     */
    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    /**
     * @return the createDate
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * @param createDate the createDate to set
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    /**
     * @return the modifyUser
     */
    public String getModifyUser() {
        return modifyUser;
    }

    /**
     * @param modifyUser the modifyUser to set
     */
    public void setModifyUser(String modifyUser) {
        this.modifyUser = modifyUser;
    }

    /**
     * @return the modifyDate
     */
    public String getModifyDate() {
        return modifyDate;
    }

    /**
     * @param modifyDate the modifyDate to set
     */
    public void setModifyDate(String modifyDate) {
        this.modifyDate = modifyDate;
    }

    /**
     * @return the deleteUser
     */
    public String getDeleteUser() {
        return deleteUser;
    }

    /**
     * @param deleteUser the deleteUser to set
     */
    public void setDeleteUser(String deleteUser) {
        this.deleteUser = deleteUser;
    }

    /**
     * @return the deleteDate
     */
    public String getDeleteDate() {
        return deleteDate;
    }

    /**
     * @param deleteDate the deleteDate to set
     */
    public void setDeleteDate(String deleteDate) {
        this.deleteDate = deleteDate;
    }
}
