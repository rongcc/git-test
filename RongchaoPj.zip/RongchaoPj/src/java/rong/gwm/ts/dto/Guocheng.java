/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author ZhouRongChao
 */
@Table("om_guocheng")
public class Guocheng {

    @Column("id")
    @Id
    private Integer id;
    @Column("code")
    private String code;
    @Column("name")
    private String name;
    @Column("type")
    private String type;
    @Column("belonger")
    private String belonger;
    @Column("org_id")
    private Integer orgId;
    @Column("inputs")
    private String inputs;
    @Column("outputs")
    private String outputs;
    @Column("resources")
    private String resources;
    @Column("managed")
    private String managed;
    @Column("status")
    private int status;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;
    @Column("edit_date")
    private Date editDate;
    @Column("edit_name")
    private String editName;
    @Column("father_id")
    private Integer fatherId;
    @Column("father_name")
    private String fatherName;
    @Column("pre_guocheng")
    private String preGuocheng;
    @Column("level")
    private Integer level;

    public Guocheng() {
    }

    public Guocheng(Integer id) {
        this.id = id;
    }

    public Guocheng(Integer id, String name, String belonger, int status) {
        this.id = id;
        this.name = name;
        this.belonger = belonger;
        this.status = status;
    }

    /**
     * @return the id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * @param code the code to set
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return the belonger
     */
    public String getBelonger() {
        return belonger;
    }

    /**
     * @param belonger the belonger to set
     */
    public void setBelonger(String belonger) {
        this.belonger = belonger;
    }

    /**
     * @return the orgId
     */
    public Integer getOrgId() {
        return orgId;
    }

    /**
     * @param orgId the orgId to set
     */
    public void setOrgId(Integer orgId) {
        this.orgId = orgId;
    }

    /**
     * @return the inputs
     */
    public String getInputs() {
        return inputs;
    }

    /**
     * @param inputs the inputs to set
     */
    public void setInputs(String inputs) {
        this.inputs = inputs;
    }

    /**
     * @return the outputs
     */
    public String getOutputs() {
        return outputs;
    }

    /**
     * @param outputs the outputs to set
     */
    public void setOutputs(String outputs) {
        this.outputs = outputs;
    }

    /**
     * @return the resources
     */
    public String getResources() {
        return resources;
    }

    /**
     * @param resources the resources to set
     */
    public void setResources(String resources) {
        this.resources = resources;
    }

    /**
     * @return the managed
     */
    public String getManaged() {
        return managed;
    }

    /**
     * @param managed the managed to set
     */
    public void setManaged(String managed) {
        this.managed = managed;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    /**
     * @return the fatherId
     */
    public Integer getFatherId() {
        return fatherId;
    }

    /**
     * @param fatherId the fatherId to set
     */
    public void setFatherId(Integer fatherId) {
        this.fatherId = fatherId;
    }

    /**
     * @return the fatherName
     */
    public String getFatherName() {
        return fatherName;
    }

    /**
     * @param fatherName the fatherName to set
     */
    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }

    /**
     * @return the editDate
     */
    public Date getEditDate() {
        return editDate;
    }

    /**
     * @param editDate the editDate to set
     */
    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }

    /**
     * @return the editName
     */
    public String getEditName() {
        return editName;
    }

    /**
     * @param editName the editName to set
     */
    public void setEditName(String editName) {
        this.editName = editName;
    }

    /**
     * @return the level
     */
    public Integer getLevel() {
        return level;
    }

    /**
     * @param level the level to set
     */
    public void setLevel(Integer level) {
        this.level = level;
    }

    /**
     * @return the preGuocheng
     */
    public String getPreGuocheng() {
        return preGuocheng;
    }

    /**
     * @param preGuocheng the preGuocheng to set
     */
    public void setPreGuocheng(String preGuocheng) {
        this.preGuocheng = preGuocheng;
    }
}
