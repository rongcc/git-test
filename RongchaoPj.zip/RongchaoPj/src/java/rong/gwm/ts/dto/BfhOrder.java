/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Name;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("bfh_order")
public class BfhOrder {

    @Column("bfh_no")
    @Name
    private String bfhNo;
    @Column("ssh_dept_id")
    private String sshDeptId;
    @Column("ssh_dept_name")
    private String sshDeptName;
    @Column("ss_guocheng_id")
    private String ssGuochengId;
    @Column("ss_guocheng_name")
    private String ssGuochengName;
    @Column("shenhe_date")
    private Date shenheDate;
    @Column("fzr")
    private String fzr;
    @Column("peitong_renyuan")
    private String peitongRenyuan;
    @Column("shenhe_yiju")
    private String shenheYiju;
    @Column("bfh_description")
    private String bfhDescription;
    @Column("shishi_bfh")
    private String shishiBfh;
    @Column("shenhe_yuan")
    private String shenheYuan;
    @Column("shenhe_zuzh")
    private String shenheZuzh;
    @Column("ssh_dept_fzr")
    private String sshDeptFzr;
    @Column("qianzi_date")
    private Date qianziDate;
    @Column("bfh_xz")
    private String bfhXz;
    @Column("source_goal")
    private String sourceGoal;
    @Column("status")
    private int status;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;
    @Column("edit_date")
    private Date editDate;
    @Column("edit_name")
    private String editName;
    @Column("post_date")
    private Date postDate;
    @Column("post_name")
    private String postName;
    @Column("source_order")
    private String sourceOrder;
    @Column("is_jieti")
    private Boolean isJieti;
    @Column("is_close")
    private Boolean isClose;
    @Column("close_date")
    private Date closeDate;
    @Column("close_name")
    private String closeName;
    @Column("fz_dept")
    private String fzDept;
    @Column("ssh_guocheng")
    private String sshGuocheng;
    @Column("guke_dept_id")
    private String gukeDeptId;
    @Column("guke_dept_name")
    private String gukeDeptName;
    @Column("ss_guocheng2_id")
    private String ssGuocheng2Id;
    @Column("ss_guocheng2_name")
    private String ssGuocheng2Name;
    @Column("ss_guocheng3_id")
    private String ssGuocheng3Id;
    @Column("ss_guocheng3_name")
    private String ssGuocheng3Name;
    @Column("status_tj")
    private boolean statusTj;
    @Column("tj_post")
    private String tjPost;
    @Column("tj_post2")
    private String tjPost2;

    /**
     * @return the bfhNo
     */
    public String getBfhNo() {
        return bfhNo;
    }

    /**
     * @param bfhNo the bfhNo to set
     */
    public void setBfhNo(String bfhNo) {
        this.bfhNo = bfhNo;
    }

    /**
     * @return the sshDeptId
     */
    public String getSshDeptId() {
        return sshDeptId;
    }

    /**
     * @param sshDeptId the sshDeptId to set
     */
    public void setSshDeptId(String sshDeptId) {
        this.sshDeptId = sshDeptId;
    }

    /**
     * @return the sshDeptName
     */
    public String getSshDeptName() {
        return sshDeptName;
    }

    /**
     * @param sshDeptName the sshDeptName to set
     */
    public void setSshDeptName(String sshDeptName) {
        this.sshDeptName = sshDeptName;
    }

    /**
     * @return the ssGuochengId
     */
    public String getSsGuochengId() {
        return ssGuochengId;
    }

    /**
     * @param ssGuochengId the ssGuochengId to set
     */
    public void setSsGuochengId(String ssGuochengId) {
        this.ssGuochengId = ssGuochengId;
    }

    /**
     * @return the ssGuochengName
     */
    public String getSsGuochengName() {
        return ssGuochengName;
    }

    /**
     * @param ssGuochengName the ssGuochengName to set
     */
    public void setSsGuochengName(String ssGuochengName) {
        this.ssGuochengName = ssGuochengName;
    }

    /**
     * @return the shenheDate
     */
    public Date getShenheDate() {
        return shenheDate;
    }

    /**
     * @param shenheDate the shenheDate to set
     */
    public void setShenheDate(Date shenheDate) {
        this.shenheDate = shenheDate;
    }

    /**
     * @return the fzr
     */
    public String getFzr() {
        return fzr;
    }

    /**
     * @param fzr the fzr to set
     */
    public void setFzr(String fzr) {
        this.fzr = fzr;
    }

    /**
     * @return the peitongRenyuan
     */
    public String getPeitongRenyuan() {
        return peitongRenyuan;
    }

    /**
     * @param peitongRenyuan the peitongRenyuan to set
     */
    public void setPeitongRenyuan(String peitongRenyuan) {
        this.peitongRenyuan = peitongRenyuan;
    }

    /**
     * @return the shenheYiju
     */
    public String getShenheYiju() {
        return shenheYiju;
    }

    /**
     * @param shenheYiju the shenheYiju to set
     */
    public void setShenheYiju(String shenheYiju) {
        this.shenheYiju = shenheYiju;
    }

    /**
     * @return the bfhDescription
     */
    public String getBfhDescription() {
        return bfhDescription;
    }

    /**
     * @param bfhDescription the bfhDescription to set
     */
    public void setBfhDescription(String bfhDescription) {
        this.bfhDescription = bfhDescription;
    }

    /**
     * @return the shishiBfh
     */
    public String getShishiBfh() {
        return shishiBfh;
    }

    /**
     * @param shishiBfh the shishiBfh to set
     */
    public void setShishiBfh(String shishiBfh) {
        this.shishiBfh = shishiBfh;
    }

    /**
     * @return the shenheYuan
     */
    public String getShenheYuan() {
        return shenheYuan;
    }

    /**
     * @param shenheYuan the shenheYuan to set
     */
    public void setShenheYuan(String shenheYuan) {
        this.shenheYuan = shenheYuan;
    }

    /**
     * @return the shenheZuzh
     */
    public String getShenheZuzh() {
        return shenheZuzh;
    }

    /**
     * @param shenheZuzh the shenheZuzh to set
     */
    public void setShenheZuzh(String shenheZuzh) {
        this.shenheZuzh = shenheZuzh;
    }

    /**
     * @return the sshDeptFzr
     */
    public String getSshDeptFzr() {
        return sshDeptFzr;
    }

    /**
     * @param sshDeptFzr the sshDeptFzr to set
     */
    public void setSshDeptFzr(String sshDeptFzr) {
        this.sshDeptFzr = sshDeptFzr;
    }

    /**
     * @return the qianziDate
     */
    public Date getQianziDate() {
        return qianziDate;
    }

    /**
     * @param qianziDate the qianziDate to set
     */
    public void setQianziDate(Date qianziDate) {
        this.qianziDate = qianziDate;
    }

    /**
     * @return the bfhXz
     */
    public String getBfhXz() {
        return bfhXz;
    }

    /**
     * @param bfhXz the bfhXz to set
     */
    public void setBfhXz(String bfhXz) {
        this.bfhXz = bfhXz;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    /**
     * @return the editDate
     */
    public Date getEditDate() {
        return editDate;
    }

    /**
     * @param editDate the editDate to set
     */
    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }

    /**
     * @return the editName
     */
    public String getEditName() {
        return editName;
    }

    /**
     * @param editName the editName to set
     */
    public void setEditName(String editName) {
        this.editName = editName;
    }

    /**
     * @return the postDate
     */
    public Date getPostDate() {
        return postDate;
    }

    /**
     * @param postDate the postDate to set
     */
    public void setPostDate(Date postDate) {
        this.postDate = postDate;
    }

    /**
     * @return the postName
     */
    public String getPostName() {
        return postName;
    }

    /**
     * @param postName the postName to set
     */
    public void setPostName(String postName) {
        this.postName = postName;
    }

    /**
     * @return the sourceOrder
     */
    public String getSourceOrder() {
        return sourceOrder;
    }

    /**
     * @param sourceOrder the sourceOrder to set
     */
    public void setSourceOrder(String sourceOrder) {
        this.sourceOrder = sourceOrder;
    }

    /**
     * @return the isJieti
     */
    public Boolean getIsJieti() {
        return isJieti;
    }

    /**
     * @param isJieti the isJieti to set
     */
    public void setIsJieti(Boolean isJieti) {
        this.isJieti = isJieti;
    }

    /**
     * @return the isClose
     */
    public Boolean getIsClose() {
        return isClose;
    }

    /**
     * @param isClose the isClose to set
     */
    public void setIsClose(Boolean isClose) {
        this.isClose = isClose;
    }

    /**
     * @return the closeDate
     */
    public Date getCloseDate() {
        return closeDate;
    }

    /**
     * @param closeDate the closeDate to set
     */
    public void setCloseDate(Date closeDate) {
        this.closeDate = closeDate;
    }

    /**
     * @return the closeName
     */
    public String getCloseName() {
        return closeName;
    }

    /**
     * @param closeName the closeName to set
     */
    public void setCloseName(String closeName) {
        this.closeName = closeName;
    }

    /**
     * @return the fzDept
     */
    public String getFzDept() {
        return fzDept;
    }

    /**
     * @param fzDept the fzDept to set
     */
    public void setFzDept(String fzDept) {
        this.fzDept = fzDept;
    }

    /**
     * @return the sshGuocheng
     */
    public String getSshGuocheng() {
        return sshGuocheng;
    }

    /**
     * @param sshGuocheng the sshGuocheng to set
     */
    public void setSshGuocheng(String sshGuocheng) {
        this.sshGuocheng = sshGuocheng;
    }

    /**
     * @return the gukeDeptId
     */
    public String getGukeDeptId() {
        return gukeDeptId;
    }

    /**
     * @param gukeDeptId the gukeDeptId to set
     */
    public void setGukeDeptId(String gukeDeptId) {
        this.gukeDeptId = gukeDeptId;
    }

    /**
     * @return the gukeDeptName
     */
    public String getGukeDeptName() {
        return gukeDeptName;
    }

    /**
     * @param gukeDeptName the gukeDeptName to set
     */
    public void setGukeDeptName(String gukeDeptName) {
        this.gukeDeptName = gukeDeptName;
    }

    /**
     * @return the ssGuocheng2Id
     */
    public String getSsGuocheng2Id() {
        return ssGuocheng2Id;
    }

    /**
     * @param ssGuocheng2Id the ssGuocheng2Id to set
     */
    public void setSsGuocheng2Id(String ssGuocheng2Id) {
        this.ssGuocheng2Id = ssGuocheng2Id;
    }

    /**
     * @return the ssGuocheng2Name
     */
    public String getSsGuocheng2Name() {
        return ssGuocheng2Name;
    }

    /**
     * @param ssGuocheng2Name the ssGuocheng2Name to set
     */
    public void setSsGuocheng2Name(String ssGuocheng2Name) {
        this.ssGuocheng2Name = ssGuocheng2Name;
    }

    /**
     * @return the ssGuocheng3Id
     */
    public String getSsGuocheng3Id() {
        return ssGuocheng3Id;
    }

    /**
     * @param ssGuocheng3Id the ssGuocheng3Id to set
     */
    public void setSsGuocheng3Id(String ssGuocheng3Id) {
        this.ssGuocheng3Id = ssGuocheng3Id;
    }

    /**
     * @return the ssGuocheng3Name
     */
    public String getSsGuocheng3Name() {
        return ssGuocheng3Name;
    }

    /**
     * @param ssGuocheng3Name the ssGuocheng3Name to set
     */
    public void setSsGuocheng3Name(String ssGuocheng3Name) {
        this.ssGuocheng3Name = ssGuocheng3Name;
    }

    /**
     * @return the sourceGoal
     */
    public String getSourceGoal() {
        return sourceGoal;
    }

    /**
     * @param sourceGoal the sourceGoal to set
     */
    public void setSourceGoal(String sourceGoal) {
        this.sourceGoal = sourceGoal;
    }

    /**
     * @return the statusTj
     */
    public boolean isStatusTj() {
        return statusTj;
    }

    /**
     * @param statusTj the statusTj to set
     */
    public void setStatusTj(boolean statusTj) {
        this.statusTj = statusTj;
    }

    /**
     * @return the tjPost
     */
    public String getTjPost() {
        return tjPost;
    }

    /**
     * @param tjPost the tjPost to set
     */
    public void setTjPost(String tjPost) {
        this.tjPost = tjPost;
    }

    /**
     * @return the tjPost2
     */
    public String getTjPost2() {
        return tjPost2;
    }

    /**
     * @param tjPost2 the tjPost2 to set
     */
    public void setTjPost2(String tjPost2) {
        this.tjPost2 = tjPost2;
    }
}
