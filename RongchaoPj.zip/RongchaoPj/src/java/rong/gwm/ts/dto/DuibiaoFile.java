/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("duibiao_file")
public class DuibiaoFile {

    @Column("duibiao_id")
    @Id
    private Integer duibiaoId;
    @Column("title")
    private String title;
    @Column("file_path")
    private String filePath;
    @Column("dept_no")
    private String deptNo;
    @Column("dept_name")
    private String deptName;
    @Column("lingjian_zu")
    private String lingjianZu;
    @Column("zhuanye_lx")
    private String zhuanyeLx;
    @Column("remark")
    private String remark;
    @Column("status")
    private int status;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;
    @Column("edit_date")
    private Date editDate;
    @Column("edit_name")
    private String editName;
    @Column("post_date")
    private Date postDate;
    @Column("post_name")
    private String postName;
    @Column("post_remark")
    private String postRemark;

    public DuibiaoFile() {
    }

    public DuibiaoFile(String title, String remark, int status) {
        this.title = title;
        this.remark = remark;
        this.status = status;
    }

    /**
     * @return the duibiaoId
     */
    public Integer getDuibiaoId() {
        return duibiaoId;
    }

    /**
     * @param duibiaoId the duibiaoId to set
     */
    public void setDuibiaoId(Integer duibiaoId) {
        this.duibiaoId = duibiaoId;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @return the filePath
     */
    public String getFilePath() {
        return filePath;
    }

    /**
     * @param filePath the filePath to set
     */
    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    /**
     * @return the deptNo
     */
    public String getDeptNo() {
        return deptNo;
    }

    /**
     * @param deptNo the deptNo to set
     */
    public void setDeptNo(String deptNo) {
        this.deptNo = deptNo;
    }

    /**
     * @return the deptName
     */
    public String getDeptName() {
        return deptName;
    }

    /**
     * @param deptName the deptName to set
     */
    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    /**
     * @return the lingjianZu
     */
    public String getLingjianZu() {
        return lingjianZu;
    }

    /**
     * @param lingjianZu the lingjianZu to set
     */
    public void setLingjianZu(String lingjianZu) {
        this.lingjianZu = lingjianZu;
    }

    /**
     * @return the zhuanyeLx
     */
    public String getZhuanyeLx() {
        return zhuanyeLx;
    }

    /**
     * @param zhuanyeLx the zhuanyeLx to set
     */
    public void setZhuanyeLx(String zhuanyeLx) {
        this.zhuanyeLx = zhuanyeLx;
    }

    /**
     * @return the remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * @param remark the remark to set
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    /**
     * @return the editDate
     */
    public Date getEditDate() {
        return editDate;
    }

    /**
     * @param editDate the editDate to set
     */
    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }

    /**
     * @return the editName
     */
    public String getEditName() {
        return editName;
    }

    /**
     * @param editName the editName to set
     */
    public void setEditName(String editName) {
        this.editName = editName;
    }

    /**
     * @return the postDate
     */
    public Date getPostDate() {
        return postDate;
    }

    /**
     * @param postDate the postDate to set
     */
    public void setPostDate(Date postDate) {
        this.postDate = postDate;
    }

    /**
     * @return the postName
     */
    public String getPostName() {
        return postName;
    }

    /**
     * @param postName the postName to set
     */
    public void setPostName(String postName) {
        this.postName = postName;
    }

    /**
     * @return the postRemark
     */
    public String getPostRemark() {
        return postRemark;
    }

    /**
     * @param postRemark the postRemark to set
     */
    public void setPostRemark(String postRemark) {
        this.postRemark = postRemark;
    }
}
