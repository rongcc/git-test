/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.web;

import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.event.ForwardEvent;
import org.zkoss.zk.ui.util.GenericForwardComposer;
import org.zkoss.zul.*;
import org.zkoss.zul.event.PagingEvent;
import rcsoft.rc.db.CachingRcdb;
import rcsoft.rc.util.RcUse;
import rong.gwm.drms.web.OpenDetail;
import rong.gwm.ts.dto.Guocheng;
import rong.gwm.ts.services.CodeAttributeServices;

/**
 *
 * @author ZhouRongChao
 */
public class GuochengComposer extends GenericForwardComposer {

    private final int _pageSize = 10;
    private int _startPageNumber = 0;
    private int _totalSize = 0;
    private boolean _needsTotalSizeUpdate = true;
    private Grid dataGrid;
    private Paging userPaging;
    GuochengPagingListModel model = null;
    String cdtStr = "";
    Listbox colname;
    Textbox keyword;
    Datebox start_time;
    Datebox end_time;
    Combobox data_scope;
    String urStr;

    @Override
    public void doAfterCompose(Component comp) throws Exception {
        super.doAfterCompose(comp);
        dataGrid.setRowRenderer(new RowRenderer() {

            @SuppressWarnings("unchecked")
            public void render(Row row, Object data) throws Exception {
                Guocheng w = (Guocheng) data;
                Radio aRa = new Radio();
                aRa.setValue(w.getId() + "");
                row.getChildren().add(aRa);
                row.getChildren().add(new Label(w.getId() + ""));
                row.getChildren().add(new Label(w.getCode()));
                int s = w.getLevel();
                Space ksp = new Space();
                ksp.setBar(false);
                if (s > 1) {
                    s = (s-1) * 25;
                }
                ksp.setSpacing(s + "px");
                Div md = new Div();
                md.appendChild(ksp);
                md.appendChild(new Label(w.getName()));
                row.getChildren().add(md);
                row.getChildren().add(new Label(w.getBelonger()));
                row.getChildren().add(new Label(new CodeAttributeServices().getDescription(CachingRcdb.getInstance().getDs4Ts(), "ss_object", w.getOrgId() + "")));
                row.getChildren().add(new Label(w.getType()));
                row.getChildren().add(new Label(w.getLevel() + ""));
                row.getChildren().add(new Label(w.getFatherName()));
                row.getChildren().add(new Label(w.getPreGuocheng()));
                row.getChildren().add(new Label(w.getInputs()));
                row.getChildren().add(new Label(w.getOutputs()));
                row.getChildren().add(new Label(w.getResources()));
                row.getChildren().add(new Label(w.getManaged()));
                row.getChildren().add(new Label(RcUse.formatDate(w.getInputDate())));
                row.getChildren().add(new Label(w.getInputName()));
                row.getChildren().add(new Label(RcUse.formatDate(w.getEditDate())));
                row.getChildren().add(new Label(w.getEditName()));
                row.setValue(w.getId() + "");
                row.addEventListener("onDoubleClick", new OpenDetail(w.getId().toString(), "guocheng/guocheng_detail.zul"));
            }
        });

        urStr = (String) session.getAttribute("ur");
        //默认为内部数据
        cdtStr = "id in(SELECT id FROM om_guocheng s left outer join operator o on s.input_name=o.oper_no "
                + " where o.dept_no=(select dept_no from operator where oper_no='" + urStr + "')) and ";
        refreshModel(cdtStr, _startPageNumber);
    }

    public void onClick$btnGenerate() {
        String start_date = "1900-1-1";
        if (start_time.getValue() != null) {
            start_date = RcUse.formatDateTime(start_time.getValue());
        }
        String end_date = "9999-12-31";
        if (end_time.getValue() != null) {
            end_date = RcUse.formatDateTime(end_time.getValue());
        }
        String myColumn = "status";
        String myWord = "";
        if (colname.getSelectedItem() != null) {
            myColumn = (String) colname.getSelectedItem().getValue();
        }
        if (keyword.getValue() != null) {
            myWord = keyword.getValue();
        }
        //查询的数据范围
        String scope_type = (String) data_scope.getSelectedItem().getValue();
        String scopStr = "";
        if (scope_type.equals("20")) {
            //内部数据
            scopStr = "id in(SELECT id FROM om_guocheng s left outer join operator o on s.input_name=o.oper_no "
                    + " where o.dept_no=(select dept_no from operator where oper_no='" + urStr + "')) and ";
        } else if (scope_type.equals("10")) {
            //个人数据
            scopStr = "input_name='" + urStr + "' and ";
        }
        cdtStr = scopStr + myColumn + " like " + "'%" + myWord + "%' and (input_date between '" + start_date + "' and '" + end_date + "')"
                + " and ";
        _needsTotalSizeUpdate = true;
        refreshModel(cdtStr, 0);
    }

    public void onPaging$userPaging(ForwardEvent event) {
        final PagingEvent pe = (PagingEvent) event.getOrigin();
        _startPageNumber = pe.getActivePage();
        refreshModel(cdtStr, _startPageNumber);
    }

    private void refreshModel(String cdtStr, int activePage) {
        userPaging.setPageSize(_pageSize);
        model = new GuochengPagingListModel(urStr, cdtStr, activePage, _pageSize);

        if (_needsTotalSizeUpdate) {
            _totalSize = model.getTotalSize();
            _needsTotalSizeUpdate = false;
        }

        userPaging.setTotalSize(_totalSize);
        userPaging.setActivePage(activePage);

        dataGrid.setModel(model);
    }
}
