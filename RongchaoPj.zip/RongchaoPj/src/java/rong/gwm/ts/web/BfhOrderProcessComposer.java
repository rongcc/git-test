/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.web;

import javax.sql.DataSource;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.event.ForwardEvent;
import org.zkoss.zk.ui.util.GenericForwardComposer;
import org.zkoss.zul.*;
import org.zkoss.zul.event.PagingEvent;
import rcsoft.rc.util.RcUse;
import rong.gwm.ts.dto.BfhOrder;
import rong.gwm.ts.services.OrderSrcService;

/**
 *
 * @author zhourongchao
 */
public class BfhOrderProcessComposer extends GenericForwardComposer {

    private static final long serialVersionUID = 1L;
    private final int _pageSize = 10;
    private int _startPageNumber = 0;
    private int _totalSize = 0;
    private boolean _needsTotalSizeUpdate = true;
    private Grid dataGrid;
    private Paging userPaging;
    BfhOrderPagingListModel model = null;
    String cdtStr = "";
    Listbox colname;
    Textbox keyword;
    OrderSrcService srcService = new OrderSrcService();
    DataSource ds = rcsoft.rc.db.CachingRcdb.getInstance().getDs4Ts();

    @Override
    public void doAfterCompose(Component comp) throws Exception {
        super.doAfterCompose(comp);
        dataGrid.setRowRenderer(new RowRenderer() {

            @SuppressWarnings("unchecked")
            public void render(Row row, Object data) throws Exception {
                BfhOrder w = (BfhOrder) data;
                Radio aRa = new Radio();
                aRa.setValue(w.getBfhNo() + "");
                row.getChildren().add(aRa);
                row.getChildren().add(new Label(w.getBfhNo() + ""));
                row.getChildren().add(new Label(w.getSsGuochengName()));
                row.getChildren().add(new Label(w.getBfhDescription()));
                //
                String yzjl = srcService.getLastYanzhengJiluNo(ds, w.getBfhNo());
                String dcjl = srcService.getLastDcNo(ds, w.getBfhNo());
                Label ab = new Label();
                if (w.getIsJieti()) {
                    ab = new Label("已结题");
                    ab.setStyle("background-color:#008B00;color:#FFFFFF;");//绿
                } else if (yzjl != null) {
                    ab = new Label("已验证");
                    ab.setStyle("background-color:#CD8500;color:#FFFFFF;");//黄
                } else if (dcjl != null) {
                    ab = new Label("已对策");
                    ab.setStyle("background-color:#4169E1;color:#FFFFFF;");//蓝
                } else if (dcjl == null) {
                    ab = new Label("等待对策");
                    ab.setStyle("background-color:#CD3700;color:#FFFFFF;weight:900;");//红
                }
                row.getChildren().add(ab);
                row.getChildren().add(new Label(w.getSshDeptName()));
                row.getChildren().add(new Label(w.getShenheYuan()));
                row.getChildren().add(new Label(w.getShenheYiju()));
                row.getChildren().add(new Label(w.getInputName()));
                row.getChildren().add(new Label(RcUse.formatDate(w.getInputDate())));
            }
        });
        String urStr = (String) session.getAttribute("ur");
        cdtStr = " bfh_no in(SELECT bfh_no FROM bfh_order s left outer join operator o on s.input_name=o.oper_no "
                + "where o.dept_no=(select dept_no from operator where oper_no='" + urStr + "'))"
                + " or ssh_dept_id=(select dept_no from operator where oper_no='" + urStr + "') and ";
        refreshModel(cdtStr, _startPageNumber);
    }

    public void onClick$btnGenerate() {
        String myColumn = "";
        String myWord = "";
        myColumn = (String) colname.getSelectedItem().getValue();
        if (keyword.getValue() != null) {
            myWord = keyword.getValue();
        }
        cdtStr = myColumn + " like " + "'%" + myWord + "%' and ";
        _needsTotalSizeUpdate = true;
        refreshModel(cdtStr, 0);
    }

    public void onPaging$userPaging(ForwardEvent event) {
        final PagingEvent pe = (PagingEvent) event.getOrigin();
        _startPageNumber = pe.getActivePage();
        refreshModel(cdtStr, _startPageNumber);
    }

    private void refreshModel(String cdtStr, int activePage) {
        userPaging.setPageSize(_pageSize);
        String urStr = (String) session.getAttribute("ur");
        model = new BfhOrderPagingListModel(urStr, cdtStr, activePage, _pageSize);

        if (_needsTotalSizeUpdate) {
            _totalSize = model.getTotalSize();
            _needsTotalSizeUpdate = false;
        }

        userPaging.setTotalSize(_totalSize);
        userPaging.setActivePage(activePage);

        dataGrid.setModel(model);
    }
}
