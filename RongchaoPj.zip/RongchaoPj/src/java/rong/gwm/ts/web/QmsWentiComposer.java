/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.web;

import java.util.List;
import javax.sql.DataSource;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.event.ForwardEvent;
import org.zkoss.zk.ui.util.GenericForwardComposer;
import org.zkoss.zul.*;
import org.zkoss.zul.event.PagingEvent;
import rcsoft.rc.db.CachingRcdb;
import rong.gwm.drms.web.OpenDetail;
import rong.gwm.ts.dto.QmsWenti;
import rong.gwm.ts.dto.ShenheJihua;
import rong.gwm.ts.services.QmsWentiService;
import rong.gwm.ts.util.DadaoUse;

/**
 *
 * @author ZhouRongChao
 */
public class QmsWentiComposer extends GenericForwardComposer {

    private static final long serialVersionUID = 1L;
    private final int _pageSize = 10;
    private int _startPageNumber = 0;
    private int _totalSize = 0;
    private boolean _needsTotalSizeUpdate = true;
    private Grid dataGrid;
    private Paging userPaging;
    QmsWentiPagingListModel model = null;
    String cdtStr = "";
    Listbox colname;
    Textbox keyword;
    QmsWentiService pzService = new QmsWentiService();
    private static final DataSource ds = CachingRcdb.getInstance().getDs4Ts();

    @Override
    public void doAfterCompose(Component comp) throws Exception {
        super.doAfterCompose(comp);
        dataGrid.setRowRenderer(new RowRenderer() {

            @SuppressWarnings("unchecked")
            public void render(Row row, Object data) throws Exception {
                QmsWenti w = (QmsWenti) data;
                Radio aRa = new Radio();
                aRa.setValue(w.getWentiNo() + "");
                row.getChildren().add(aRa);
                row.getChildren().add(new Label(w.getWentiNo() + ""));
                row.getChildren().add(new Label(w.getWentiMiaoshu() + ""));
                row.getChildren().add(new Label(w.getYanzhongdu()));
                row.getChildren().add(new Html(w.getYuanyinFenxi()==null?"":w.getYuanyinFenxi().replace("\\r\\n", "<br/>")));  //所剩天数
                int ssd = DadaoUse.getInstance().getRemantDay(w.getInputDate(), 7);
                Label dCell = new Label(ssd + "天");
                //七天内审核计划批准显示绿色否则为红色
                List sjList = pzService.fetchWentiJihua(ds, w.getWentiNo());
                //一个关联计划批准即显示绿色
                dCell.setStyle("background-color: #80FF91;");
                if (ssd < 0) {
                    dCell.setStyle("background-color: #FF3300;");
                } else if (ssd == 0) {
                    dCell.setStyle("background-color: yellow;");
                }
                for (int i = 0; i < sjList.size(); i++) {
                    ShenheJihua sj = (ShenheJihua) sjList.get(i);
                    int sta = sj.getStatus();
                    if (sta == 2) {
                        dCell = new Label("计划批准");
                        //dCell.setStyle("background-color: #00FF99;");
                    }
                }
                if (w.getZhuangtaiStatus() == 1) {
                    dCell = new Label("关闭倒计时");
                    //dCell.setStyle("background-color: #00FF99;");
                }
                row.getChildren().add(dCell);
                //row.getChildren().add(new Label(w.getRemark()));
                row.getChildren().add(new Label(w.getSsDept()));
                //row.getChildren().add(new Label(w.getSourceOrder()));
                row.addEventListener("onDoubleClick", new OpenDetail(w.getWentiNo().toString(), "shenhe/qms_wenti_detail.zul"));
            }
        });

        refreshModel(cdtStr, _startPageNumber);
    }

    public void onClick$btnGenerate() {
        //
        String myColumn;
        String myWord = "";
        myColumn = (String) colname.getSelectedItem().getValue();
        if (keyword.getValue() != null) {
            myWord = keyword.getValue();
        }
        cdtStr = myColumn + " like " + "'%" + myWord + "%' and ";
        _needsTotalSizeUpdate = true;
        refreshModel(cdtStr, 0);
    }

    public void onPaging$userPaging(ForwardEvent event) {
        final PagingEvent pe = (PagingEvent) event.getOrigin();
        _startPageNumber = pe.getActivePage();
        refreshModel(cdtStr, _startPageNumber);
    }

    private void refreshModel(String cdtStr, int activePage) {
        userPaging.setPageSize(_pageSize);
        String urStr = (String) session.getAttribute("ur");
        model = new QmsWentiPagingListModel(urStr, cdtStr, activePage, _pageSize);

        if (_needsTotalSizeUpdate) {
            _totalSize = model.getTotalSize();
            _needsTotalSizeUpdate = false;
        }

        userPaging.setTotalSize(_totalSize);
        userPaging.setActivePage(activePage);

        dataGrid.setModel(model);
    }
}
