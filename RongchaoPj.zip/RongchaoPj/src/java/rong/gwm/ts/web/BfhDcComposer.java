/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.web;

import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.event.ForwardEvent;
import org.zkoss.zk.ui.util.GenericForwardComposer;
import org.zkoss.zul.*;
import org.zkoss.zul.event.PagingEvent;
import rcsoft.rc.util.RcUse;
import rong.gwm.drms.web.OpenDetail;
import rong.gwm.ts.dto.BfhDc;
import rong.gwm.ts.services.OrderSrcService;

/**
 *
 * @author ZhouRongChao
 */
public class BfhDcComposer extends GenericForwardComposer {

    private static final long serialVersionUID = 1L;
    private final int _pageSize = 10;
    private int _startPageNumber = 0;
    private int _totalSize = 0;
    private boolean _needsTotalSizeUpdate = true;
    private Radiogroup iRag;
    private Grid dataGrid;
    private Paging userPaging;
    String cdtStr = "";
    Listbox colname;
    Textbox keyword;
    Datebox start_time;
    Datebox end_time;
    Combobox data_scope;
    String urStr;
    BfhDcPagingListModel model = null;
    OrderSrcService srcService = new OrderSrcService();

    @Override
    public void doAfterCompose(Component comp) throws Exception {
        super.doAfterCompose(comp);
        dataGrid.setRowRenderer(new RowRenderer() {

            @SuppressWarnings("unchecked")
            public void render(Row row, Object data) throws Exception {
                BfhDc w = (BfhDc) data;
                Radio aRa = new Radio();
                aRa.setValue(w.getDcNo() + "");
                row.getChildren().add(aRa);
                row.getChildren().add(new Label(w.getDcNo() + ""));
                row.getChildren().add(new Label(w.getYuanyinFenxi()));
                row.getChildren().add(new Label(w.getJiuzheng()));
                row.getChildren().add(new Label(RcUse.formatDate(w.getJiuzhengJiedianDate())));
                Label cuoshiLa = new Label(w.getJiuzhengCuoshi());
                cuoshiLa.setMultiline(true);
                row.getChildren().add(cuoshiLa);
                row.getChildren().add(new Label(RcUse.formatDate(w.getCuoshiJiedianDate())));
                Label ab = new Label();
                if (w.getStatus() == 2) {
                    ab = new Label("已批准");
                    ab.setStyle("background-color:#008B00;color:#FFFFFF;");//绿
                }
                if (w.getStatus() == 1) {
                    ab = new Label("已批准");
                    ab.setStyle("background-color:#008B00;color:#FFFFFF;");//绿
                } else if (w.isStatusTj()) {
                    ab = new Label("已提交");
                    ab.setStyle("background-color:#4169E1;color:#FFFFFF;");//蓝
                } else if (w.getStatus() == 0) {
                    ab = new Label("编制中");
                    ab.setStyle("background-color:#CD3700;color:#FFFFFF;weight:900;");//红
                }
                row.getChildren().add(ab);
                row.getChildren().add(new Label(w.getInputName()));
                row.getChildren().add(new Label(RcUse.formatDate(w.getInputDate())));
                row.getChildren().add(new Label(w.getSourceOrder()));
                row.getChildren().add(new Label(w.getFzr()));
                row.addEventListener("onDoubleClick", new OpenDetail(w.getDcNo().toString(), "bfh/bfh_dc_detail.zul"));
            }
        });

        urStr = (String) session.getAttribute("ur");
        //默认为内部数据
        cdtStr = "dc_no in(SELECT dc_no FROM bfh_dc s left outer join operator o on s.input_name=o.oper_no "
                + " where o.dept_no=(select dept_no from operator where oper_no='" + urStr + "')) and ";
        refreshModel(cdtStr, _startPageNumber);
    }

    public void onClick$btnGenerate() {
        String start_date = "1900-1-1";
        if (start_time.getValue() != null) {
            start_date = RcUse.formatDateTime(start_time.getValue());
        }
        String end_date = "9999-12-31";
        if (end_time.getValue() != null) {
            end_date = RcUse.formatDateTime(end_time.getValue());
        }
        String myColumn = "";
        String myWord = "";
        myColumn = (String) colname.getSelectedItem().getValue();
        if (keyword.getValue() != null) {
            myWord = keyword.getValue();
        }
        //查询的数据范围
        String scope_type = (String) data_scope.getSelectedItem().getValue();
        String scopStr = "";
        if (scope_type.equals("20")) {
            //内部数据
            scopStr = "dc_no in(SELECT dc_no FROM bfh_dc s left outer join operator o on s.input_name=o.oper_no "
                    + " where o.dept_no=(select dept_no from operator where oper_no='" + urStr + "')) and ";
        } else if (scope_type.equals("10")) {
            //个人数据
            scopStr = "input_name='" + urStr + "' and ";
        }
        cdtStr = scopStr + myColumn + " like " + "'%" + myWord + "%' and (input_date between '" + start_date + "' and '" + end_date + "')" + " and ";
        _needsTotalSizeUpdate = true;
        refreshModel(cdtStr, 0);
    }

    public void onPaging$userPaging(ForwardEvent event) {
        final PagingEvent pe = (PagingEvent) event.getOrigin();
        _startPageNumber = pe.getActivePage();
        refreshModel(cdtStr, _startPageNumber);
    }

    private void refreshModel(String cdtStr, int activePage) {
        userPaging.setPageSize(_pageSize);
        urStr = (String) session.getAttribute("ur");
        model = new BfhDcPagingListModel(urStr, cdtStr, activePage, _pageSize);

        if (_needsTotalSizeUpdate) {
            _totalSize = model.getTotalSize();
            _needsTotalSizeUpdate = false;
        }

        userPaging.setTotalSize(_totalSize);
        userPaging.setActivePage(activePage);

        dataGrid.setModel(model);
    }
}