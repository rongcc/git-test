/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.web;

import java.util.HashMap;
import java.util.Map;
import org.zkoss.zk.ui.Executions;
import org.zkoss.zk.ui.event.GenericEventListener;
import org.zkoss.zul.Window;

/**
 *
 * @author ZhouRongChao
 */
public class AutoVue extends GenericEventListener {

    String rfileName = "";
    String fileName = "";
    String filePath = "";

    public AutoVue(String p1, String p2, String p3) {
        rfileName = p1;
        fileName = p2;
        filePath = p3;
    }

    public void onClick() {
        Map map = new HashMap();
        map.put("pno", filePath);
        map.put("fname", fileName);
        map.put("rfname", rfileName);
        try {
            final Window win = (Window) Executions.createComponents(
                    "../RC/soft/auto_vue.zul", null, map);
            win.setMaximizable(true);
            win.doModal();
        } catch (Exception e) {
        }
    }
}
