/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.web;

import java.util.List;
import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rcsoft.rc.db.CachingRcdb;
import rong.gwm.ts.dto.ShenheBaogao;

/**
 *
 * @author ZhouRongChao
 */
public class ShenheBaogaoPagingListModel extends AbstractPagingListModel {

    private static final long serialVersionUID = -1L;
    private int totalSize;

    public ShenheBaogaoPagingListModel(String urStr, String cdtStr, int startPageNumber, int pageSize) {
        super(urStr, cdtStr, startPageNumber, pageSize);
    }

    @Override
    protected List getPageData(String urStr, String cdtStr, int itemStartNumber, int pageSize) {
        return search(urStr, cdtStr, itemStartNumber, pageSize);
    }

    @Override
    public int getTotalSize() {
        return totalSize;
    }

    private List search(String urStr, String cdtStr, int itemStartNumber, int pageSize) {
        //System.out.println("k:"+urStr+"-"+cdtStr);
        Dao dao = new NutDao(CachingRcdb.getInstance().getDs4Ts());
        this.totalSize = dao.count(ShenheBaogao.class, Cnd.wrap(cdtStr + " status!=-1 "));
        List al = dao.query(ShenheBaogao.class, Cnd.wrap(cdtStr + " status!=-1  order by input_date desc limit " + itemStartNumber + "," + pageSize), null);

        return al;
    }
}
