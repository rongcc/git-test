/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.wflow;

import java.util.Date;

/**
 *
 * @author zhourongchao
 */
public class Shixiang {

    //事项编号
    private int id;
    //事项名
    private String name;
    //事项内容
    private String content;
    //关联单据号
    private String srcOrderId;
    private Date inputDate;
    private String inputName;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the content
     */
    public String getContent() {
        return content;
    }

    /**
     * @param content the content to set
     */
    public void setContent(String content) {
        this.content = content;
    }

    /**
     * @return the srcOrderId
     */
    public String getSrcOrderId() {
        return srcOrderId;
    }

    /**
     * @param srcOrderId the srcOrderId to set
     */
    public void setSrcOrderId(String srcOrderId) {
        this.srcOrderId = srcOrderId;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }
}
