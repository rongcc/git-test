/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.wflow;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.PK;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("w_step")
@PK({"stepId", "flowId"})
public class WStep {

    @Column("step_id")
    private String stepId;
    @Column("flow_id")
    private int flowId;
    @Column("deal_status")
    private int dealStatus;
    @Column("deal_date")
    private Date dealDate;
    @Column("deal_name")
    private String dealName;
    @Column("deal_note")
    private String dealNote;
    @Column("step_status")
    private int stepStatus;

    /**
     * @return the stepId
     */
    public String getStepId() {
        return stepId;
    }

    /**
     * @param stepId the stepId to set
     */
    public void setStepId(String stepId) {
        this.stepId = stepId;
    }

    /**
     * @return the flowId
     */
    public int getFlowId() {
        return flowId;
    }

    /**
     * @param flowId the flowId to set
     */
    public void setFlowId(int flowId) {
        this.flowId = flowId;
    }

    /**
     * @return the dealStatus
     */
    public int getDealStatus() {
        return dealStatus;
    }

    /**
     * @param dealStatus the dealStatus to set
     */
    public void setDealStatus(int dealStatus) {
        this.dealStatus = dealStatus;
    }

    /**
     * @return the dealDate
     */
    public Date getDealDate() {
        return dealDate;
    }

    /**
     * @param dealDate the dealDate to set
     */
    public void setDealDate(Date dealDate) {
        this.dealDate = dealDate;
    }

    /**
     * @return the dealName
     */
    public String getDealName() {
        return dealName;
    }

    /**
     * @param dealName the dealName to set
     */
    public void setDealName(String dealName) {
        this.dealName = dealName;
    }

    /**
     * @return the dealNote
     */
    public String getDealNote() {
        return dealNote;
    }

    /**
     * @param dealNote the dealNote to set
     */
    public void setDealNote(String dealNote) {
        this.dealNote = dealNote;
    }

    /**
     * @return the stepStatus
     */
    public int getStepStatus() {
        return stepStatus;
    }

    /**
     * @param stepStatus the stepStatus to set
     */
    public void setStepStatus(int stepStatus) {
        this.stepStatus = stepStatus;
    }
}
