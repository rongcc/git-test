/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.wflow;

import javax.sql.DataSource;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;

/**
 *
 * @author zhourongchao
 */
public class WStepMService {

    public WStepM fetch(DataSource ds, String codeType, String code) {
        WStepM cd = null;
        try {
            Dao dao = new NutDao(ds);
            cd = dao.fetchx(WStepM.class, codeType, code);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cd;
    }

    public int delete(DataSource ds, WStepM cd) {
        int di = 0;
        try {
            Dao dao = new NutDao(ds);
            di = dao.deletex(WStepM.class, cd.getStepId(), cd.getFlowId());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return di;
    }
}
