/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.wflow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;

/**
 *
 * @author zhourongchao
 */
public class WorkFlowService {

    /**
     * 取得这个用户的待办事项列表
     * @param ds
     * @param userName
     * @return
     */
    public List findDaiban(DataSource ds, String userName) {
        List al = new ArrayList();
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            String sqlStr = "select * from oa_flow where flow_id in(select "
                    + "distinct flow_id  from oa_flow_step where deal_status=-1 "
                    + "and user_name=?) order by flow_id desc";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, userName);
            rs = pStmt.executeQuery();
            while (rs.next()) {
                Shixiang item = new Shixiang();
                item.setId(Integer.valueOf(rs.getInt("flow_id")));
                item.setName(rs.getString("flow_name"));
                item.setContent(rs.getString("remark"));
                item.setSrcOrderId(rs.getString("src_order_id"));
                item.setInputName(rs.getString("input_name"));
                al.add(item);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return al;
    }

    /**
     * 取得这个用户的已办事项列表
     * @param ds
     * @param userName
     * @return
     */
    public List findYiban(DataSource ds, String userName) {
        List al = new ArrayList();
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            String sqlStr = "select * from oa_flow where flow_id in(select "
                    + "distinct flow_id  from oa_flow_step where deal_status>0 "
                    + "and user_name=? and step_id>'0000') order by flow_id desc";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, userName);
            rs = pStmt.executeQuery();
            while (rs.next()) {
                Shixiang item = new Shixiang();
                item.setId(Integer.valueOf(rs.getInt("flow_id")));
                item.setName(rs.getString("flow_name"));
                item.setContent(rs.getString("remark"));
                item.setSrcOrderId(rs.getString("src_order_id"));
                item.setInputName(rs.getString("input_name"));
                al.add(item);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return al;
    }

    /**
     * 取得这个用户的已发事项列表
     * @param ds
     * @param userName
     * @return
     */
    public List findYifa(DataSource ds, String userName) {
        List al = new ArrayList();
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            String sqlStr = "select * from oa_flow where flow_id in(select "
                    + "distinct flow_id  from oa_flow_step where step_id='0000' "
                    + "and user_name=?) order by flow_id desc";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, userName);
            rs = pStmt.executeQuery();
            while (rs.next()) {
                Shixiang item = new Shixiang();
                item.setId(Integer.valueOf(rs.getInt("flow_id")));
                item.setName(rs.getString("flow_name"));
                item.setContent(rs.getString("remark"));
                item.setSrcOrderId(rs.getString("src_order_id"));
                item.setInputName(rs.getString("input_name"));
                al.add(item);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return al;
    }

    /**
     * 设置待办步骤为-1
     * @param ds
     * @param flowId
     * @return
     */
    public int signDaiban(DataSource ds, int flowId) {
        int num = 0;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            String sqlStr = "select max(step_id) from w_step where flow_id=? and deal_status=1";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setInt(1, flowId);
            rs = pStmt.executeQuery();
            String start = null;
            if (rs.next()) {
                start = new StringBuffer().append(rs.getInt(1) + 10001).substring(1);
                sqlStr = "update w_step set deal_status=-1 where flow_id=? and deal_status!=1 and step_id like ?";
                pStmt = conn.prepareStatement(sqlStr);
                pStmt.setInt(1, flowId);
                pStmt.setString(2, start + "%");
                num += pStmt.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return num;
    }

    /**
     * 处理这个步骤
     * @param ds
     * @param flowId
     * @param stepId
     * @param yesNo 1表示同意2表示不同意
     * @return
     */
    public int doDeal(DataSource ds, int flowId, String stepId, int yesNo) {
        int num = 0;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            String sqlStr = "update w_step set deal_status=? where flow_id=? and step_id=? ";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setInt(1, yesNo);
            pStmt.setInt(2, flowId);
            pStmt.setString(3, stepId);
            num += pStmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return num;
    }

    /**
     * 获得用户步骤
     * @param ds
     * @param flowId
     * @param user
     * @return
     */
    public String getMyStep(DataSource ds, int flowId, String user) {
        String stepId = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            String sqlStr = "select step_id from w_step where deal_status=-1 and deal_name=? and flow_id=? order by step_id";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, user);
            pStmt.setInt(2, flowId);
            rs = pStmt.executeQuery();
            if (rs.next()) {
                stepId = rs.getString("step_id");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return stepId;
    }

    public boolean isMyTurn(DataSource ds, int flowId, String user) {
        boolean boo = false;
        try {
            String myStep = this.getMyStep(ds, flowId, user);
            if (myStep != null && !myStep.equals("")) {
                boo = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return boo;
    }

    public WFlow shixiang2FlowOrder(Shixiang shixiang) {
        WFlow order = new WFlow();
        order.setFlowId(shixiang.getId());
        order.setFlowName(shixiang.getName());
        order.setSrcOrderNo(shixiang.getSrcOrderId());
        order.setRemark(shixiang.getContent());
        order.setStatus(Integer.valueOf(0));
        //
        order.setInputName(shixiang.getInputName());
        return order;
    }
}
