/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.wflow;

import javax.sql.DataSource;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;

/**
 *
 * @author zhourongchao
 */
public class WStepService {

    public WStep fetch(DataSource ds, String codeType, String code) {
        WStep cd = null;
        try {
            Dao dao = new NutDao(ds);
            cd = dao.fetchx(WStep.class, codeType, code);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cd;
    }

    public int delete(DataSource ds, WStep cd) {
        int di = 0;
        try {
            Dao dao = new NutDao(ds);
            di = dao.deletex(WStep.class, cd.getStepId(), cd.getFlowId());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return di;
    }
}
