/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.ts.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import org.apache.commons.dbcp.BasicDataSource;

/**
 *
 * @author zhourongchao
 */
public class DBConnect {

    private BasicDataSource ds4Ts = null;
    private BasicDataSource ds4Drms = null;
    private BasicDataSource ds4Rcsoft = null;
    private BasicDataSource ds4Openfire = null;
    private BasicDataSource ds4Car = null;
    private BasicDataSource ds4LocalQms = null;
    private BasicDataSource ds4Chaopj = null;
    //下面是连接SQL SERVER的，测试和正式两个QMS。
    private BasicDataSource ds4TestQms = null;
    private BasicDataSource ds4ServerQms = null;
    //
    private InitialContext ic;
    private Map cache;
    private static DBConnect me;

    static {
        try {
            me = new DBConnect();
        } catch (NamingException se) {
            throw new RuntimeException(se);
        } catch (Exception e) {
        }
    }

    public DBConnect() throws NamingException, Exception {
        ic = new InitialContext();
        cache = Collections.synchronizedMap(new HashMap());
        //Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
        Class.forName("com.mysql.jdbc.Driver");// org.gjt.mm.mysql.Driver");//
    }

    public static DBConnect getInstance() {
        return me;
    }
    private String dbUrl = "jdbc:mysql://localhost:3306/gwm_ts?useUnicode=true&characterEncoding=GBK";
    private String dbUser = "root";
    private String dbPwd = "125412";

    public Connection getConnection() throws Exception {
        return java.sql.DriverManager.getConnection(dbUrl, dbUser, dbPwd);
    }

    public void closeConnection(Connection con) {
        try {
            if (con != null) {
                con.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void closePrepStmt(PreparedStatement prepStmt) {
        try {
            if (prepStmt != null) {
                prepStmt.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void closeResultSet(ResultSet rs) {
        try {
            if (rs != null) {
                rs.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public BasicDataSource getDataSource() {
        BasicDataSource ds = null;
        try {
            if (ds4Ts == null) {
                ds = new BasicDataSource();
                ds.setDriverClassName("com.mysql.jdbc.Driver");
                ds.setUrl(dbUrl);
                ds.setUsername(dbUser);
                ds.setPassword(dbPwd);
                //
                ds4Ts = ds;
            } else {
                ds = ds4Ts;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ds;
    }

    /**
     * 获得sql server数据库的GWMQMS数据源，测试账号。
     * @return
     */
    public BasicDataSource getDataSource2() {
        BasicDataSource ds = null;
        try {
            if (ds4TestQms == null) {
                ds = new BasicDataSource();
                ds.setDriverClassName("net.sourceforge.jtds.jdbc.Driver");
                ds.setUrl("jdbc:jtds:sqlserver://10.1.129.10:1433/GWMQMS");
                ds.setUsername("PB_User");
                ds.setPassword("P1n8a0@1t.b6");
            } else {
                ds = ds4TestQms;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ds;
    }

    /**
     * 获得sql server数据库的GWMQMS数据源，正式账号。
     * @return
     */
    public BasicDataSource getDataSource22() {
        BasicDataSource ds = null;
        try {
            if (ds4ServerQms == null) {
                ds = new BasicDataSource();
                ds.setDriverClassName("net.sourceforge.jtds.jdbc.Driver");
                ds.setUrl("jdbc:jtds:sqlserver://10.1.129.16:1433/QMS_MAIN");
                ds.setUsername("QA_USER1");
                ds.setPassword("G5K2W6U1C9");
            } else {
                ds = ds4ServerQms;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ds;
    }

    /**
     * 获得整车评价数据库gwmcar的数据源。
     * @return
     */
    public BasicDataSource getDataSource4Car() {
        BasicDataSource ds = null;
        try {
            if (ds4Car == null) {
                ds = new BasicDataSource();
                ds.setDriverClassName("com.mysql.jdbc.Driver");
                ds.setUrl("jdbc:mysql://localhost:3306/gwmcar?useUnicode=true&characterEncoding=GBK");
                ds.setUsername("root");
                ds.setPassword("125412");
                //
                ds4Car = ds;
            } else {
                ds = ds4Car;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ds;
    }

    /**
     * 获得设计评审管理数据库gwmdrms的数据源。
     * @return
     */
    public BasicDataSource getDataSource4Drms() {
        BasicDataSource ds = null;
        try {
            if (ds4Drms == null||ds4Drms.getConnection()==null) {
                ds = new BasicDataSource();
                ds.setDriverClassName("com.mysql.jdbc.Driver");
                ds.setUrl("jdbc:mysql://localhost:3306/gwmdrms?useUnicode=true&characterEncoding=GBK");
                ds.setUsername("root");
                ds.setPassword("125412");
                //
                ds4Drms = ds;
            } else {
                ds = ds4Drms;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ds;
    }

    /**
     * 获得设计评审管理数据库chaopj的数据源。
     * @return
     */
    public BasicDataSource getDataSource4Chaopj() {
        BasicDataSource ds = null;
        try {
            if (ds4Chaopj == null) {
                ds = new BasicDataSource();
                ds.setDriverClassName("com.mysql.jdbc.Driver");
                ds.setUrl("jdbc:mysql://localhost:3306/chaopj?useUnicode=true&characterEncoding=GBK");
                ds.setUsername("root");
                ds.setPassword("125412");
                //
                ds4Chaopj = ds;
            } else {
                ds = ds4Chaopj;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ds;
    }

    /**
     * 获得MySQL与原QMS映射的gwmqms数据库。
     * @return
     */
    public BasicDataSource getDataSource4MySQLgwmqms() {
        BasicDataSource ds = null;
        try {
            if (ds4LocalQms == null) {
                ds = new BasicDataSource();
                ds.setDriverClassName("com.mysql.jdbc.Driver");
                ds.setUrl("jdbc:mysql://localhost:3306/gwmqms?useUnicode=true&characterEncoding=GBK");
                ds.setUsername("root");
                ds.setPassword("125412");
            } else {
                ds = ds4LocalQms;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ds;
    }

    /**
     * 获得数据库openfire的数据源。
     * @return
     */
    public BasicDataSource getDataSource4Openfire() {
        BasicDataSource ds = null;
        try {
            if (ds4Openfire == null) {
                ds = new BasicDataSource();
                ds.setDriverClassName("com.mysql.jdbc.Driver");
                ds.setUrl("jdbc:mysql://localhost:3306/openfire?useUnicode=true&characterEncoding=GBK");
                ds.setUsername("root");
                ds.setPassword("125412");
                //
                ds4Openfire = ds;
            } else {
                ds = ds4Openfire;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ds;
    }

    /**
     * 获取数据库rcsoft的数据源。
     * @return
     */
    public BasicDataSource getDataSource4Rcsoft() {
        BasicDataSource ds = null;
        try {
            if (ds4Rcsoft == null) {
                ds = new BasicDataSource();
                ds.setDriverClassName("com.mysql.jdbc.Driver");
                ds.setUrl("jdbc:mysql://localhost:3306/rcsoft?useUnicode=true&characterEncoding=GBK");
                ds.setUsername("root");
                ds.setPassword("125412");
                //
                ds4Rcsoft = ds;
            } else {
                ds = ds4Rcsoft;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ds;
    }
}
