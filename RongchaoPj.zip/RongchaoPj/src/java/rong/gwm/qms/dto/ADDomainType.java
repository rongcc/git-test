/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.qms.dto;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author ZhouRongChao
 */
@Table("AD_DomainType")
public class ADDomainType {

    @Column("AD1_ID")
    @Id
    private Integer ad1Id;
    @Column("AD1_ParentID")
    private Integer aD1ParentID;
    @Column("AD1_Code")
    private String aD1Code;
    @Column("AD1_Name")
    private String aD1Name;
    @Column("AD1_Remark")
    private String aD1Remark;
    @Column("AD1_OUID")
    private String ad1Ouid;

    /**
     * @return the ad1Id
     */
    public Integer getAd1Id() {
        return ad1Id;
    }

    /**
     * @param ad1Id the ad1Id to set
     */
    public void setAd1Id(Integer ad1Id) {
        this.ad1Id = ad1Id;
    }

    /**
     * @return the aD1ParentID
     */
    public Integer getaD1ParentID() {
        return aD1ParentID;
    }

    /**
     * @param aD1ParentID the aD1ParentID to set
     */
    public void setaD1ParentID(Integer aD1ParentID) {
        this.aD1ParentID = aD1ParentID;
    }

    /**
     * @return the aD1Code
     */
    public String getaD1Code() {
        return aD1Code;
    }

    /**
     * @param aD1Code the aD1Code to set
     */
    public void setaD1Code(String aD1Code) {
        this.aD1Code = aD1Code;
    }

    /**
     * @return the aD1Name
     */
    public String getaD1Name() {
        return aD1Name;
    }

    /**
     * @param aD1Name the aD1Name to set
     */
    public void setaD1Name(String aD1Name) {
        this.aD1Name = aD1Name;
    }

    /**
     * @return the aD1Remark
     */
    public String getaD1Remark() {
        return aD1Remark;
    }

    /**
     * @param aD1Remark the aD1Remark to set
     */
    public void setaD1Remark(String aD1Remark) {
        this.aD1Remark = aD1Remark;
    }

    /**
     * @return the ad1Ouid
     */
    public String getAd1Ouid() {
        return ad1Ouid;
    }

    /**
     * @param ad1Ouid the ad1Ouid to set
     */
    public void setAd1Ouid(String ad1Ouid) {
        this.ad1Ouid = ad1Ouid;
    }
}
