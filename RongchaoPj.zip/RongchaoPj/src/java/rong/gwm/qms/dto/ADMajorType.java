/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.qms.dto;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author ZhouRongChao
 */
@Table("AD_MajorType")
public class ADMajorType {

    @Column("AD2_ID")
    @Id
    private Integer ad2Id;
    @Column("AD2_Name")
    private String aD2Name;
    @Column("AD2_Code")
    private String aD2Code;
    @Column("AD2_Remark")
    private String aD2Remark;
    @Column("AD2_ParentID")
    private Integer aD2ParentID;
    @Column("AD2_ToolTips")
    private String aD2ToolTips;

    /**
     * @return the ad2Id
     */
    public Integer getAd2Id() {
        return ad2Id;
    }

    /**
     * @param ad2Id the ad2Id to set
     */
    public void setAd2Id(Integer ad2Id) {
        this.ad2Id = ad2Id;
    }

    /**
     * @return the aD2Name
     */
    public String getaD2Name() {
        return aD2Name;
    }

    /**
     * @param aD2Name the aD2Name to set
     */
    public void setaD2Name(String aD2Name) {
        this.aD2Name = aD2Name;
    }

    /**
     * @return the aD2Code
     */
    public String getaD2Code() {
        return aD2Code;
    }

    /**
     * @param aD2Code the aD2Code to set
     */
    public void setaD2Code(String aD2Code) {
        this.aD2Code = aD2Code;
    }

    /**
     * @return the aD2Remark
     */
    public String getaD2Remark() {
        return aD2Remark;
    }

    /**
     * @param aD2Remark the aD2Remark to set
     */
    public void setaD2Remark(String aD2Remark) {
        this.aD2Remark = aD2Remark;
    }

    /**
     * @return the aD2ParentID
     */
    public Integer getaD2ParentID() {
        return aD2ParentID;
    }

    /**
     * @param aD2ParentID the aD2ParentID to set
     */
    public void setaD2ParentID(Integer aD2ParentID) {
        this.aD2ParentID = aD2ParentID;
    }

    /**
     * @return the aD2ToolTips
     */
    public String getaD2ToolTips() {
        return aD2ToolTips;
    }

    /**
     * @param aD2ToolTips the aD2ToolTips to set
     */
    public void setaD2ToolTips(String aD2ToolTips) {
        this.aD2ToolTips = aD2ToolTips;
    }
}
