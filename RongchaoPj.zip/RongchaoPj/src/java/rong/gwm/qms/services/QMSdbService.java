/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.qms.services;

import org.apache.commons.dbcp.BasicDataSource;

/**
 *
 * @author ZhouRongChao
 */
public class QMSdbService {

    public int getData4AD_DomainType() {
        return 1;
    }

    public int getData4AD_MajorType() {
        return 1;
    }

    public int getData4UM_OrgUnit() {
        return 1;
    }

    /**
     * 获得sql server数据库的GWMQMS数据源，正式账号。
     * @return
     */
    public BasicDataSource getDataSource22() {
        BasicDataSource ds = null;
        try {
            ds = new BasicDataSource();
            ds.setDriverClassName("net.sourceforge.jtds.jdbc.Driver");
            ds.setUrl("jdbc:jtds:sqlserver://10.1.129.16:1433/QMS_MAIN");
            ds.setUsername("QA_USER1");
            ds.setPassword("G5K2W6U1C9");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ds;
    }

    /**
     * 获得MySQL与原QMS映射的gwmqms数据库。
     * @return
     */
    public BasicDataSource getDataSource4MySQLgwmqms() {
        BasicDataSource ds = null;
        try {
            ds = new BasicDataSource();
            ds.setDriverClassName("com.mysql.jdbc.Driver");
            ds.setUrl("jdbc:mysql://localhost:3306/gwmqms?useUnicode=true&characterEncoding=GBK");
            ds.setUsername("root");
            ds.setPassword("125412");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ds;
    }
}
