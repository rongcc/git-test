/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.drms.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author ZhouRongChao
 */
@Table("ppc_cite")
public class PpcCite implements java.io.Serializable {

    @Column("id")
    @Id
    private Integer id;
    @Column("ppc_id")
    private int ppcId;
    @Column("ppc_subject")
    private String ppcSubject;
    @Column("cite_date")
    private Date citeDate;
    @Column("cite_type")
    private String citeType;
    @Column("cite_order")
    private String citeOrder;

    /**
     * @return the id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return the ppcId
     */
    public int getPpcId() {
        return ppcId;
    }

    /**
     * @param ppcId the ppcId to set
     */
    public void setPpcId(int ppcId) {
        this.ppcId = ppcId;
    }

    /**
     * @return the ppcSubject
     */
    public String getPpcSubject() {
        return ppcSubject;
    }

    /**
     * @param ppcSubject the ppcSubject to set
     */
    public void setPpcSubject(String ppcSubject) {
        this.ppcSubject = ppcSubject;
    }

    /**
     * @return the citeDate
     */
    public Date getCiteDate() {
        return citeDate;
    }

    /**
     * @param citeDate the citeDate to set
     */
    public void setCiteDate(Date citeDate) {
        this.citeDate = citeDate;
    }

    /**
     * @return the citeType
     */
    public String getCiteType() {
        return citeType;
    }

    /**
     * @param citeType the citeType to set
     */
    public void setCiteType(String citeType) {
        this.citeType = citeType;
    }

    /**
     * @return the citeOrder
     */
    public String getCiteOrder() {
        return citeOrder;
    }

    /**
     * @param citeOrder the citeOrder to set
     */
    public void setCiteOrder(String citeOrder) {
        this.citeOrder = citeOrder;
    }
}
