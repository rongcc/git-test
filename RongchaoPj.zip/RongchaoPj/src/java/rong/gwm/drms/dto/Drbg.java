/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.drms.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Name;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("drbg")
public class Drbg {

    @Column("drbg_no")
    @Name
    private String drbgNo;
    @Column("pingshen_date")
    private Date pingshenDate;
    @Column("pingshen_room")
    private String pingshenRoom;
    @Column("zuzhang")
    private String zuzhang;
    @Column("fuzuzhang")
    private String fuzuzhang;
    @Column("drbg_code")
    private String drbgCode;
    @Column("miji")
    private String miji;
    @Column("product_name")
    private String productName;
    @Column("product_step")
    private String productStep;
    @Column("dr_project_name")
    private String drProjectName;
    @Column("design_org_unit")
    private String designOrgUnit;
    @Column("project_man")
    private String projectMan;
    @Column("dr_jibie")
    private String drJibie;
    @Column("zhuban_org_unit")
    private String zhubanOrgUnit;
    @Column("remark")
    private String remark;
    @Column("status")
    private int status;
    @Column("status_tj")
    private Boolean statusTj;
    @Column("pin_type")
    private String pinType;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;
    @Column("edit_date")
    private Date editDate;
    @Column("edit_name")
    private String editName;
    @Column("post_date")
    private Date postDate;
    @Column("post_name")
    private String postName;
    @Column("source_order")
    private String sourceOrder;
    @Column("tj_post")
    private String tjPost;
    @Column("tj_post2")
    private String tjPost2;
    @Column("zhuanyelx")
    private String zhuanyelx;
    @Column("ps_input")
    private String psInput;
    @Column("ps_aim")
    private String psAim;
    @Column("ps_description")
    private String psDescription;
    @Column("ps_verdict")
    private String psVerdict;

    /**
     * @return the drbgNo
     */
    public String getDrbgNo() {
        return drbgNo;
    }

    /**
     * @param drbgNo the drbgNo to set
     */
    public void setDrbgNo(String drbgNo) {
        this.drbgNo = drbgNo;
    }

    /**
     * @return the pingshenDate
     */
    public Date getPingshenDate() {
        return pingshenDate;
    }

    /**
     * @param pingshenDate the pingshenDate to set
     */
    public void setPingshenDate(Date pingshenDate) {
        this.pingshenDate = pingshenDate;
    }

    /**
     * @return the pingshenRoom
     */
    public String getPingshenRoom() {
        return pingshenRoom;
    }

    /**
     * @param pingshenRoom the pingshenRoom to set
     */
    public void setPingshenRoom(String pingshenRoom) {
        this.pingshenRoom = pingshenRoom;
    }

    /**
     * @return the zuzhang
     */
    public String getZuzhang() {
        return zuzhang;
    }

    /**
     * @param zuzhang the zuzhang to set
     */
    public void setZuzhang(String zuzhang) {
        this.zuzhang = zuzhang;
    }

    /**
     * @return the fuzuzhang
     */
    public String getFuzuzhang() {
        return fuzuzhang;
    }

    /**
     * @param fuzuzhang the fuzuzhang to set
     */
    public void setFuzuzhang(String fuzuzhang) {
        this.fuzuzhang = fuzuzhang;
    }

    /**
     * @return the drbgCode
     */
    public String getDrbgCode() {
        return drbgCode;
    }

    /**
     * @param drbgCode the drbgCode to set
     */
    public void setDrbgCode(String drbgCode) {
        this.drbgCode = drbgCode;
    }

    /**
     * @return the miji
     */
    public String getMiji() {
        return miji;
    }

    /**
     * @param miji the miji to set
     */
    public void setMiji(String miji) {
        this.miji = miji;
    }

    /**
     * @return the productName
     */
    public String getProductName() {
        return productName;
    }

    /**
     * @param productName the productName to set
     */
    public void setProductName(String productName) {
        this.productName = productName;
    }

    /**
     * @return the productStep
     */
    public String getProductStep() {
        return productStep;
    }

    /**
     * @param productStep the productStep to set
     */
    public void setProductStep(String productStep) {
        this.productStep = productStep;
    }

    /**
     * @return the drProjectName
     */
    public String getDrProjectName() {
        return drProjectName;
    }

    /**
     * @param drProjectName the drProjectName to set
     */
    public void setDrProjectName(String drProjectName) {
        this.drProjectName = drProjectName;
    }

    /**
     * @return the designOrgUnit
     */
    public String getDesignOrgUnit() {
        return designOrgUnit;
    }

    /**
     * @param designOrgUnit the designOrgUnit to set
     */
    public void setDesignOrgUnit(String designOrgUnit) {
        this.designOrgUnit = designOrgUnit;
    }

    /**
     * @return the projectMan
     */
    public String getProjectMan() {
        return projectMan;
    }

    /**
     * @param projectMan the projectMan to set
     */
    public void setProjectMan(String projectMan) {
        this.projectMan = projectMan;
    }

    /**
     * @return the drJibie
     */
    public String getDrJibie() {
        return drJibie;
    }

    /**
     * @param drJibie the drJibie to set
     */
    public void setDrJibie(String drJibie) {
        this.drJibie = drJibie;
    }

    /**
     * @return the zhubanOrgUnit
     */
    public String getZhubanOrgUnit() {
        return zhubanOrgUnit;
    }

    /**
     * @param zhubanOrgUnit the zhubanOrgUnit to set
     */
    public void setZhubanOrgUnit(String zhubanOrgUnit) {
        this.zhubanOrgUnit = zhubanOrgUnit;
    }

    /**
     * @return the remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * @param remark the remark to set
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the statusTj
     */
    public Boolean getStatusTj() {
        return statusTj;
    }

    /**
     * @param statusTj the statusTj to set
     */
    public void setStatusTj(Boolean statusTj) {
        this.statusTj = statusTj;
    }

    /**
     * @return the pinType
     */
    public String getPinType() {
        return pinType;
    }

    /**
     * @param pinType the pinType to set
     */
    public void setPinType(String pinType) {
        this.pinType = pinType;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    /**
     * @return the editDate
     */
    public Date getEditDate() {
        return editDate;
    }

    /**
     * @param editDate the editDate to set
     */
    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }

    /**
     * @return the editName
     */
    public String getEditName() {
        return editName;
    }

    /**
     * @param editName the editName to set
     */
    public void setEditName(String editName) {
        this.editName = editName;
    }

    /**
     * @return the postDate
     */
    public Date getPostDate() {
        return postDate;
    }

    /**
     * @param postDate the postDate to set
     */
    public void setPostDate(Date postDate) {
        this.postDate = postDate;
    }

    /**
     * @return the postName
     */
    public String getPostName() {
        return postName;
    }

    /**
     * @param postName the postName to set
     */
    public void setPostName(String postName) {
        this.postName = postName;
    }

    /**
     * @return the sourceOrder
     */
    public String getSourceOrder() {
        return sourceOrder;
    }

    /**
     * @param sourceOrder the sourceOrder to set
     */
    public void setSourceOrder(String sourceOrder) {
        this.sourceOrder = sourceOrder;
    }

    /**
     * @return the tjPost
     */
    public String getTjPost() {
        return tjPost;
    }

    /**
     * @param tjPost the tjPost to set
     */
    public void setTjPost(String tjPost) {
        this.tjPost = tjPost;
    }

    /**
     * @return the tjPost2
     */
    public String getTjPost2() {
        return tjPost2;
    }

    /**
     * @param tjPost2 the tjPost2 to set
     */
    public void setTjPost2(String tjPost2) {
        this.tjPost2 = tjPost2;
    }

    /**
     * @return the zhuanyelx
     */
    public String getZhuanyelx() {
        return zhuanyelx;
    }

    /**
     * @param zhuanyelx the zhuanyelx to set
     */
    public void setZhuanyelx(String zhuanyelx) {
        this.zhuanyelx = zhuanyelx;
    }

    /**
     * @return the psInput
     */
    public String getPsInput() {
        return psInput;
    }

    /**
     * @param psInput the psInput to set
     */
    public void setPsInput(String psInput) {
        this.psInput = psInput;
    }

    /**
     * @return the psAim
     */
    public String getPsAim() {
        return psAim;
    }

    /**
     * @param psAim the psAim to set
     */
    public void setPsAim(String psAim) {
        this.psAim = psAim;
    }

    /**
     * @return the psDescription
     */
    public String getPsDescription() {
        return psDescription;
    }

    /**
     * @param psDescription the psDescription to set
     */
    public void setPsDescription(String psDescription) {
        this.psDescription = psDescription;
    }

    /**
     * @return the psVerdict
     */
    public String getPsVerdict() {
        return psVerdict;
    }

    /**
     * @param psVerdict the psVerdict to set
     */
    public void setPsVerdict(String psVerdict) {
        this.psVerdict = psVerdict;
    }
}
