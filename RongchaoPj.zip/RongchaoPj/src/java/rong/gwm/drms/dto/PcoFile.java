/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.drms.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.PK;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("pco_file")
@PK({"itemNo", "orderNo"})
public class PcoFile {

    @Column("item_no")
    private int itemNo;
    @Column("order_no")
    private String orderNo;
    @Column("real_filename")
    private String realFilename;
    @Column("physical_filename")
    private String physicalFilename;
    @Column("file_path")
    private String filePath;
    @Column("upload_date")
    private Date uploadDate;
    @Column("upload_name")
    private String uploadName;

    /**
     * @return the itemNo
     */
    public int getItemNo() {
        return itemNo;
    }

    /**
     * @param itemNo the itemNo to set
     */
    public void setItemNo(int itemNo) {
        this.itemNo = itemNo;
    }

    /**
     * @return the orderNo
     */
    public String getOrderNo() {
        return orderNo;
    }

    /**
     * @param orderNo the orderNo to set
     */
    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    /**
     * @return the realFilename
     */
    public String getRealFilename() {
        return realFilename;
    }

    /**
     * @param realFilename the realFilename to set
     */
    public void setRealFilename(String realFilename) {
        this.realFilename = realFilename;
    }

    /**
     * @return the physicalFilename
     */
    public String getPhysicalFilename() {
        return physicalFilename;
    }

    /**
     * @param physicalFilename the physicalFilename to set
     */
    public void setPhysicalFilename(String physicalFilename) {
        this.physicalFilename = physicalFilename;
    }

    /**
     * @return the filePath
     */
    public String getFilePath() {
        return filePath;
    }

    /**
     * @param filePath the filePath to set
     */
    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    /**
     * @return the uploadDate
     */
    public Date getUploadDate() {
        return uploadDate;
    }

    /**
     * @param uploadDate the uploadDate to set
     */
    public void setUploadDate(Date uploadDate) {
        this.uploadDate = uploadDate;
    }

    /**
     * @return the uploadName
     */
    public String getUploadName() {
        return uploadName;
    }

    /**
     * @param uploadName the uploadName to set
     */
    public void setUploadName(String uploadName) {
        this.uploadName = uploadName;
    }
}
