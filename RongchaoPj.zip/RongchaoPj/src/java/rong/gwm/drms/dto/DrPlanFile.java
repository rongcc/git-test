package rong.gwm.drms.dto;
import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.PK;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author YuMeiYu
 */
@Table("dr_plan_file")
@PK({"itemNo", "planNo"})
public class DrPlanFile {


    @Column("item_no")
    private int itemNo;
    @Column("plan_no")
    private String planNo;
    @Column( "real_filename")
    private String realFilename;
    @Column( "physical_filename")
    private String physicalFilename;
    @Column( "file_path")
    private String filePath;
    @Column( "upload_time")
    private Date uploadTime;
    @Column( "upload_name")
    private String uploadName;

    /**
     * @return the itemNo
     */
    public int getItemNo() {
        return itemNo;
    }

    /**
     * @param itemNo the itemNo to set
     */
    public void setItemNo(int itemNo) {
        this.itemNo = itemNo;
    }

    /**
     * @return the planNo
     */
    public String getPlanNo() {
        return planNo;
    }

    /**
     * @param planNo the planNo to set
     */
    public void setPlanNo(String planNo) {
        this.planNo = planNo;
    }

    /**
     * @return the realFilename
     */
    public String getRealFilename() {
        return realFilename;
    }

    /**
     * @param realFilename the realFilename to set
     */
    public void setRealFilename(String realFilename) {
        this.realFilename = realFilename;
    }

    /**
     * @return the physicalFilename
     */
    public String getPhysicalFilename() {
        return physicalFilename;
    }

    /**
     * @param physicalFilename the physicalFilename to set
     */
    public void setPhysicalFilename(String physicalFilename) {
        this.physicalFilename = physicalFilename;
    }

    /**
     * @return the filePath
     */
    public String getFilePath() {
        return filePath;
    }

    /**
     * @param filePath the filePath to set
     */
    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    /**
     * @return the uploadTime
     */
    public Date getUploadTime() {
        return uploadTime;
    }

    /**
     * @param uploadTime the uploadTime to set
     */
    public void setUploadTime(Date uploadTime) {
        this.uploadTime = uploadTime;
    }

    /**
     * @return the uploadName
     */
    public String getUploadName() {
        return uploadName;
    }

    /**
     * @param uploadName the uploadName to set
     */
    public void setUploadName(String uploadName) {
        this.uploadName = uploadName;
    }
}

