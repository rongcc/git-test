/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.drms.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author ZhouRongChao
 */
@Table("ppc")
public class PPC implements java.io.Serializable {

    @Column("id")
    @Id
    private Integer id;
    @Column("ppc_no")
    private String ppcNo;
    @Column("bname")
    private String bname;
    @Column("subject")
    private String subject;
    @Column("car_type")
    private String carType;
    @Column("lbj_zh")
    private String lbjZh;
    @Column("lbj_name")
    private String lbjName;
    @Column("lbj_bh")
    private String lbjBh;
    @Column("wtfs_dept")
    private String wtfsDept;
    @Column("xxpt_bh")
    private String xxptBh;
    @Column("file_path")
    private String filePath;
    @Column("physical_filename")
    private String physicalFilename;
    @Column("real_filename")
    private String realFilename;
    @Column("upload_time")
    private Date uploadTime;
    @Column("remark")
    private String remark;
    @Column("status")
    private int status;
    @Column("status_tj")
    private Boolean statusTj;
    @Column("pin_type")
    private String pinType;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;
    @Column("edit_date")
    private Date editDate;
    @Column("edit_name")
    private String editName;
    @Column("post_date")
    private Date postDate;
    @Column("post_name")
    private String postName;
    @Column("tj_post")
    private String tjPost;
    @Column("tj_post2")
    private String tjPost2;
    @Column("gongyi")
    private String gongyi;

    /**
     * @return the id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return the ppcNo
     */
    public String getPpcNo() {
        return ppcNo;
    }

    /**
     * @param ppcNo the ppcNo to set
     */
    public void setPpcNo(String ppcNo) {
        this.ppcNo = ppcNo;
    }

    /**
     * @return the bname
     */
    public String getBname() {
        return bname;
    }

    /**
     * @param bname the bname to set
     */
    public void setBname(String bname) {
        this.bname = bname;
    }

    /**
     * @return the subject
     */
    public String getSubject() {
        return subject;
    }

    /**
     * @param subject the subject to set
     */
    public void setSubject(String subject) {
        this.subject = subject;
    }

    /**
     * @return the carType
     */
    public String getCarType() {
        return carType;
    }

    /**
     * @param carType the carType to set
     */
    public void setCarType(String carType) {
        this.carType = carType;
    }

    /**
     * @return the lbjZh
     */
    public String getLbjZh() {
        return lbjZh;
    }

    /**
     * @param lbjZh the lbjZh to set
     */
    public void setLbjZh(String lbjZh) {
        this.lbjZh = lbjZh;
    }

    /**
     * @return the lbjName
     */
    public String getLbjName() {
        return lbjName;
    }

    /**
     * @param lbjName the lbjName to set
     */
    public void setLbjName(String lbjName) {
        this.lbjName = lbjName;
    }

    /**
     * @return the lbjBh
     */
    public String getLbjBh() {
        return lbjBh;
    }

    /**
     * @param lbjBh the lbjBh to set
     */
    public void setLbjBh(String lbjBh) {
        this.lbjBh = lbjBh;
    }

    /**
     * @return the wtfsDept
     */
    public String getWtfsDept() {
        return wtfsDept;
    }

    /**
     * @param wtfsDept the wtfsDept to set
     */
    public void setWtfsDept(String wtfsDept) {
        this.wtfsDept = wtfsDept;
    }

    /**
     * @return the xxptBh
     */
    public String getXxptBh() {
        return xxptBh;
    }

    /**
     * @param xxptBh the xxptBh to set
     */
    public void setXxptBh(String xxptBh) {
        this.xxptBh = xxptBh;
    }

    /**
     * @return the filePath
     */
    public String getFilePath() {
        return filePath;
    }

    /**
     * @param filePath the filePath to set
     */
    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    /**
     * @return the physicalFilename
     */
    public String getPhysicalFilename() {
        return physicalFilename;
    }

    /**
     * @param physicalFilename the physicalFilename to set
     */
    public void setPhysicalFilename(String physicalFilename) {
        this.physicalFilename = physicalFilename;
    }

    /**
     * @return the realFilename
     */
    public String getRealFilename() {
        return realFilename;
    }

    /**
     * @param realFilename the realFilename to set
     */
    public void setRealFilename(String realFilename) {
        this.realFilename = realFilename;
    }

    /**
     * @return the uploadTime
     */
    public Date getUploadTime() {
        return uploadTime;
    }

    /**
     * @param uploadTime the uploadTime to set
     */
    public void setUploadTime(Date uploadTime) {
        this.uploadTime = uploadTime;
    }

    /**
     * @return the remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * @param remark the remark to set
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the statusTj
     */
    public Boolean getStatusTj() {
        return statusTj;
    }

    /**
     * @param statusTj the statusTj to set
     */
    public void setStatusTj(Boolean statusTj) {
        this.statusTj = statusTj;
    }

    /**
     * @return the pinType
     */
    public String getPinType() {
        return pinType;
    }

    /**
     * @param pinType the pinType to set
     */
    public void setPinType(String pinType) {
        this.pinType = pinType;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    /**
     * @return the editDate
     */
    public Date getEditDate() {
        return editDate;
    }

    /**
     * @param editDate the editDate to set
     */
    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }

    /**
     * @return the editName
     */
    public String getEditName() {
        return editName;
    }

    /**
     * @param editName the editName to set
     */
    public void setEditName(String editName) {
        this.editName = editName;
    }

    /**
     * @return the postDate
     */
    public Date getPostDate() {
        return postDate;
    }

    /**
     * @param postDate the postDate to set
     */
    public void setPostDate(Date postDate) {
        this.postDate = postDate;
    }

    /**
     * @return the postName
     */
    public String getPostName() {
        return postName;
    }

    /**
     * @param postName the postName to set
     */
    public void setPostName(String postName) {
        this.postName = postName;
    }

    /**
     * @return the tjPost
     */
    public String getTjPost() {
        return tjPost;
    }

    /**
     * @param tjPost the tjPost to set
     */
    public void setTjPost(String tjPost) {
        this.tjPost = tjPost;
    }

    /**
     * @return the tjPost2
     */
    public String getTjPost2() {
        return tjPost2;
    }

    /**
     * @param tjPost2 the tjPost2 to set
     */
    public void setTjPost2(String tjPost2) {
        this.tjPost2 = tjPost2;
    }

    /**
     * @return the gongyi
     */
    public String getGongyi() {
        return gongyi;
    }

    /**
     * @param gongyi the gongyi to set
     */
    public void setGongyi(String gongyi) {
        this.gongyi = gongyi;
    }
}
