/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.drms.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author yumeiyu
 */
@Table("wenti_project")

public class WentiProject {

    @Column("project_no")
    @Id
    private Integer projectNo;
    @Column("project_name")
    private String projectName;
    @Column("description")
    private String description;
    @Column("name2")
    private String name2;
    @Column("project_code")
    private String projectCode;
    @Column("sch_start_date")
    private Date schStartDate;
    @Column("sch_end_date")
    private Date schEndDate;
    @Column("act_start_date")
    private Date actStartDate;
    @Column("act_end_date")
    private Date actEndDate;
    @Column("finished")
    private boolean finished;
    @Column("man")
    private String man;
    @Column("pin_type")
    private String pinType;
    @Column("type")
    private String type;
    @Column("status")
    private short status;
    @Column("remark")
    private String remark;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;
    @Column("edit_date")
    private Date editDate;
    @Column("edit_name")
    private String editName;
    @Column("post_date")
    private Date postDate;
    @Column("post_name")
    private String postName;
    @Column("post2_date")
    private Date post2Date;
    @Column("post2_name")
    private String post2Name;
    @Column("sch_time_limit")
    private Double schTimeLimit;
    @Column("act_time_limit")
    private Double actTimeLimit;
    @Column("time_limit_units")
    private String timeLimitUnits;
    @Column("wenti_no")
    private String wentiNo;
    @Column("wenti_dc")
    private String wentiDc;
    @Column("jindu_status")
    private String jinduStatus;
    @Column("jindu_affirm_man")
    private String jinduAffirmMan;

    /**
     * @return the projectNo
     */
    public Integer getProjectNo() {
        return projectNo;
    }

    /**
     * @param projectNo the projectNo to set
     */
    public void setProjectNo(Integer projectNo) {
        this.projectNo = projectNo;
    }

    /**
     * @return the projectName
     */
    public String getProjectName() {
        return projectName;
    }

    /**
     * @param projectName the projectName to set
     */
    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the name2
     */
    public String getName2() {
        return name2;
    }

    /**
     * @param name2 the name2 to set
     */
    public void setName2(String name2) {
        this.name2 = name2;
    }

    /**
     * @return the projectCode
     */
    public String getProjectCode() {
        return projectCode;
    }

    /**
     * @param projectCode the projectCode to set
     */
    public void setProjectCode(String projectCode) {
        this.projectCode = projectCode;
    }

    /**
     * @return the schStartDate
     */
    public Date getSchStartDate() {
        return schStartDate;
    }

    /**
     * @param schStartDate the schStartDate to set
     */
    public void setSchStartDate(Date schStartDate) {
        this.schStartDate = schStartDate;
    }

    /**
     * @return the schEndDate
     */
    public Date getSchEndDate() {
        return schEndDate;
    }

    /**
     * @param schEndDate the schEndDate to set
     */
    public void setSchEndDate(Date schEndDate) {
        this.schEndDate = schEndDate;
    }

    /**
     * @return the actStartDate
     */
    public Date getActStartDate() {
        return actStartDate;
    }

    /**
     * @param actStartDate the actStartDate to set
     */
    public void setActStartDate(Date actStartDate) {
        this.actStartDate = actStartDate;
    }

    /**
     * @return the actEndDate
     */
    public Date getActEndDate() {
        return actEndDate;
    }

    /**
     * @param actEndDate the actEndDate to set
     */
    public void setActEndDate(Date actEndDate) {
        this.actEndDate = actEndDate;
    }

    /**
     * @return the finished
     */
    public boolean isFinished() {
        return finished;
    }

    /**
     * @param finished the finished to set
     */
    public void setFinished(boolean finished) {
        this.finished = finished;
    }

    /**
     * @return the man
     */
    public String getMan() {
        return man;
    }

    /**
     * @param man the man to set
     */
    public void setMan(String man) {
        this.man = man;
    }

    /**
     * @return the pinType
     */
    public String getPinType() {
        return pinType;
    }

    /**
     * @param pinType the pinType to set
     */
    public void setPinType(String pinType) {
        this.pinType = pinType;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return the status
     */
    public short getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(short status) {
        this.status = status;
    }

    /**
     * @return the remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * @param remark the remark to set
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    /**
     * @return the editDate
     */
    public Date getEditDate() {
        return editDate;
    }

    /**
     * @param editDate the editDate to set
     */
    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }

    /**
     * @return the editName
     */
    public String getEditName() {
        return editName;
    }

    /**
     * @param editName the editName to set
     */
    public void setEditName(String editName) {
        this.editName = editName;
    }

    /**
     * @return the postDate
     */
    public Date getPostDate() {
        return postDate;
    }

    /**
     * @param postDate the postDate to set
     */
    public void setPostDate(Date postDate) {
        this.postDate = postDate;
    }

    /**
     * @return the postName
     */
    public String getPostName() {
        return postName;
    }

    /**
     * @param postName the postName to set
     */
    public void setPostName(String postName) {
        this.postName = postName;
    }

    /**
     * @return the post2Date
     */
    public Date getPost2Date() {
        return post2Date;
    }

    /**
     * @param post2Date the post2Date to set
     */
    public void setPost2Date(Date post2Date) {
        this.post2Date = post2Date;
    }

    /**
     * @return the post2Name
     */
    public String getPost2Name() {
        return post2Name;
    }

    /**
     * @param post2Name the post2Name to set
     */
    public void setPost2Name(String post2Name) {
        this.post2Name = post2Name;
    }

    /**
     * @return the schTimeLimit
     */
    public Double getSchTimeLimit() {
        return schTimeLimit;
    }

    /**
     * @param schTimeLimit the schTimeLimit to set
     */
    public void setSchTimeLimit(Double schTimeLimit) {
        this.schTimeLimit = schTimeLimit;
    }

    /**
     * @return the actTimeLimit
     */
    public Double getActTimeLimit() {
        return actTimeLimit;
    }

    /**
     * @param actTimeLimit the actTimeLimit to set
     */
    public void setActTimeLimit(Double actTimeLimit) {
        this.actTimeLimit = actTimeLimit;
    }

    /**
     * @return the timeLimitUnits
     */
    public String getTimeLimitUnits() {
        return timeLimitUnits;
    }

    /**
     * @param timeLimitUnits the timeLimitUnits to set
     */
    public void setTimeLimitUnits(String timeLimitUnits) {
        this.timeLimitUnits = timeLimitUnits;
    }

    /**
     * @return the wentiNo
     */
    public String getWentiNo() {
        return wentiNo;
    }

    /**
     * @param wentiNo the wentiNo to set
     */
    public void setWentiNo(String wentiNo) {
        this.wentiNo = wentiNo;
    }

    /**
     * @return the wentiDc
     */
    public String getWentiDc() {
        return wentiDc;
    }

    /**
     * @param wentiDc the wentiDc to set
     */
    public void setWentiDc(String wentiDc) {
        this.wentiDc = wentiDc;
    }

    /**
     * @return the jinduStatus
     */
    public String getJinduStatus() {
        return jinduStatus;
    }

    /**
     * @param jinduStatus the jinduStatus to set
     */
    public void setJinduStatus(String jinduStatus) {
        this.jinduStatus = jinduStatus;
    }

    /**
     * @return the jinduAffirmMan
     */
    public String getJinduAffirmMan() {
        return jinduAffirmMan;
    }

    /**
     * @param jinduAffirmMan the jinduAffirmMan to set
     */
    public void setJinduAffirmMan(String jinduAffirmMan) {
        this.jinduAffirmMan = jinduAffirmMan;
    }
}

 