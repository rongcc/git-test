/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.drms.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author ZhouRongChao
 */
@Table("bangzhu_file")
public class BangzhuFile {

    @Column("id")
    @Id
    private Integer id;
    @Column("name")
    private String name;
    @Column("description")
    private String description;
    @Column("status")
    private int status;
    @Column("physical_filename")
    private String physicalFilename;
    @Column("real_filename")
    private String realFilename;
    @Column("file_path")
    private String filePath;
    @Column("upload_time")
    private Date uploadTime;
    @Column("upload_name")
    private String uploadName;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;

    /**
     * @return the id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the physicalFilename
     */
    public String getPhysicalFilename() {
        return physicalFilename;
    }

    /**
     * @param physicalFilename the physicalFilename to set
     */
    public void setPhysicalFilename(String physicalFilename) {
        this.physicalFilename = physicalFilename;
    }

    /**
     * @return the realFilename
     */
    public String getRealFilename() {
        return realFilename;
    }

    /**
     * @param realFilename the realFilename to set
     */
    public void setRealFilename(String realFilename) {
        this.realFilename = realFilename;
    }

    /**
     * @return the filePath
     */
    public String getFilePath() {
        return filePath;
    }

    /**
     * @param filePath the filePath to set
     */
    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    /**
     * @return the uploadTime
     */
    public Date getUploadTime() {
        return uploadTime;
    }

    /**
     * @param uploadTime the uploadTime to set
     */
    public void setUploadTime(Date uploadTime) {
        this.uploadTime = uploadTime;
    }

    /**
     * @return the uploadName
     */
    public String getUploadName() {
        return uploadName;
    }

    /**
     * @param uploadName the uploadName to set
     */
    public void setUploadName(String uploadName) {
        this.uploadName = uploadName;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }
}
