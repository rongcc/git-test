/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.drms.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("drbg_post")
public class DrbgPost {

    @Column("id")
    @Id
    private Integer id;
    @Column("order_no")
    private String orderNo;
    @Column("post_type")
    private String postType;
    @Column("posted")
    private boolean posted;
    @Column("postil")
    private String postil;
    @Column("post_date")
    private Date postDate;
    @Column("post_name")
    private String postName;

    /**
     * @return the id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return the orderNo
     */
    public String getOrderNo() {
        return orderNo;
    }

    /**
     * @param orderNo the orderNo to set
     */
    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    /**
     * @return the postType
     */
    public String getPostType() {
        return postType;
    }

    /**
     * @param postType the postType to set
     */
    public void setPostType(String postType) {
        this.postType = postType;
    }

    /**
     * @return the posted
     */
    public boolean isPosted() {
        return posted;
    }

    /**
     * @param posted the posted to set
     */
    public void setPosted(boolean posted) {
        this.posted = posted;
    }

    /**
     * @return the postil
     */
    public String getPostil() {
        return postil;
    }

    /**
     * @param postil the postil to set
     */
    public void setPostil(String postil) {
        this.postil = postil;
    }

    /**
     * @return the postDate
     */
    public Date getPostDate() {
        return postDate;
    }

    /**
     * @param postDate the postDate to set
     */
    public void setPostDate(Date postDate) {
        this.postDate = postDate;
    }

    /**
     * @return the postName
     */
    public String getPostName() {
        return postName;
    }

    /**
     * @param postName the postName to set
     */
    public void setPostName(String postName) {
        this.postName = postName;
    }
}
