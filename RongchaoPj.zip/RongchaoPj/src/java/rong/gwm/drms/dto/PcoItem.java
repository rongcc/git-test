/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.drms.dto;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.PK;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author zhourongchao
 */
@Table("pco_item")
@PK({"itemNo", "orderNo"})
public class PcoItem {

    @Column("item_no")
    private int itemNo;
    @Column("order_no")
    private String orderNo;
    @Column("attribute1")
    private String attribute1;
    @Column("attribute2")
    private String attribute2;
    @Column("attribute3")
    private String attribute3;
    @Column("attribute4")
    private String attribute4;
    @Column("attribute5")
    private String attribute5;

    /**
     * @return the itemNo
     */
    public int getItemNo() {
        return itemNo;
    }

    /**
     * @param itemNo the itemNo to set
     */
    public void setItemNo(int itemNo) {
        this.itemNo = itemNo;
    }

    /**
     * @return the orderNo
     */
    public String getOrderNo() {
        return orderNo;
    }

    /**
     * @param orderNo the orderNo to set
     */
    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    /**
     * @return the attribute1
     */
    public String getAttribute1() {
        return attribute1;
    }

    /**
     * @param attribute1 the attribute1 to set
     */
    public void setAttribute1(String attribute1) {
        this.attribute1 = attribute1;
    }

    /**
     * @return the attribute2
     */
    public String getAttribute2() {
        return attribute2;
    }

    /**
     * @param attribute2 the attribute2 to set
     */
    public void setAttribute2(String attribute2) {
        this.attribute2 = attribute2;
    }

    /**
     * @return the attribute3
     */
    public String getAttribute3() {
        return attribute3;
    }

    /**
     * @param attribute3 the attribute3 to set
     */
    public void setAttribute3(String attribute3) {
        this.attribute3 = attribute3;
    }

    /**
     * @return the attribute4
     */
    public String getAttribute4() {
        return attribute4;
    }

    /**
     * @param attribute4 the attribute4 to set
     */
    public void setAttribute4(String attribute4) {
        this.attribute4 = attribute4;
    }

    /**
     * @return the attribute5
     */
    public String getAttribute5() {
        return attribute5;
    }

    /**
     * @param attribute5 the attribute5 to set
     */
    public void setAttribute5(String attribute5) {
        this.attribute5 = attribute5;
    }
}
