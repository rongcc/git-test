/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.drms.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Name;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author ZhouRongChao
 */
@Table("wenti")
public class Wenti {

    @Column("we_no")
    @Name
    private String weNo;
    @Column("we_description")
    private String weDescription;
    @Column("cuoshi_jianyi")
    private String cuoshiJianyi;
    @Column("we_name")
    private String weName;
    @Column("tichu_date")
    private Date tichuDate;
    @Column("tichu_name")
    private String tichuName;
    @Column("we_type")
    private String weType;
    @Column("src_type")
    private String srcType;
    @Column("src_order_no")
    private String srcOrderNo;
    @Column("need_reply_date")
    private Date needReplyDate;
    @Column("remark")
    private String remark;
    @Column("status")
    private int status;
    @Column("status_tj")
    private Boolean statusTj;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;
    @Column("edit_date")
    private Date editDate;
    @Column("edit_name")
    private String editName;
    @Column("post_date")
    private Date postDate;
    @Column("post_name")
    private String postName;
    @Column("expert_id")
    private int expertId;
    @Column("zhuanyelx")
    private String zhuanyelx;
    @Column("accepted")
    private Boolean accepted;
    @Column("issue_status")
    private String issueStatus;
    @Column("major_man")
    private String majorMan;
    @Column("finish_date")
    private Date finishDate;
    @Column("item_no")
    private int itemNo;
    @Column("duice")
    private String duice;

    /**
     * @return the weNo
     */
    public String getWeNo() {
        return weNo;
    }

    /**
     * @param weNo the weNo to set
     */
    public void setWeNo(String weNo) {
        this.weNo = weNo;
    }

    /**
     * @return the weDescription
     */
    public String getWeDescription() {
        return weDescription;
    }

    /**
     * @param weDescription the weDescription to set
     */
    public void setWeDescription(String weDescription) {
        this.weDescription = weDescription;
    }

    /**
     * @return the cuoshiJianyi
     */
    public String getCuoshiJianyi() {
        return cuoshiJianyi;
    }

    /**
     * @param cuoshiJianyi the cuoshiJianyi to set
     */
    public void setCuoshiJianyi(String cuoshiJianyi) {
        this.cuoshiJianyi = cuoshiJianyi;
    }

    /**
     * @return the weName
     */
    public String getWeName() {
        return weName;
    }

    /**
     * @param weName the weName to set
     */
    public void setWeName(String weName) {
        this.weName = weName;
    }

    /**
     * @return the tichuDate
     */
    public Date getTichuDate() {
        return tichuDate;
    }

    /**
     * @param tichuDate the tichuDate to set
     */
    public void setTichuDate(Date tichuDate) {
        this.tichuDate = tichuDate;
    }

    /**
     * @return the tichuName
     */
    public String getTichuName() {
        return tichuName;
    }

    /**
     * @param tichuName the tichuName to set
     */
    public void setTichuName(String tichuName) {
        this.tichuName = tichuName;
    }

    /**
     * @return the weType
     */
    public String getWeType() {
        return weType;
    }

    /**
     * @param weType the weType to set
     */
    public void setWeType(String weType) {
        this.weType = weType;
    }

    /**
     * @return the srcType
     */
    public String getSrcType() {
        return srcType;
    }

    /**
     * @param srcType the srcType to set
     */
    public void setSrcType(String srcType) {
        this.srcType = srcType;
    }

    /**
     * @return the srcOrderNo
     */
    public String getSrcOrderNo() {
        return srcOrderNo;
    }

    /**
     * @param srcOrderNo the srcOrderNo to set
     */
    public void setSrcOrderNo(String srcOrderNo) {
        this.srcOrderNo = srcOrderNo;
    }

    /**
     * @return the needReplyDate
     */
    public Date getNeedReplyDate() {
        return needReplyDate;
    }

    /**
     * @param needReplyDate the needReplyDate to set
     */
    public void setNeedReplyDate(Date needReplyDate) {
        this.needReplyDate = needReplyDate;
    }

    /**
     * @return the remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * @param remark the remark to set
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the statusTj
     */
    public Boolean getStatusTj() {
        return statusTj;
    }

    /**
     * @param statusTj the statusTj to set
     */
    public void setStatusTj(Boolean statusTj) {
        this.statusTj = statusTj;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    /**
     * @return the editDate
     */
    public Date getEditDate() {
        return editDate;
    }

    /**
     * @param editDate the editDate to set
     */
    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }

    /**
     * @return the editName
     */
    public String getEditName() {
        return editName;
    }

    /**
     * @param editName the editName to set
     */
    public void setEditName(String editName) {
        this.editName = editName;
    }

    /**
     * @return the postDate
     */
    public Date getPostDate() {
        return postDate;
    }

    /**
     * @param postDate the postDate to set
     */
    public void setPostDate(Date postDate) {
        this.postDate = postDate;
    }

    /**
     * @return the postName
     */
    public String getPostName() {
        return postName;
    }

    /**
     * @param postName the postName to set
     */
    public void setPostName(String postName) {
        this.postName = postName;
    }

    /**
     * @return the expertId
     */
    public int getExpertId() {
        return expertId;
    }

    /**
     * @param expertId the expertId to set
     */
    public void setExpertId(int expertId) {
        this.expertId = expertId;
    }

    /**
     * @return the zhuanyelx
     */
    public String getZhuanyelx() {
        return zhuanyelx;
    }

    /**
     * @param zhuanyelx the zhuanyelx to set
     */
    public void setZhuanyelx(String zhuanyelx) {
        this.zhuanyelx = zhuanyelx;
    }

    /**
     * @return the issueStatus
     */
    public String getIssueStatus() {
        return issueStatus;
    }

    /**
     * @param issueStatus the issueStatus to set
     */
    public void setIssueStatus(String issueStatus) {
        this.issueStatus = issueStatus;
    }

    /**
     * @return the majorMan
     */
    public String getMajorMan() {
        return majorMan;
    }

    /**
     * @param majorMan the majorMan to set
     */
    public void setMajorMan(String majorMan) {
        this.majorMan = majorMan;
    }

    /**
     * @return the finishDate
     */
    public Date getFinishDate() {
        return finishDate;
    }

    /**
     * @param finishDate the finishDate to set
     */
    public void setFinishDate(Date finishDate) {
        this.finishDate = finishDate;
    }

    /**
     * @return the itemNo
     */
    public int getItemNo() {
        return itemNo;
    }

    /**
     * @param itemNo the itemNo to set
     */
    public void setItemNo(int itemNo) {
        this.itemNo = itemNo;
    }

    /**
     * @return the duice
     */
    public String getDuice() {
        return duice;
    }

    /**
     * @param duice the duice to set
     */
    public void setDuice(String duice) {
        this.duice = duice;
    }

    /**
     * @return the accepted
     */
    public Boolean getAccepted() {
        return accepted;
    }

    /**
     * @param accepted the accepted to set
     */
    public void setAccepted(Boolean accepted) {
        this.accepted = accepted;
    }
}
