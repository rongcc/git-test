/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.drms.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Name;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author ZhouRongChao
 */
@Table("dr_plan")
public class DrPlan {

    @Column("plan_no")
    @Name
    private String planNo;
    @Column("drsq_no")
    private String drsqNo;
    @Column("psxm_name")
    private String psxmName;
    @Column("pingshen_room")
    private String pingshenRoom;
    @Column("persons")
    private String persons;
    @Column("start_time")
    private Date startTime;
    @Column("end_time")
    private Date endTime;
    @Column("remark")
    private String remark;
    @Column("status")
    private int status;
    @Column("status_tj")
    private Boolean statusTj;
    @Column("pin_type")
    private String pinType;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;
    @Column("edit_date")
    private Date editDate;
    @Column("edit_name")
    private String editName;
    @Column("post_date")
    private Date postDate;
    @Column("post_name")
    private String postName;

    /**
     * @return the planNo
     */
    public String getPlanNo() {
        return planNo;
    }

    /**
     * @param planNo the planNo to set
     */
    public void setPlanNo(String planNo) {
        this.planNo = planNo;
    }

    /**
     * @return the drsqNo
     */
    public String getDrsqNo() {
        return drsqNo;
    }

    /**
     * @param drsqNo the drsqNo to set
     */
    public void setDrsqNo(String drsqNo) {
        this.drsqNo = drsqNo;
    }

    /**
     * @return the psxmName
     */
    public String getPsxmName() {
        return psxmName;
    }

    /**
     * @param psxmName the psxmName to set
     */
    public void setPsxmName(String psxmName) {
        this.psxmName = psxmName;
    }

    /**
     * @return the pingshenRoom
     */
    public String getPingshenRoom() {
        return pingshenRoom;
    }

    /**
     * @param pingshenRoom the pingshenRoom to set
     */
    public void setPingshenRoom(String pingshenRoom) {
        this.pingshenRoom = pingshenRoom;
    }

    /**
     * @return the persons
     */
    public String getPersons() {
        return persons;
    }

    /**
     * @param persons the persons to set
     */
    public void setPersons(String persons) {
        this.persons = persons;
    }

    /**
     * @return the startTime
     */
    public Date getStartTime() {
        return startTime;
    }

    /**
     * @param startTime the startTime to set
     */
    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    /**
     * @return the endTime
     */
    public Date getEndTime() {
        return endTime;
    }

    /**
     * @param endTime the endTime to set
     */
    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    /**
     * @return the remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * @param remark the remark to set
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the statusTj
     */
    public Boolean getStatusTj() {
        return statusTj;
    }

    /**
     * @param statusTj the statusTj to set
     */
    public void setStatusTj(Boolean statusTj) {
        this.statusTj = statusTj;
    }

    /**
     * @return the pinType
     */
    public String getPinType() {
        return pinType;
    }

    /**
     * @param pinType the pinType to set
     */
    public void setPinType(String pinType) {
        this.pinType = pinType;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    /**
     * @return the editDate
     */
    public Date getEditDate() {
        return editDate;
    }

    /**
     * @param editDate the editDate to set
     */
    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }

    /**
     * @return the editName
     */
    public String getEditName() {
        return editName;
    }

    /**
     * @param editName the editName to set
     */
    public void setEditName(String editName) {
        this.editName = editName;
    }

    /**
     * @return the postDate
     */
    public Date getPostDate() {
        return postDate;
    }

    /**
     * @param postDate the postDate to set
     */
    public void setPostDate(Date postDate) {
        this.postDate = postDate;
    }

    /**
     * @return the postName
     */
    public String getPostName() {
        return postName;
    }

    /**
     * @param postName the postName to set
     */
    public void setPostName(String postName) {
        this.postName = postName;
    }
}
