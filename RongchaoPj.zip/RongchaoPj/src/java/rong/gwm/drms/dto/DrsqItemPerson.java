/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.drms.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.PK;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author YuMeiYu
 */
@Table("drsq_item_person")
@PK({"itemNo", "drsqNo"})
public class DrsqItemPerson implements java.io.Serializable {

    @Column("item_no")
    private int itemNo;
    @Column("drsq_no")
    private String drsqNo;
    @Column("name")
    private String name;
    @Column("expert_id")
    private Integer expertId;
    @Column("username")
    private String username;
    @Column("src_type")
    private String srcType;
    @Column("dr_position")
    private String drPosition;

    /**
     * @return the itemNo
     */
    public int getItemNo() {
        return itemNo;
    }

    /**
     * @param itemNo the itemNo to set
     */
    public void setItemNo(int itemNo) {
        this.itemNo = itemNo;
    }

    /**
     * @return the drsqNo
     */
    public String getDrsqNo() {
        return drsqNo;
    }

    /**
     * @param drsqNo the drsqNo to set
     */
    public void setDrsqNo(String drsqNo) {
        this.drsqNo = drsqNo;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the expertId
     */
    public Integer getExpertId() {
        return expertId;
    }

    /**
     * @param expertId the expertId to set
     */
    public void setExpertId(Integer expertId) {
        this.expertId = expertId;
    }

    /**
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username the username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * @return the srcType
     */
    public String getSrcType() {
        return srcType;
    }

    /**
     * @param srcType the srcType to set
     */
    public void setSrcType(String srcType) {
        this.srcType = srcType;
    }

    /**
     * @return the drPosition
     */
    public String getDrPosition() {
        return drPosition;
    }

    /**
     * @param drPosition the drPosition to set
     */
    public void setDrPosition(String drPosition) {
        this.drPosition = drPosition;
    }
}
