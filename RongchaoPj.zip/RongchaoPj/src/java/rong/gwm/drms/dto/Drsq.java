/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.drms.dto;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Name;
import org.nutz.dao.entity.annotation.Table;

/**
 *
 * @author YuMeiYu
 */
@Table("drsq")
public class Drsq implements java.io.Serializable {

    @Column("drsq_no")
    @Name
    private String drsqNo;
    @Column("psxm_name")
    private String psxmName;
    @Column("ss_project")
    private String ssProject;
    @Column("ss_org")
    private String ssOrg;
    @Column("lbj_type")
    private String lbjType;
    @Column("sz_system")
    private String szSystem;
    @Column("sz_group")
    private String szGroup;
    @Column("sz_son_group")
    private String szSonGroup;
    @Column("sz_yfjd")
    private String szYfjd;
    @Column("sq_date")
    private Date sqDate;
    @Column("ps_sugdate")
    private Date psSugdate;
    @Column("ps_jb")
    private String psJb;
    @Column("ps_zbdw")
    private String psZbdw;
    @Column("ps_zbdw_name")
    private String psZbdwName;
    @Column("sq_reason")
    private String sqReason;
    @Column("dr_attach")
    private String drAttach;
    @Column("project_man")
    private String projectMan;
    @Column("remark")
    private String remark;
    @Column("status")
    private int status;
    @Column("status_tj")
    private Boolean statusTj;
    @Column("pin_type")
    private String pinType;
    @Column("input_date")
    private Date inputDate;
    @Column("input_name")
    private String inputName;
    @Column("edit_date")
    private Date editDate;
    @Column("edit_name")
    private String editName;
    @Column("jianyi_dept")
    private String jianyiDept;
    @Column("post_date")
    private Date postDate;
    @Column("post_name")
    private String postName;
    @Column("tj_post")
    private String tjPost;
    @Column("tj_post2")
    private String tjPost2;
    @Column("zhuanyelx")
    private String zhuanyelx;

    /**
     * @return the drsqNo
     */
    public String getDrsqNo() {
        return drsqNo;
    }

    /**
     * @param drsqNo the drsqNo to set
     */
    public void setDrsqNo(String drsqNo) {
        this.drsqNo = drsqNo;
    }

    /**
     * @return the psxmName
     */
    public String getPsxmName() {
        return psxmName;
    }

    /**
     * @param psxmName the psxmName to set
     */
    public void setPsxmName(String psxmName) {
        this.psxmName = psxmName;
    }

    /**
     * @return the ssProject
     */
    public String getSsProject() {
        return ssProject;
    }

    /**
     * @param ssProject the ssProject to set
     */
    public void setSsProject(String ssProject) {
        this.ssProject = ssProject;
    }

    /**
     * @return the ssOrg
     */
    public String getSsOrg() {
        return ssOrg;
    }

    /**
     * @param ssOrg the ssOrg to set
     */
    public void setSsOrg(String ssOrg) {
        this.ssOrg = ssOrg;
    }

    /**
     * @return the lbjType
     */
    public String getLbjType() {
        return lbjType;
    }

    /**
     * @param lbjType the lbjType to set
     */
    public void setLbjType(String lbjType) {
        this.lbjType = lbjType;
    }

    /**
     * @return the szSystem
     */
    public String getSzSystem() {
        return szSystem;
    }

    /**
     * @param szSystem the szSystem to set
     */
    public void setSzSystem(String szSystem) {
        this.szSystem = szSystem;
    }

    /**
     * @return the szGroup
     */
    public String getSzGroup() {
        return szGroup;
    }

    /**
     * @param szGroup the szGroup to set
     */
    public void setSzGroup(String szGroup) {
        this.szGroup = szGroup;
    }

    /**
     * @return the szSonGroup
     */
    public String getSzSonGroup() {
        return szSonGroup;
    }

    /**
     * @param szSonGroup the szSonGroup to set
     */
    public void setSzSonGroup(String szSonGroup) {
        this.szSonGroup = szSonGroup;
    }

    /**
     * @return the szYfjd
     */
    public String getSzYfjd() {
        return szYfjd;
    }

    /**
     * @param szYfjd the szYfjd to set
     */
    public void setSzYfjd(String szYfjd) {
        this.szYfjd = szYfjd;
    }

    /**
     * @return the sqDate
     */
    public Date getSqDate() {
        return sqDate;
    }

    /**
     * @param sqDate the sqDate to set
     */
    public void setSqDate(Date sqDate) {
        this.sqDate = sqDate;
    }

    /**
     * @return the psSugdate
     */
    public Date getPsSugdate() {
        return psSugdate;
    }

    /**
     * @param psSugdate the psSugdate to set
     */
    public void setPsSugdate(Date psSugdate) {
        this.psSugdate = psSugdate;
    }

    /**
     * @return the psJb
     */
    public String getPsJb() {
        return psJb;
    }

    /**
     * @param psJb the psJb to set
     */
    public void setPsJb(String psJb) {
        this.psJb = psJb;
    }

    /**
     * @return the psZbdw
     */
    public String getPsZbdw() {
        return psZbdw;
    }

    /**
     * @param psZbdw the psZbdw to set
     */
    public void setPsZbdw(String psZbdw) {
        this.psZbdw = psZbdw;
    }

    /**
     * @return the psZbdwName
     */
    public String getPsZbdwName() {
        return psZbdwName;
    }

    /**
     * @param psZbdwName the psZbdwName to set
     */
    public void setPsZbdwName(String psZbdwName) {
        this.psZbdwName = psZbdwName;
    }

    /**
     * @return the sqReason
     */
    public String getSqReason() {
        return sqReason;
    }

    /**
     * @param sqReason the sqReason to set
     */
    public void setSqReason(String sqReason) {
        this.sqReason = sqReason;
    }

    /**
     * @return the drAttach
     */
    public String getDrAttach() {
        return drAttach;
    }

    /**
     * @param drAttach the drAttach to set
     */
    public void setDrAttach(String drAttach) {
        this.drAttach = drAttach;
    }

    /**
     * @return the projectMan
     */
    public String getProjectMan() {
        return projectMan;
    }

    /**
     * @param projectMan the projectMan to set
     */
    public void setProjectMan(String projectMan) {
        this.projectMan = projectMan;
    }

    /**
     * @return the remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * @param remark the remark to set
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the statusTj
     */
    public Boolean getStatusTj() {
        return statusTj;
    }

    /**
     * @param statusTj the statusTj to set
     */
    public void setStatusTj(Boolean statusTj) {
        this.statusTj = statusTj;
    }

    /**
     * @return the pinType
     */
    public String getPinType() {
        return pinType;
    }

    /**
     * @param pinType the pinType to set
     */
    public void setPinType(String pinType) {
        this.pinType = pinType;
    }

    /**
     * @return the inputDate
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * @param inputDate the inputDate to set
     */
    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    /**
     * @return the inputName
     */
    public String getInputName() {
        return inputName;
    }

    /**
     * @param inputName the inputName to set
     */
    public void setInputName(String inputName) {
        this.inputName = inputName;
    }

    /**
     * @return the editDate
     */
    public Date getEditDate() {
        return editDate;
    }

    /**
     * @param editDate the editDate to set
     */
    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }

    /**
     * @return the editName
     */
    public String getEditName() {
        return editName;
    }

    /**
     * @param editName the editName to set
     */
    public void setEditName(String editName) {
        this.editName = editName;
    }

    public String getJianyiDept() {
        return jianyiDept;
    }

    /**
     * @param editName the editName to set
     */
    public void setJianyiDept(String jianyiDept) {
        this.jianyiDept = jianyiDept;
    }

    public Date getPostDate() {
        return postDate;
    }

    /**
     * @param postDate the postDate to set
     */
    public void setPostDate(Date postDate) {
        this.postDate = postDate;
    }

    /**
     * @return the postName
     */
    public String getPostName() {
        return postName;
    }

    /**
     * @param postName the postName to set
     */
    public void setPostName(String postName) {
        this.postName = postName;
    }

    /**
     * @return the tjPost
     */
    public String getTjPost() {
        return tjPost;
    }

    /**
     * @param tjPost the tjPost to set
     */
    public void setTjPost(String tjPost) {
        this.tjPost = tjPost;
    }

    /**
     * @return the tjPost2
     */
    public String getTjPost2() {
        return tjPost2;
    }

    /**
     * @param tjPost2 the tjPost2 to set
     */
    public void setTjPost2(String tjPost2) {
        this.tjPost2 = tjPost2;
    }

    /**
     * @return the zhuanyelx
     */
    public String getZhuanyelx() {
        return zhuanyelx;
    }

    /**
     * @param zhuanyelx the zhuanyelx to set
     */
    public void setZhuanyelx(String zhuanyelx) {
        this.zhuanyelx = zhuanyelx;
    }
}
