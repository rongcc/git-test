/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.drms.util;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import javax.sql.DataSource;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;
import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rcsoft.rc.db.CachingRcdb;
import rong.gwm.drms.dto.DrPlan;
import rong.gwm.drms.dto.Drbg;
import rong.gwm.drms.services.DrPlanService;

/**
 *
 * @author ZhouRongChao
 */
public class DP2TimelineXML {

    public void BuildXMLDoc(String xmlPath) throws IOException, JDOMException {
        String filePath = "";
        if (xmlPath != null) {
            filePath = xmlPath;
        }
        // 创建根节点;   
        Element root = new Element("data");
        // 根节点添加到文档中；   
        Document Doc = new Document(root);
        //查数据
        DataSource ds = CachingRcdb.getInstance().getDs4Drms();
        Dao dao = new NutDao(ds);
        List al = dao.query(DrPlan.class, Cnd.wrap(" status=1 "), null);
        DrPlanService dpService = new DrPlanService();
        // 此处 for 循环可替换成 遍历 数据库表的结果集操作;   
        for (int i = 0; i < al.size(); i++) {
            DrPlan dp = (DrPlan) al.get(i);
            // 创建节点;   
            Element elements = new Element("event");
            // 给节点添加属性;   
            elements.setAttribute("start", "" + dp.getStartTime().toString());
            //elements.setAttribute("end", "" + dp.getEndTime());
            elements.setAttribute("title", "" + dp.getPsxmName());
            elements.setAttribute("link", "");
            int oc = dao.count(Drbg.class, Cnd.wrap("source_order='" + dp.getPlanNo() + "' and status!=-1 and status_tj=1"));
            if (0 < oc) {
                elements.setAttribute("icon", "green-circle.png");
            }
            String nstr = dpService.findDrsqItemPersonListStr(ds, dp.getPlanNo());
            elements.setText(dp.getPlanNo() + ":" + nstr);
            // 给父节点添加子节点;  
            root.addContent(elements);
        }
        Format format = Format.getPrettyFormat();
        XMLOutputter XMLOut = new XMLOutputter(format);
        // 输出xml 文件；  
        XMLOut.output(Doc, new FileOutputStream(filePath + "timeline_ex1.xml"));
    }
}
