/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.drms.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;
import java.util.List;
import javax.sql.DataSource;
import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rong.gwm.drms.dto.PPC;
import rong.gwm.drms.dto.PpcPost;
import rong.gwm.ts.dto.SearchAdItem;
import rong.gwm.ts.util.DadaoUse;

/**
 *
 * @author zhourongchao
 */
public class PpcService {

    public PpcService() {
    }

    /**
     * 获得一个单据的审批信息。
     * @param ds 数据源
     * @param orderNo 单号
     * @return
     */
    public List findPpcPostList(DataSource ds, String orderNo) {
        List al = null;
        try {
            Dao dao = new NutDao(ds);
            al = dao.query(PpcPost.class, Cnd.where("order_no", "=", orderNo).asc("id"), null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return al;
    }

    /**
     * 获得在特定状态下的某部门上传的PPC个数。
     * @param ds
     * @param statusInt 编制或未审核前委0已审核1批准后为2
     * @param deptNo
     * @return
     */
    public int getPpcCount(DataSource ds, int statusInt, String deptNo) {
        int di = 0;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            //
            String sqlStr = "select * from (select a.status sta,a.real_filename real_filename,a.input_name,"
                    + "b.oper_no,b.dept_no dept_no,b.dept_name dept_name"
                    + " FROM gwmdrms.ppc a left join gwm_ts.operator b"
                    + " on a.input_name=b.oper_no ) as ab"
                    + " where sta=? and dept_no=? and real_filename is not null";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setInt(1, statusInt);
            pStmt.setString(2, deptNo);
            rs = pStmt.executeQuery();
            while (rs.next()) {
                di += 1;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return di;
    }

    public List searchAd(DataSource ds, List itemList) {
        List dList = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            //
            SearchAdItem item = null;
            StringBuilder sqlStr = new StringBuilder();
            for (int i = 0; i < itemList.size(); i++) {
                item = (SearchAdItem) itemList.get(i);
                String aoStr = item.getAo();
                String khStr = item.getKh();
                String tbColStr = item.getTbCol();
                String bjStr = item.getBj();
                String kwType = item.getKwType();
                if (aoStr == null) {
                    aoStr = "";
                }
                if (khStr == null) {
                    khStr = "";
                }
                if (tbColStr == null) {
                    tbColStr = "";
                }
                if (bjStr == null) {
                    bjStr = "";
                }
                if (kwType == null) {
                    kwType = "String";
                }
                //根据kwType内容取值。字符串，日期，整数。
                String kwStr = null;
                Date kwDate = null;
                Integer kwInteger = null;
                if (kwType.equals("String")) {
                    kwStr = (String) item.getKw();
                } else if (kwType.equals("Date")) {
                    kwDate = (Date) item.getKw();
                } else if (kwType.equals("Integer")) {
                    kwInteger = (Integer) item.getKw();
                }
                //
                sqlStr.append(" ");
                sqlStr.append(aoStr);
                sqlStr.append(khStr);
                sqlStr.append(" ");
                sqlStr.append(tbColStr);
                sqlStr.append(" ");
                if ("DaYu".equals(bjStr)) {
                    sqlStr.append(">");
                } else if ("DaYuDengYu".equals(bjStr)) {
                    sqlStr.append(">=");
                } else if ("XiaoYu".equals(bjStr)) {
                    sqlStr.append("<");
                } else if ("XiaoYuDengYu".equals(bjStr)) {
                    sqlStr.append("<=");
                } else {
                    sqlStr.append(bjStr);
                }
                if (kwStr != null) {
                    if (bjStr.equals("like")) {
                        sqlStr.append(" '");
                        sqlStr.append("%");
                        sqlStr.append(kwStr);
                        sqlStr.append("%");
                        sqlStr.append("'");
                    } else if (bjStr.equals("=") || bjStr.equals("!=") || bjStr.equals("DaYu") || bjStr.equals("DaYuDengYu") || bjStr.equals("XiaoYu") || bjStr.equals("XiaoYuDengYu")) {
                        sqlStr.append(" '");
                        sqlStr.append(kwStr);
                        sqlStr.append("'");
                    } else {
                        sqlStr.append(" ");
                        sqlStr.append(kwStr);
                    }
                } else if (kwDate != null) {
                    sqlStr.append(" '");
                    sqlStr.append(DadaoUse.getInstance().formatRiQiShiJianDate(kwDate));
                    sqlStr.append("'");
                } else if (kwInteger != null) {
                    sqlStr.append(" ");
                    sqlStr.append(kwInteger);
                }
            }
            //
            //System.out.println("SQL语句：where " + sqlStr);
            //
            //pStmt = conn.prepareStatement("select * from ppc where" + sqlStr);
            //
            Dao dao = new NutDao(ds);
            dList = dao.query(PPC.class, Cnd.wrap(sqlStr + " order by input_date desc"), null);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return dList;
    }
}
