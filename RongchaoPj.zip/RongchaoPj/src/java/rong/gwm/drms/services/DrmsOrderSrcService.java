/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.drms.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;

/**
 *
 * @author ZhouRongChao
 */
public class DrmsOrderSrcService {

    private String getDrsqInputName4Wenti(DataSource ds, String orderStart) {
        //Date myDate = null;
        String inputName = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            Dao dao = new NutDao(ds);
            conn = ds.getConnection();
            //
            String sqlStr = "select * from drsq where drsq.drsq_no =("
                    + "select dr_plan.drsq_no from dr_plan where dr_plan.plan_no =( "
                    + "select drbg.source_order from drbg where drbg.drbg_no =("
                    + "SELECT src_order_no FROM wenti where we_no=?"
                    + ")"
                    + ")"
                    + ")";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, orderStart);
            rs = pStmt.executeQuery();
            if (rs.next()) {
                inputName = rs.getString("input_name");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return inputName;
    }

    private List getDrsqInputEditPostPost2Name4Wenti(DataSource ds, String orderStart) {
        //Date myDate = null;
        List ieppList = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            Dao dao = new NutDao(ds);
            conn = ds.getConnection();
            //
            String sqlStr = "select * from drsq where drsq.drsq_no =("
                    + "select dr_plan.drsq_no from dr_plan where dr_plan.plan_no =( "
                    + "select drbg.source_order from drbg where drbg.drbg_no =("
                    + "SELECT src_order_no FROM wenti where we_no=?"
                    + ")"
                    + ")"
                    + ")";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, orderStart);
            rs = pStmt.executeQuery();
            ieppList = new ArrayList();
            if (rs.next()) {
                ieppList.add(rs.getString("input_name"));
                ieppList.add(rs.getString("edit_name"));
                ieppList.add(rs.getString("post_name"));
                ieppList.add(rs.getString("tj_post"));
                ieppList.add(rs.getString("tj_post2"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return ieppList;
    }

    /**
     * 该用户是否为此问题关联的DR申请人员。
     * @param ds
     * @param orderStart
     * @param myName
     * @param myType 如果为1，仅考虑录入者。如果2，考虑申请编辑审核批准全部人员。
     * @return
     */
    public boolean isDrsqSrcName4Wenti(DataSource ds, String orderStart, String myName, int myType) {
        boolean boo = false;
        if (1 == myType) {
            boo = this.getDrsqInputName4Wenti(ds, orderStart).equalsIgnoreCase(myName);
        }
        if (2 == myType) {
            boo = this.getDrsqInputEditPostPost2Name4Wenti(ds, orderStart).contains(myName);
        }
        return boo;
    }

    private List getDrPlanInputEditPostName4Wenti(DataSource ds, String orderStart) {
        //Date myDate = null;
        List ieppList = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            Dao dao = new NutDao(ds);
            conn = ds.getConnection();
            //
            String sqlStr = "select * from dr_plan where dr_plan.plan_no =( "
                    + "select drbg.source_order from drbg where drbg.drbg_no =("
                    + "SELECT src_order_no FROM wenti where we_no=?"
                    + ")"
                    + ")";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, orderStart);
            rs = pStmt.executeQuery();
            ieppList = new ArrayList();
            if (rs.next()) {
                ieppList.add(rs.getString("input_name"));
                ieppList.add(rs.getString("edit_name"));
                ieppList.add(rs.getString("post_name"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return ieppList;
    }

    /**
     *
     * @param ds
     * @param orderStart
     * @param myName
     * @return
     */
    public boolean isDrPlanSrcName4Wenti(DataSource ds, String orderStart, String myName) {
        boolean boo = false;
        boo = this.getDrPlanInputEditPostName4Wenti(ds, orderStart).contains(myName);
        return boo;
    }

    private List getDrbgInputEditPostPost2Name4Wenti(DataSource ds, String orderStart) {
        //Date myDate = null;
        List ieppList = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            Dao dao = new NutDao(ds);
            conn = ds.getConnection();
            //
            String sqlStr = "select * from drbg where drbg.drbg_no =("
                    + "SELECT src_order_no FROM wenti where we_no=?"
                    + ")";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, orderStart);
            rs = pStmt.executeQuery();
            ieppList = new ArrayList();
            if (rs.next()) {
                ieppList.add(rs.getString("input_name"));
                ieppList.add(rs.getString("edit_name"));
                ieppList.add(rs.getString("post_name"));
                ieppList.add(rs.getString("tj_post"));
                ieppList.add(rs.getString("tj_post2"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return ieppList;
    }

    /**
     * 
     * @param ds
     * @param orderStart
     * @param myName
     * @return
     */
    public boolean isDrbgSrcName4Wenti(DataSource ds, String orderStart, String myName) {
        boolean boo = false;
        boo = this.getDrbgInputEditPostPost2Name4Wenti(ds, orderStart).contains(myName);
        return boo;
    }

    private List getWentiInputEditPostName4Wenti(DataSource ds, String orderStart) {
        //Date myDate = null;
        List ieppList = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            Dao dao = new NutDao(ds);
            conn = ds.getConnection();
            //
            String sqlStr = "SELECT * FROM wenti where we_no=?";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, orderStart);
            rs = pStmt.executeQuery();
            ieppList = new ArrayList();
            if (rs.next()) {
                ieppList.add(rs.getString("input_name"));
                ieppList.add(rs.getString("edit_name"));
                ieppList.add(rs.getString("post_name"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return ieppList;
    }

    public boolean isWentiSrcName4Wenti(DataSource ds, String orderStart, String myName) {
        boolean boo = false;
        boo = this.getWentiInputEditPostName4Wenti(ds, orderStart).contains(myName);
        return boo;
    }

    /**
     * 此问题的关联人。
     * @param ds
     * @param orderStart
     * @param myName
     * @return
     */
    public boolean isSrcWenti(DataSource ds, String orderStart, String myName) {
        boolean boo = false;
        if (isDrsqSrcName4Wenti(ds, orderStart, myName, 2) || isDrPlanSrcName4Wenti(ds, orderStart, myName) || isDrbgSrcName4Wenti(ds, orderStart, myName) || isWentiSrcName4Wenti(ds, orderStart, myName)) {
            boo = true;
        }
        return boo;
    }

    private List getDrsqInputEditPostPost2Name4Drbg(DataSource ds, String orderStart) {
        //Date myDate = null;
        List ieppList = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            Dao dao = new NutDao(ds);
            conn = ds.getConnection();
            //
            String sqlStr = "select * from drsq where drsq.drsq_no =("
                    + "select dr_plan.drsq_no from dr_plan where dr_plan.plan_no =( "
                    + "select drbg.source_order from drbg where drbg.drbg_no =?"
                    + ")"
                    + ")";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, orderStart);
            rs = pStmt.executeQuery();
            ieppList = new ArrayList();
            if (rs.next()) {
                ieppList.add(rs.getString("input_name"));
                ieppList.add(rs.getString("edit_name"));
                ieppList.add(rs.getString("post_name"));
                ieppList.add(rs.getString("tj_post"));
                ieppList.add(rs.getString("tj_post2"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return ieppList;
    }

    public boolean isDrsqSrcName4Drbg(DataSource ds, String orderStart, String myName) {
        boolean boo = false;
        boo = this.getDrsqInputEditPostPost2Name4Drbg(ds, orderStart).contains(myName);
        return boo;
    }

    private List getDrPlanInputEditPostName4Drbg(DataSource ds, String orderStart) {
        //Date myDate = null;
        List ieppList = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            Dao dao = new NutDao(ds);
            conn = ds.getConnection();
            //
            String sqlStr = "select * from dr_plan where dr_plan.plan_no =( "
                    + "select drbg.source_order from drbg where drbg.drbg_no =?"
                    + ")";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, orderStart);
            rs = pStmt.executeQuery();
            ieppList = new ArrayList();
            if (rs.next()) {
                ieppList.add(rs.getString("input_name"));
                ieppList.add(rs.getString("edit_name"));
                ieppList.add(rs.getString("post_name"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return ieppList;
    }

    public boolean isDrPlanSrcName4Drbg(DataSource ds, String orderStart, String myName) {
        boolean boo = false;
        boo = this.getDrPlanInputEditPostName4Drbg(ds, orderStart).contains(myName);
        return boo;
    }

    private List getDrbgInputEditPostPost2Name4Brbg(DataSource ds, String orderStart) {
        //Date myDate = null;
        List ieppList = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            Dao dao = new NutDao(ds);
            conn = ds.getConnection();
            //
            String sqlStr = "select * from drbg where drbg.drbg_no =?";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, orderStart);
            rs = pStmt.executeQuery();
            ieppList = new ArrayList();
            if (rs.next()) {
                ieppList.add(rs.getString("input_name"));
                ieppList.add(rs.getString("edit_name"));
                ieppList.add(rs.getString("post_name"));
                ieppList.add(rs.getString("tj_post"));
                ieppList.add(rs.getString("tj_post2"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return ieppList;
    }

    public boolean isDrbgSrcName4Drbg(DataSource ds, String orderStart, String myName) {
        boolean boo = false;
        boo = this.getDrbgInputEditPostPost2Name4Brbg(ds, orderStart).contains(myName);
        return boo;
    }

    /**
     * 
     * @param ds
     * @param orderStart
     * @param myName
     * @return
     */
    public boolean isSrcDrbg(DataSource ds, String orderStart, String myName) {
        boolean boo = false;
        if (isDrsqSrcName4Drbg(ds, orderStart, myName) || isDrPlanSrcName4Drbg(ds, orderStart, myName) || isDrbgSrcName4Drbg(ds, orderStart, myName)) {
            boo = true;
        }
        return boo;
    }

    private List getDrsqInputEditPostPost2Name4Brsq(DataSource ds, String orderStart) {
        //Date myDate = null;
        List ieppList = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            Dao dao = new NutDao(ds);
            conn = ds.getConnection();
            //
            String sqlStr = "select * from drsq where drsq.drsq_no =?";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, orderStart);
            rs = pStmt.executeQuery();
            ieppList = new ArrayList();
            if (rs.next()) {
                ieppList.add(rs.getString("input_name"));
                ieppList.add(rs.getString("edit_name"));
                ieppList.add(rs.getString("post_name"));
                ieppList.add(rs.getString("tj_post"));
                ieppList.add(rs.getString("tj_post2"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return ieppList;
    }

    public boolean isDrsqSrcName4Drsq(DataSource ds, String orderStart, String myName) {
        boolean boo = false;
        boo = this.getDrsqInputEditPostPost2Name4Brsq(ds, orderStart).contains(myName);
        return boo;
    }

    public boolean isSrcDrsq(DataSource ds, String orderStart, String myName) {
        boolean boo = false;
        if (isDrsqSrcName4Drsq(ds, orderStart, myName)) {
            boo = true;
        }
        return boo;
    }
}
