/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.drms.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.sql.DataSource;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rong.gwm.drms.dto.DrbgItemFile;

/**
 *
 * @author ZhouRongChao
 */
public class DrbgItemFileService {

    public DrbgItemFile fetch(DataSource ds, int itemNo, String orderNo) {
        DrbgItemFile cd = null;
        try {
            Dao dao = new NutDao(ds);
            cd = dao.fetchx(DrbgItemFile.class, itemNo, orderNo);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cd;
    }

    public int getNextItemNo(DataSource ds, String orderNo) {
        int nextItemNo = 1;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            //取原表
            String sqlStr = "SELECT max(item_no) FROM drbg_item_file where drbg_no='" + orderNo + "'";
            pStmt = conn.prepareStatement(sqlStr);
            rs = pStmt.executeQuery();
            if (rs.next()) {
                nextItemNo = rs.getInt(1) + 1;
            } else {
                nextItemNo = 1;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return nextItemNo;
    }
}
