/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.drms.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.List;
import javax.sql.DataSource;
import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rong.gwm.drms.dto.DrsqItemFile;
import rong.gwm.drms.dto.DrsqPost;

/**
 *
 * @author zhourongchao
 */
public class DrsqService {

    public DrsqService() {
    }

    /**
     * get the next order no.
     */
    public String getNextNo(DataSource ds) {
        String nextNo = "";
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            StringBuffer sb = new StringBuffer();
            Calendar rightNow = Calendar.getInstance();
            int y = rightNow.get(Calendar.YEAR);
            conn = ds.getConnection();
            //取原表
            String sqlStr = "select max(drsq_no) from drsq";
            pStmt = conn.prepareStatement(sqlStr);
            rs = pStmt.executeQuery();
            String no = null;
            if (rs.next()) {
                no = rs.getString(1);
            }
            //根据查询结果运算
            if (no != null && no.length() > 4) {
                int lastYear = 2000 + Integer.parseInt(no.substring(2, 4));
                if (y > lastYear) {
                    nextNo = sb.append("DQ").append(String.valueOf(y).substring(2)).append("000001").toString();
                } else {
                    int ino = Integer.parseInt(no.substring(4));
                    nextNo = sb.append("DQ").append(String.valueOf(y).substring(2)).append(String.valueOf(1000001 + ino).substring(1)).toString();
                }
            } else {
                nextNo = sb.append("DQ").append(String.valueOf(y).substring(2)).append("000001").toString();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return nextNo;
    }

    /**
     * 查出此单据的文件列表。
     * @param ds
     * @param orderNo
     * @return
     */
    public List findItemFileList(DataSource ds, String orderNo) {
        List al = null;
        try {
            Dao dao = new NutDao(ds);
            al = dao.query(DrsqItemFile.class, Cnd.where("drsq_no", "=", orderNo).asc("item_no"), null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return al;
    }

    /**
     * 获得一个单据的审批信息。
     * @param ds 数据源
     * @param orderNo 单号
     * @return
     */
    public List findDrsqPostList(DataSource ds, String orderNo) {
        List al = null;
        try {
            Dao dao = new NutDao(ds);
            al = dao.query(DrsqPost.class, Cnd.where("order_no", "=", orderNo).asc("id"), null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return al;
    }

    /**
     * 该用户是否在设计评审申请单的计划内。
     * @param ds
     * @param operNo 用户编号；
     * @param orderNo 评审申请单号；
     * @return
     */
    public boolean isInDrPlan(DataSource ds, String operNo, String orderNo) {
        boolean myBoo = false;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            //取原表
            String sqlStr = "SELECT 1 FROM drsq_item_person where drsq_no IN("
                    + "select distinct plan_no from DR_PLAN where status<>-1 and  drsq_no=?"
                    + ") and username=?";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, orderNo);
            pStmt.setString(2, operNo);
            rs = pStmt.executeQuery();
            if (rs.next()) {
                myBoo = true;
            }
            /*
            while (rs.next()) {
            if ("1".equals(rs.getString(1))) {
            myBoo = true;
            }
            }*/
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return myBoo;
    }
}
