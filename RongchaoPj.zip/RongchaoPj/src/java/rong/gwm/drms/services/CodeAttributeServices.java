/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.drms.services;

import javax.sql.DataSource;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rong.gwm.drms.dto.CodeAttribute;

/**
 *
 * @author zhourongchao
 */
public class CodeAttributeServices {

    public CodeAttributeServices() {
    }

    public CodeAttribute fetch(DataSource ds, String codeType, String code) {
        CodeAttribute cd = null;
        try {
            Dao dao = new NutDao(ds);
            cd = dao.fetchx(CodeAttribute.class, codeType, code);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cd;
    }

    public int delete(DataSource ds, CodeAttribute cd) {
        int di = 0;
        try {
            Dao dao = new NutDao(ds);
            di = dao.deletex(CodeAttribute.class, cd.getCodeType(), cd.getCode());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return di;
    }

    public boolean myCode2oc(DataSource ds, String pno) {
        boolean boo = false;
        try {
            CodeAttribute cde = fetch(ds, "my_code2", pno);
            if (cde != null) {
                boo = "1".equals(cde.getAttribute1());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return boo;
    }
}
