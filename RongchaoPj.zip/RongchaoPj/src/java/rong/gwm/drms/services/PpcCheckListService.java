/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.drms.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import javax.sql.DataSource;
import org.nutz.dao.Chain;
import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rong.gwm.drms.dto.PpcCheckList;

/**
 *
 * @author ZhouRongChao
 */
public class PpcCheckListService {

    /**
     *
     * @param ds
     * @return
     */
    public int getNextNo(DataSource ds) {
        int nextNo = 0;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            //取原表
            String sqlStr = "select max(order_no) from ppc_check_list";
            pStmt = conn.prepareStatement(sqlStr);
            rs = pStmt.executeQuery();
            if (rs.next()) {
                nextNo = rs.getInt(1) + 1;
            } else {
                nextNo = 1;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return nextNo;
    }

    /**
     * 
     * @param ds
     * @param orderNo
     * @return
     */
    public int destroyOrder(DataSource ds, int orderNo) {
        int di = 0;
        try {
            Dao dao = new NutDao(ds);
            di = dao.update(PpcCheckList.class, Chain.make("status", -1), Cnd.where("order_no", "=", orderNo));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return di;
    }

    /**
     *
     * @param ds
     * @param orderNo
     * @return
     */
    public List findItemList(DataSource ds, int orderNo) {
        List al = null;
        try {
            Dao dao = new NutDao(ds);
            al = dao.query(PpcCheckList.class, Cnd.where("order_no", "=", orderNo), null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return al;
    }

    public PpcCheckList fetchA(DataSource ds, int orderNo) {
        PpcCheckList po = null;
        List al = null;
        try {
            Dao dao = new NutDao(ds);
            al = dao.query(PpcCheckList.class, Cnd.where("order_no", "=", orderNo), null);
            if (al.size() >= 1) {
                po = (PpcCheckList) al.get(0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return po;
    }

}
