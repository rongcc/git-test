/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.drms.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;

/**
 *
 * @author ZhouRongChao
 */
public class MyWorkService {

    /**
     * 我的待办事项概览。
     * @param ds
     * @param operNo
     * @return
     */
    public List getMyWorkList(DataSource ds, String operNo) {
        List al = null;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            al = new ArrayList();
            conn = ds.getConnection();
            String sqlStr = "";
            sqlStr = "select drsq_no from drsq where tj_post2 =? and status=1 order by input_date desc";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, operNo);
            rs = pStmt.executeQuery();
            while (rs.next()) {
                al.add("需要批准DR申请单" + rs.getString(1) + "");
            }
            sqlStr = "select drsq_no from drsq where tj_post =? and status=0 and status_tj=1 order by input_date desc";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, operNo);
            rs = pStmt.executeQuery();
            while (rs.next()) {
                al.add("需要审核DR申请单" + rs.getString(1) + "");
            }
            sqlStr = "select drbg_no from drbg where tj_post2 =? and status=1 order by input_date desc";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, operNo);
            rs = pStmt.executeQuery();
            while (rs.next()) {
                al.add("需要批准DR报告" + rs.getString(1) + "");
            }
            sqlStr = "select drbg_no from drbg where tj_post =? and status=0 and status_tj=1 order by input_date desc";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, operNo);
            rs = pStmt.executeQuery();
            while (rs.next()) {
                al.add("需要审核DR报告" + rs.getString(1) + "");
            }
            sqlStr = "select id from PPC where tj_post2 =? and status=1 order by input_date desc";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, operNo);
            rs = pStmt.executeQuery();
            while (rs.next()) {
                al.add("需要批准PPC " + rs.getString(1) + "");
            }
            sqlStr = "select id from PPC where tj_post =? and status=0 and status_tj=1 order by input_date desc";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, operNo);
            rs = pStmt.executeQuery();
            while (rs.next()) {
                al.add("需要审核PPC " + rs.getString(1) + "");
            }
            //非指定权限
            sqlStr = "SELECT p.plan_no,o.oper_no,o.dept_no"
                    + " FROM dr_plan p left join gwm_ts.operator o"
                    + " on p.input_name=o.oper_no"
                    + " where p.status=1 and p.plan_no not in(select source_order from drbg where status!=-1)"
                    + " and o.dept_no =(SELECT dept_no FROM gwm_ts.operator where oper_no=?)"
                    + " and 'Y'=(SELECT create_right FROM gwm_ts.access_right where oper_no=? and access_page='drms_dr_planM')";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, operNo);
            pStmt.setString(2, operNo);
            rs = pStmt.executeQuery();
            while (rs.next()) {
                al.add("可以根据DR计划 " + rs.getString(1) + "编制DR报告。");
            }
            sqlStr = "SELECT p.drsq_no,o.oper_no,o.dept_no"
                    + " FROM drsq p left join gwm_ts.operator o"
                    + " on p.input_name=o.oper_no"
                    + " where p.status=2 and p.drsq_no not in(select drsq_no from dr_plan where status!=-1)"
                    + " and o.dept_no =(SELECT dept_no FROM gwm_ts.operator where oper_no=?)"
                    + " and 'Y'=(SELECT create_right FROM gwm_ts.access_right where oper_no=? and access_page='drms_drbgM')";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, operNo);
            pStmt.setString(2, operNo);
            rs = pStmt.executeQuery();
            while (rs.next()) {
                al.add("可以根据DR申请单 " + rs.getString(1) + "编制DR计划。");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return al;
    }
}
