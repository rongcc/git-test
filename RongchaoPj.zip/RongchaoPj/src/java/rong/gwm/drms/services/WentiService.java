/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.drms.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.sql.DataSource;
import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rong.gwm.drms.dto.JinduJilu;
import rong.gwm.drms.dto.Wenti;
import rong.gwm.drms.dto.WentiItemFile;

/**
 *
 * @author zhourongchao
 */
public class WentiService {

    public WentiService() {
    }

    /**
     * get the next order no.
     */
    public String getNextNo(DataSource ds) {
        String nextNo = "";
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            StringBuffer sb = new StringBuffer();
            Calendar rightNow = Calendar.getInstance();
            int y = rightNow.get(Calendar.YEAR);
            conn = ds.getConnection();
            //取原表
            String sqlStr = "select max(we_no) from wenti";
            pStmt = conn.prepareStatement(sqlStr);
            rs = pStmt.executeQuery();
            String no = null;
            if (rs.next()) {
                no = rs.getString(1);
            }
            //根据查询结果运算
            if (no != null && no.length() > 4) {
                int lastYear = 2000 + Integer.parseInt(no.substring(2, 4));
                if (y > lastYear) {
                    nextNo = sb.append("WE").append(String.valueOf(y).substring(2)).append("000001").toString();
                } else {
                    int ino = Integer.parseInt(no.substring(4));
                    nextNo = sb.append("WE").append(String.valueOf(y).substring(2)).append(String.valueOf(1000001 + ino).substring(1)).toString();
                }
            } else {
                nextNo = sb.append("WE").append(String.valueOf(y).substring(2)).append("000001").toString();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return nextNo;
    }

    /**
     * 查出此单据的文件列表。
     * @param ds
     * @param orderNo
     * @return
     */
    public List findItemFileList(DataSource ds, String orderNo) {
        List al = null;
        try {
            Dao dao = new NutDao(ds);
            al = dao.query(WentiItemFile.class, Cnd.where("we_no", "=", orderNo).asc("item_no"), null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return al;
    }

    /**
     * 获取最近的进度记录。
     * @param ds
     * @param orderNo
     * @return
     */
    public JinduJilu getLastJinduJilu(DataSource ds, String orderNo) {
        List al = null;
        JinduJilu jilu = null;
        try {
            Dao dao = new NutDao(ds);
            //按录入日期排列后取最后记录即为最近的进度记录。
            al = dao.query(JinduJilu.class, Cnd.where("source_order", "=", orderNo).and("status", "!=", "-1").asc("input_date"), null);
            for (int i = 0; i < al.size(); i++) {
                jilu = (JinduJilu) al.get(i);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jilu;
    }

    /**
     * 获取问题最近的进度记录状态。
     * @param ds
     * @param orderNo
     * @return
     */
    public String getJinduJilu(DataSource ds, String orderNo) {
        String dStr = "";
        List al = null;
        JinduJilu jilu = null;
        try {
            Dao dao = new NutDao(ds);
            //按录入日期排列后取最后记录即为最近的进度记录。
            al = dao.query(JinduJilu.class, Cnd.where("source_order", "=", orderNo).and("status", "!=", "-1").asc("input_date"), null);
            for (int i = 0; i < al.size(); i++) {
                jilu = (JinduJilu) al.get(i);
                dStr = jilu.getNowJindu();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return dStr;
    }

    /**
     * 将用12345...代表的问题严重度转化为ABCDE。
     * @param ds
     * @param yzdFen
     * @return
     */
    public String transYzd(DataSource ds, String yzdFen) {
        String dStr = "";
        if (yzdFen == null || "".equals(yzdFen)) {
            return dStr;
        }
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            //取原表
            String sqlStr = "SELECT attribute1 FROM gwmdrms.code_attribute where code_type='wtyzd' and code=?";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, yzdFen);
            rs = pStmt.executeQuery();
            if (rs.next()) {
                dStr = rs.getString(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return dStr;
    }

    /**
     * 距问题完成时间还有的天数。
     * @param ds
     * @param orderNo
     * @return
     */
    public int getJuWancheng(DataSource ds, String orderNo) {
        int jw = 0;
        try {
            Dao dao = new NutDao(ds);
            Wenti wenti = dao.fetch(Wenti.class, orderNo);
            Date fDate = wenti.getFinishDate();
            if (fDate == null) {
                return 0;
            }
            Calendar rightNow = Calendar.getInstance();
            long ju = fDate.getTime() - rightNow.getTimeInMillis();
            long juTian = ju / (24 * 60 * 60 * 1000);
            jw = new Long(juTian).intValue();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jw;
    }
}
