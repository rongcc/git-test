/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.drms.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.sql.DataSource;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rong.gwm.drms.dto.DrsqItemPerson;

/**
 *
 * @author zhourongchao
 */
public class DrsqItemPersonService {

    public DrsqItemPersonService() {
    }

    public int getNextItemNo(DataSource ds, String orderNo) {
        int nextItemNo = 1;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            //取原表
            String sqlStr = "SELECT max(item_no) FROM gwmdrms.drsq_item_person where drsq_no='" + orderNo + "'";
            pStmt = conn.prepareStatement(sqlStr);
            rs = pStmt.executeQuery();
            if (rs.next()) {
                nextItemNo = rs.getInt(1) + 1;
            } else {
                nextItemNo = 1;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return nextItemNo;
    }

    /**
     * 获取一条审核计划的具体安排
     * @param ds
     * @param codeType
     * @param code
     * @return
     */
    public DrsqItemPerson fetch(DataSource ds, int itemNo, String drsqNo) {
        DrsqItemPerson cd = null;
        try {
            Dao dao = new NutDao(ds);
            cd = dao.fetchx(DrsqItemPerson.class, itemNo, drsqNo);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cd;
    }

    /**
     * 删除一条审核计划的具体安排
     * @param ds
     * @param cd
     * @return
     */
    public int delete(DataSource ds, DrsqItemPerson cd) {
        int di = 0;
        try {
            Dao dao = new NutDao(ds);
            di = dao.deletex(DrsqItemPerson.class, cd.getItemNo(), cd.getDrsqNo());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return di;
    }

    /**
     * 删除DR审核人员名单
     * @param ds
     * @param cd
     * @return
     */
    public int deleteOrderItems(DataSource ds, String orderNo) {
        int di = 0;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            String sqlStr = "delete FROM drsq_item_person where drsq_no=? ";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, orderNo);
            di = pStmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return di;
    }
}
