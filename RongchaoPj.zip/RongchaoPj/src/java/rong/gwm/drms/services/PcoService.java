/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.drms.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.List;
import javax.sql.DataSource;
import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rong.gwm.drms.dto.PcoFile;
import rong.gwm.drms.dto.PcoItem;
import rong.gwm.drms.dto.PcoPost;

/**
 *
 * @author zhourongchao
 */
public class PcoService {

    /**
     * get the next order no.
     */
    public String getNextNo(DataSource ds) {
        String nextNo = "";
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            StringBuffer sb = new StringBuffer();
            Calendar rightNow = Calendar.getInstance();
            int y = rightNow.get(Calendar.YEAR);
            conn = ds.getConnection();
            //取原表
            String sqlStr = "select max(order_no) from pco";
            pStmt = conn.prepareStatement(sqlStr);
            rs = pStmt.executeQuery();
            String no = null;
            if (rs.next()) {
                no = rs.getString(1);
            }
            //根据查询结果运算
            if (no != null && no.length() > 4) {
                int lastYear = 2000 + Integer.parseInt(no.substring(2, 4));
                if (y > lastYear) {
                    nextNo = sb.append("CO").append(String.valueOf(y).substring(2)).append("000001").toString();
                } else {
                    int ino = Integer.parseInt(no.substring(4));
                    nextNo = sb.append("CO").append(String.valueOf(y).substring(2)).append(String.valueOf(1000001 + ino).substring(1)).toString();
                }
            } else {
                nextNo = sb.append("CO").append(String.valueOf(y).substring(2)).append("000001").toString();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return nextNo;
    }

    /**
     * get next item no from itemType is item or file.
     * @param ds
     * @param orderNo
     * @param itemType
     * @return
     */
    public int getNextItemNo(DataSource ds, String orderNo, String itemType) {
        int nextNo = 1;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            String sqlStr = "select max(item_no) from pco_file where order_no=? ";
            if ("item".equalsIgnoreCase(itemType)) {
                sqlStr = "select max(item_no) from pco_item where order_no=? ";
            } else if ("file".equalsIgnoreCase(itemType)) {
                sqlStr = "select max(item_no) from pco_file where order_no=? ";
            }
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, orderNo);
            rs = pStmt.executeQuery();
            if (rs.next()) {
                nextNo = rs.getInt(1) + 1;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return nextNo;
    }

    /**
     * 获得子条目列表。
     * @param ds
     * @param orderNo
     * @return
     */
    public List getItemList(DataSource ds, String orderNo) {
        List al = null;
        try {
            Dao dao = new NutDao(ds);
            al = dao.query(PcoItem.class, Cnd.where("order_no", "=", orderNo).asc("item_no"), null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return al;
    }

    /**
     * 获得附件列表。
     * @param ds
     * @param orderNo
     * @return
     */
    public List getFileList(DataSource ds, String orderNo) {
        List al = null;
        try {
            Dao dao = new NutDao(ds);
            al = dao.query(PcoFile.class, Cnd.where("order_no", "=", orderNo).asc("item_no"), null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return al;
    }

    /**
     * 获得审批信息列表。
     * @param ds
     * @param orderNo
     * @return
     */
    public List getPostList(DataSource ds, String orderNo) {
        List al = null;
        try {
            Dao dao = new NutDao(ds);
            al = dao.query(PcoPost.class, Cnd.where("order_no", "=", orderNo).asc("post_date"), null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return al;
    }

    /**
     * 获取最后一次批注。
     * @param ds
     * @param orderNo
     * @return
     */
    public String getLastPostil(DataSource ds, String orderNo) {
        String dStr = "";
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            String sqlStr = "SELECT post_name,postil FROM pco_post where order_no=? order by post_date desc";
            pStmt = conn.prepareStatement(sqlStr);
            pStmt.setString(1, orderNo);
            rs = pStmt.executeQuery();
            if (rs.next()) {
                if (rs.getString("postil") == null || rs.getString("postil").trim().equals("")) {
                    dStr = "";
                } else {
                    dStr = "“" + rs.getString("postil") + "” —— " + rs.getString("post_name");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return dStr;
    }

    /**
     * 获取一个附件。
     * @param ds
     * @param orderNo
     * @param itemNo
     * @return
     */
    public Object fetchFile(DataSource ds, String orderNo, int itemNo) {
        PcoFile ob = null;
        try {
            Dao dao = new NutDao(ds);
            ob = dao.fetchx(PcoFile.class, itemNo, orderNo);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ob;
    }

    /**
     * 获取一个子条目。
     * @param ds
     * @param orderNo
     * @param itemNo
     * @return
     */
    public Object fetchItem(DataSource ds, String orderNo, int itemNo) {
        PcoItem ob = null;
        try {
            Dao dao = new NutDao(ds);
            ob = dao.fetchx(PcoItem.class, itemNo, orderNo);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ob;
    }
}
