/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.drms.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.sql.DataSource;

/**
 *
 * @author zhourongchao
 */
public class WpItemFileService {

    public WpItemFileService() {
    }

    public int getNextItemNo(DataSource ds, int orderNo) {
        int nextItemNo = 1;
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            conn = ds.getConnection();
            //取原表
            String sqlStr = "SELECT max(item_no) FROM gwmdrms.wp_item_file where project_no='" + orderNo + "'";
            pStmt = conn.prepareStatement(sqlStr);
            rs = pStmt.executeQuery();
            if (rs.next()) {
                nextItemNo = rs.getInt(1) + 1;
            } else {
                nextItemNo = 1;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return nextItemNo;
    }
}
