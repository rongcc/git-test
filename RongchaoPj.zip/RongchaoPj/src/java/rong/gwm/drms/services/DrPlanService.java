/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.drms.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.List;
import javax.sql.DataSource;
import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rong.gwm.drms.dto.DrPlanFile;
import rong.gwm.drms.dto.DrsqItemPerson;

/**
 *
 * @author ZhouRongChao
 */
public class DrPlanService {

    /**
     * get the next order no.
     */
    public String getNextNo(DataSource ds) {
        String nextNo = "";
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            StringBuffer sb = new StringBuffer();
            Calendar rightNow = Calendar.getInstance();
            int y = rightNow.get(Calendar.YEAR);
            conn = ds.getConnection();
            //取原表
            String sqlStr = "select max(plan_no) from dr_plan";
            pStmt = conn.prepareStatement(sqlStr);
            rs = pStmt.executeQuery();
            String no = null;
            if (rs.next()) {
                no = rs.getString(1);
            }
            //根据查询结果运算
            if (no != null && no.length() > 4) {
                int lastYear = 2000 + Integer.parseInt(no.substring(2, 4));
                if (y > lastYear) {
                    nextNo = sb.append("DP").append(String.valueOf(y).substring(2)).append("000001").toString();
                } else {
                    int ino = Integer.parseInt(no.substring(4));
                    nextNo = sb.append("DP").append(String.valueOf(y).substring(2)).append(String.valueOf(1000001 + ino).substring(1)).toString();
                }
            } else {
                nextNo = sb.append("DP").append(String.valueOf(y).substring(2)).append("000001").toString();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pStmt != null) {
                    pStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return nextNo;
    }

    public List findItemFileList(DataSource ds, String orderNo) {
        List al = null;
        try {
            Dao dao = new NutDao(ds);
            al = dao.query(DrPlanFile.class, Cnd.where("plan_no", "=", orderNo).asc("item_no"), null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return al;
    }

    public List findDrsqItemPersonList(DataSource ds, String orderNo) {
        List al = null;
        try {
            Dao dao = new NutDao(ds);
            al = dao.query(DrsqItemPerson.class, Cnd.where("drsq_no", "=", orderNo).asc("name"), null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return al;
    }

    public String findDrsqItemPersonListStr(DataSource ds, String orderNo) {
        StringBuilder strbu = new StringBuilder("");
        try {
            Dao dao = new NutDao(ds);
            List al = dao.query(DrsqItemPerson.class, Cnd.where("drsq_no", "=", orderNo).asc("name"), null);
            for (int i = 0; i < al.size(); i++) {
                DrsqItemPerson person = (DrsqItemPerson) al.get(i);
                strbu.append(person.getName()).append("；");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return strbu.toString();
    }
}
