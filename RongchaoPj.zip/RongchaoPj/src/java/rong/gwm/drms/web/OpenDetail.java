/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.drms.web;

import java.util.HashMap;
import java.util.Map;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.Executions;
import org.zkoss.zk.ui.event.GenericEventListener;
import org.zkoss.zul.Window;

/**
 * 打开查看详细页的事件监听器。
 *
 * @author ZhouRongChao
 */
public class OpenDetail extends GenericEventListener {

    String pno;
    String uri;
    Component moWin;

    /**
     *
     * @param pno 单据编号
     * @param uri 查看详细页的路径
     */
    public OpenDetail(String pno, String uri) {
        this.pno = pno;
        this.uri = uri;
    }

    /**
     *
     * @param pno 单据编号
     * @param uri 查看详细页的路径
     * @param moWin 母页面
     */
    public OpenDetail(String pno, String uri, Component moWin) {
        this.pno = pno;
        this.uri = uri;
        this.moWin = moWin;
    }

    /**
     * 响应鼠标单击事件。
     */
    public void onClick() {
        Map map = new HashMap();
        map.put("pno", pno);
        try {
            final Window win = (Window) Executions.createComponents(uri, moWin, map);
            win.setMaximizable(true);
            win.doModal();
        } catch (Exception e) {
        }
    }

    /**
     * 响应鼠标双击事件。
     */
    public void onDoubleClick() {
        Map map = new HashMap();
        map.put("pno", pno);
        try {
            final Window win = (Window) Executions.createComponents(uri, moWin, map);
            win.setMaximizable(true);
            win.doModal();
        } catch (Exception e) {
        }
    }
}