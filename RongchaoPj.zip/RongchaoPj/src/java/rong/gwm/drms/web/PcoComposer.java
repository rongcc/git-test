/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.drms.web;

import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.event.ForwardEvent;
import org.zkoss.zk.ui.util.GenericForwardComposer;
import org.zkoss.zul.*;
import org.zkoss.zul.event.PagingEvent;
import rcsoft.rc.util.RcUse;
import rong.gwm.drms.dto.Pco;

/**
 *
 * @author ZhouRongChao
 */
public class PcoComposer extends GenericForwardComposer {

    private static final long serialVersionUID = 1L;
    private final int _pageSize = 20;
    private int _startPageNumber = 0;
    private int _totalSize = 0;
    private boolean _needsTotalSizeUpdate = true;
    private Grid dataGrid;
    private Paging userPaging;
    PcoPagingListModel model = null;
    String cdtStr = "";
    Listbox colname;
    Textbox keyword;
    Datebox start_time;
    Datebox end_time;
    Button search_n;

    @Override
    public void doAfterCompose(Component comp) throws Exception {
        super.doAfterCompose(comp);
        dataGrid.setRowRenderer(new RowRenderer() {

            @SuppressWarnings("unchecked")
            public void render(Row row, Object data) throws Exception {
                Pco w = (Pco) data;
                Radio aRa = new Radio();
                aRa.setValue(w.getOrderNo() + "");
                row.getChildren().add(aRa);
                row.getChildren().add(new Label(w.getOrderNo() + ""));
                row.getChildren().add(new Label(w.getAttribute1() + ""));
                row.getChildren().add(new Label(w.getAttribute2()));
                row.getChildren().add(new Label(w.getAttribute4()));
                row.getChildren().add(new Label(w.getAttribute5()));
                Label ab = new Label();
                if (w.getStatus() == 2) {
                    ab = new Label("已批准");
                    ab.setStyle("background-color:#008B00;color:#FFFFFF;");//绿
                } else if (w.getStatus() == 1) {
                    ab = new Label("已审核");
                    ab.setStyle("background-color:#CD8500;color:#FFFFFF;");//黄
                } else if (w.isStatusTj()) {
                    ab = new Label("已提交");
                    ab.setStyle("background-color:#4169E1;color:#FFFFFF;");//蓝
                } else if (w.getStatus() == 0) {
                    ab = new Label("编制中");
                    ab.setStyle("background-color:#CD3700;color:#FFFFFF;weight:900;");//红
                }
                row.getChildren().add(ab);
                row.getChildren().add(new Label(w.getInputName()));
                row.getChildren().add(new Label(rcsoft.rc.util.RcUse.formatDate(w.getInputDate())));
                row.addEventListener("onDoubleClick", new OpenDetail(w.getOrderNo(), "pco/pco_detail.zul"));
            }
        });

        refreshModel(cdtStr, _startPageNumber);
    }

    public void onClick$btnGenerate() {
        String start_date = "1970-1-1";
        if (start_time.getValue() != null) {
            start_date = RcUse.formatDateTime(start_time.getValue());
        }
        String end_date = "9999-12-31";
        if (end_time.getValue() != null) {
            end_date = RcUse.formatDateTime(end_time.getValue());
        }
        //
        String myColumn;
        String myWord = "";
        myColumn = (String) colname.getSelectedItem().getValue();
        if (keyword.getValue() != null) {
            myWord = keyword.getValue();
        }
        cdtStr = myColumn + " like " + "'%" + myWord + "%' and (input_date between '" + start_date + "' and '" + end_date + "')" + " and ";
        _needsTotalSizeUpdate = true;
        refreshModel(cdtStr, 0);
    }

    public void onClick$have_post2() {
        String urStr = (String) session.getAttribute("ur");
        cdtStr = "status=2 and ";
        _needsTotalSizeUpdate = true;
        refreshModel(cdtStr, 0);
    }

    public void onClick$mypost2() {
        String urStr = (String) session.getAttribute("ur");
        cdtStr = "tj_post2 = '" + urStr + "' and status=1 and status_tj=1 and ";
        _needsTotalSizeUpdate = true;
        refreshModel(cdtStr, 0);
    }

    public void onClick$mypost() {
        String urStr = (String) session.getAttribute("ur");
        cdtStr = "tj_post = '" + urStr + "' and status=0 and status_tj=1 and ";
        _needsTotalSizeUpdate = true;
        refreshModel(cdtStr, 0);
    }

    public void onClick$search_n() {
        //String urStr = (String) session.getAttribute("ur");
        String snStr = search_n.getLabel();
        cdtStr = "order_no in(" + snStr + ") and ";
        //System.out.println("sql:"+cdtStr);
        _needsTotalSizeUpdate = true;
        refreshModel(cdtStr, 0);
    }

    public void onPaging$userPaging(ForwardEvent event) {
        final PagingEvent pe = (PagingEvent) event.getOrigin();
        _startPageNumber = pe.getActivePage();
        refreshModel(cdtStr, _startPageNumber);
    }

    private void refreshModel(String cdtStr, int activePage) {
        userPaging.setPageSize(_pageSize);
        String urStr = (String) session.getAttribute("ur");
        model = new PcoPagingListModel(urStr, cdtStr, activePage, _pageSize);

        if (_needsTotalSizeUpdate) {
            _totalSize = model.getTotalSize();
            _needsTotalSizeUpdate = false;
        }

        userPaging.setTotalSize(_totalSize);
        userPaging.setActivePage(activePage);

        dataGrid.setModel(model);
    }
}