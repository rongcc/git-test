/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.drms.web;

import javax.sql.DataSource;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.event.ForwardEvent;
import org.zkoss.zk.ui.util.GenericForwardComposer;
import org.zkoss.zul.*;
import org.zkoss.zul.event.PagingEvent;
import rcsoft.rc.db.CachingRcdb;
import rong.gwm.drms.dto.Expert;
import rong.gwm.ts.dto.AccessRight;
import rong.gwm.ts.services.AccessRightService;
import rong.gwm.ts.services.OperatorService;

/**
 *
 * @author ZhouRongChao
 */
public class ExpertComposer extends GenericForwardComposer {

    private static final long serialVersionUID = 1L;
    private final int _pageSize = 20;
    private int _startPageNumber = 0;
    private int _totalSize = 0;
    private boolean _needsTotalSizeUpdate = true;
    private Grid dataGrid;
    private Paging userPaging;
    ExpertPagingListModel model = null;
    String cdtStr = "";
    Listbox colname;
    Textbox keyword;

    @Override
    public void doAfterCompose(Component comp) throws Exception {
        super.doAfterCompose(comp);
        dataGrid.setRowRenderer(new RowRenderer() {

            @SuppressWarnings("unchecked")
            public void render(Row row, Object data) throws Exception {
                Expert w = (Expert) data;
                Radio aRa = new Radio();
                aRa.setValue(w.getId() + "");
                row.getChildren().add(aRa);
                row.getChildren().add(new Label(w.getId() + ""));
                row.getChildren().add(new Label(w.getName() + ""));
                row.getChildren().add(new Label(w.getDept2() == null ? "" : w.getDept2() + ""));
                row.getChildren().add(new Label(w.getDept3() == null ? "" : w.getDept3() + ""));
                row.getChildren().add(new Label(w.getSpeciality() + ""));
                row.getChildren().add(new Label(w.getCarLive() + ""));
                row.getChildren().add(new Label(w.getWorkYear() == null ? "" : w.getWorkYear() + ""));
                row.getChildren().add(new Label(w.getFzType() == null ? "" : w.getFzType() + ""));
                row.getChildren().add(new Label(w.getUsername()));
                Label ab = new Label();
                if (w.getStatus() == 1) {
                    ab = new Label("已确认");
                    ab.setStyle("background-color:#008B00;color:#FFFFFF;");//绿
                } else if (w.getStatus() == 0) {
                    ab = new Label("编制中");
                    ab.setStyle("background-color:#CD3700;color:#FFFFFF;weight:900;");//红
                }
                row.getChildren().add(ab);
            }
        });

        refreshModel(cdtStr, _startPageNumber);
    }

    public void onClick$btnGenerate() {
        String myColumn;
        String myWord = "";
        myColumn = (String) colname.getSelectedItem().getValue();
        if (keyword.getValue() != null) {
            myWord = keyword.getValue();
        }
        cdtStr = myColumn + " like " + "'%" + myWord + "%' and ";
        _needsTotalSizeUpdate = true;
        refreshModel(cdtStr, 0);
    }

    public void onPaging$userPaging(ForwardEvent event) {
        final PagingEvent pe = (PagingEvent) event.getOrigin();
        _startPageNumber = pe.getActivePage();
        refreshModel(cdtStr, _startPageNumber);
    }

    private void refreshModel(String cdtStr, int activePage) {
        userPaging.setPageSize(_pageSize);
        String urStr = (String) session.getAttribute("ur");
        //获取用户的dataScope
        DataSource ds = CachingRcdb.getInstance().getDs4Ts();
        AccessRightService arService = new AccessRightService();
        AccessRight ar = arService.fetch(ds, urStr, "drms_expertM");
        int dataScope = ar.getDataScope();
        String urDept = new OperatorService().getOperDeptNo(ds, urStr);
        if (dataScope == 20) {
            cdtStr = cdtStr + " id in(select id from expert where input_name in"
                    + "(select oper_no from gwm_ts.operator where dept_no='" + urDept + "' and status!=-1"
                    + ")) and ";
        }
        model = new ExpertPagingListModel(urStr, cdtStr, activePage, _pageSize);

        if (_needsTotalSizeUpdate) {
            _totalSize = model.getTotalSize();
            _needsTotalSizeUpdate = false;
        }

        userPaging.setTotalSize(_totalSize);
        userPaging.setActivePage(activePage);

        dataGrid.setModel(model);
    }
}
