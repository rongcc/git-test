/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.drms.web;

import java.util.List;
import javax.sql.DataSource;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.event.Event;
import org.zkoss.zk.ui.event.Events;
import org.zkoss.zk.ui.event.ForwardEvent;
import org.zkoss.zk.ui.util.GenericForwardComposer;
import org.zkoss.zul.*;
import org.zkoss.zul.event.PagingEvent;
import rcsoft.rc.db.CachingRcdb;
import rcsoft.rc.util.RcUse;
import rong.gwm.drms.dto.Wenti;
import rong.gwm.drms.dto.WentiItemFile;
import rong.gwm.drms.services.WentiService;
import rong.gwm.ts.web.AutoVue;

/**
 *
 * @author ZhouRongChao
 */
public class WentiComposer extends GenericForwardComposer {

    /**
     *
     */
    private static final long serialVersionUID = 1L;
    private final int _pageSize = 20;
    private int _startPageNumber = 0;
    private int _totalSize = 0;
    private boolean _needsTotalSizeUpdate = true;
    private Grid dataGrid;
    private Paging userPaging;
    WentiPagingListModel model = null;
    String cdtStr = "";
    Listbox colname;
    Textbox keyword;
    Datebox start_time;
    Datebox end_time;
    Button detail_bt;
    private static final WentiService htService = new WentiService();
    private static final DataSource ds4Drms = CachingRcdb.getInstance().getDs4Drms();

    @Override
    public void doAfterCompose(Component comp) throws Exception {
        super.doAfterCompose(comp);
        dataGrid.setRowRenderer(new RowRenderer() {

            @SuppressWarnings("unchecked")
            public void render(Row row, Object data) throws Exception {
                Wenti w = (Wenti) data;
                Radio aRa = new Radio();
                aRa.setValue(w.getWeNo() + "");
                row.getChildren().add(aRa);
                row.getChildren().add(new Label(w.getWeNo() + ""));
                row.getChildren().add(new Label(w.getWeDescription()));
                String acpt = "";
                if (w.getAccepted() != null) {
                    if (w.getAccepted().booleanValue()) {
                        acpt = "Y";
                    } else {
                        acpt = "N";
                    }
                }
                if ("完成".equals(htService.getJinduJilu(ds4Drms, w.getWeNo()))) {
                    row.getChildren().add(new Label("已完成"));
                } else if (acpt.equals("N")) {
                    row.getChildren().add(new Label("不采纳"));
                } else {
                    int jw = htService.getJuWancheng(ds4Drms, w.getWeNo());
                    Label ab = new Label(jw + "天");
                    ab.setWidth("130px");
                    if (1 <= jw) {
                        ab.setStyle("background-color:#008B00;color:#FFFFFF;");//绿
                    } else if (0 <= jw) {
                        ab.setStyle("background-color:#CD8500;color:#FFFFFF;");//黄
                    } else {
                        ab.setStyle("background-color:#CD3700;color:#FFFFFF;");//红
                    }
                    row.getChildren().add(ab);
                }
                row.getChildren().add(new Label(htService.transYzd(ds4Drms, w.getIssueStatus())));
                row.getChildren().add(new Label(acpt));
                row.getChildren().add(new Label(htService.getJinduJilu(ds4Drms, w.getWeNo())));
                Div hlayt = new Div();
                List itfiList = htService.findItemFileList(ds4Drms, w.getWeNo());
                for (int fi = 0; fi < itfiList.size(); fi++) {
                    WentiItemFile itfi = (WentiItemFile) itfiList.get(fi);
                    if (itfi.getRealFilename() == null) {
                        continue;
                    }
                    Toolbarbutton toobt;
                    WentiItemFile iFile = (WentiItemFile) itfi;
                    String p1 = "";
                    String p2 = "";
                    String p3 = "";
                    if (iFile.getRealFilename() != null) {
                        p1 = iFile.getRealFilename();
                    }
                    if (iFile.getPhysicalFilename() != null) {
                        p2 = iFile.getPhysicalFilename();
                    }
                    if (iFile.getFilePath() != null) {
                        p3 = iFile.getFilePath();
                    }
                    toobt = new Toolbarbutton(p1);
                    toobt.addEventListener("onClick", new AutoVue(p1, p2, p3));
                    hlayt.appendChild(toobt);
                }
                row.getChildren().add(hlayt);
                A a = new A(w.getSrcOrderNo());
                a.setStyle("color:gray;");
                if (w.getSrcOrderNo().startsWith("DR")) {
                    a.addEventListener("onClick", new OpenDetail(w.getSrcOrderNo(), "DR/drbg_detail.zul"));
                } else if (w.getSrcOrderNo().startsWith("DQ")) {
                    a.addEventListener("onClick", new OpenDetail(w.getSrcOrderNo(), "DR/drsq_detail.zul"));
                }
                //row.getChildren().add(new Label(w.getSrcOrderNo()));
                row.getChildren().add(a);
                row.addEventListener("onDoubleClick", new OpenDetail(w.getWeNo(), "WE/we_detail.zul"));
            }
        });
        String urStr = (String) session.getAttribute("ur");
        cdtStr = "(we_no in(SELECT we_no FROM wenti w left outer join gwm_ts.operator o on w.input_name=o.oper_no "
                + "where o.dept_no=(select dept_no from gwm_ts.operator where oper_no='" + urStr + "')"
                + ") or src_order_no in(SELECT drsq_no FROM drsq q left join gwm_ts.operator o on q.input_name=o.oper_no where o.dept_no=(select dept_no from gwm_ts.operator where oper_no='" + urStr + "'))) and ";
        refreshModel(cdtStr, _startPageNumber);
    }

    public void onClick$btnGenerate() {
        String start_date = "1900-1-1";
        if (start_time.getValue() != null) {
            start_date = RcUse.formatDateTime(start_time.getValue());
        }
        String end_date = "9999-12-31";
        if (end_time.getValue() != null) {
            end_date = RcUse.formatDateTime(end_time.getValue());
        }
        //
        //
        String myColumn = "we_no";
        String myWord = "";
        myColumn = (String) colname.getSelectedItem().getValue();
        if (keyword.getValue() != null) {
            myWord = keyword.getValue();
        }
        String urStr = (String) session.getAttribute("ur");
        cdtStr = myColumn + " like " + "'%" + myWord + "%' and (input_date "
                + "between '" + start_date + "' and '" + end_date + "') and ";
        _needsTotalSizeUpdate = true;
        refreshModel(cdtStr, 0);
    }

    public void onClick$btnNoJindu() {
        cdtStr = " accepted is true and we_no not in(SELECT source_order FROM jindu_jilu where status!=-1) and ";
        _needsTotalSizeUpdate = true;
        refreshModel(cdtStr, 0);
    }

    public void onClick$btnNoTime() {
        cdtStr = " accepted is true and status!=-1 and we_no not in"
                + "(select source_order from jindu_jilu where now_jindu='完成' and status!=-1)"
                + " and finish_date<now() and ";
        _needsTotalSizeUpdate = true;
        refreshModel(cdtStr, 0);
    }

    public void onPaging$userPaging(ForwardEvent event) {
        final PagingEvent pe = (PagingEvent) event.getOrigin();
        _startPageNumber = pe.getActivePage();
        refreshModel(cdtStr, _startPageNumber);
    }

    private void refreshModel(String cdtStr, int activePage) {
        userPaging.setPageSize(_pageSize);
        String urStr = (String) session.getAttribute("ur");
        model = new WentiPagingListModel(urStr, cdtStr, activePage, _pageSize);

        if (_needsTotalSizeUpdate) {
            _totalSize = model.getTotalSize();
            //System.out.println(_totalSize);
            _needsTotalSizeUpdate = false;
        }

        userPaging.setTotalSize(_totalSize);
        userPaging.setActivePage(activePage);

        dataGrid.setModel(model);
    }
}
