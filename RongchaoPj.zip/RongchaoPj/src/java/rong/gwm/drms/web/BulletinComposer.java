/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.gwm.drms.web;

import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.event.ForwardEvent;
import org.zkoss.zk.ui.util.GenericForwardComposer;
import org.zkoss.zul.*;
import org.zkoss.zul.event.PagingEvent;
import rcsoft.rc.util.RcUse;
import rong.gwm.drms.dto.Bulletin;

/**
 *
 * @author ZhouRongChao
 */
public class BulletinComposer extends GenericForwardComposer {

    private static final long serialVersionUID = 1L;
    private final int _pageSize = 20;
    private int _startPageNumber = 0;
    private int _totalSize = 0;
    private boolean _needsTotalSizeUpdate = true;
    private Grid dataGrid;
    private Paging userPaging;
    BulletinPagingListModel model = null;
    String cdtStr = "";
    Listbox colname;
    Textbox keyword;
    Datebox start_time;
    Datebox end_time;

    @Override
    public void doAfterCompose(Component comp) throws Exception {
        super.doAfterCompose(comp);
        dataGrid.setRowRenderer(new RowRenderer() {

            @SuppressWarnings("unchecked")
            public void render(Row row, Object data) throws Exception {
                Bulletin w = (Bulletin) data;
                Radio aRa = new Radio();
                aRa.setValue(w.getOrderNo() + "");
                row.getChildren().add(aRa);
                row.getChildren().add(new Label(w.getOrderNo() + ""));
                row.getChildren().add(new Label(w.getTitle()));
                row.getChildren().add(new Label(w.getInputName()));
                row.getChildren().add(new Label(RcUse.formatDate(w.getInputDate())));
            }
        });

        refreshModel(cdtStr, _startPageNumber);
    }

    public void onClick$btnGenerate() {
        String start_date = "1970-1-1";
        if (start_time.getValue() != null) {
            start_date = RcUse.formatDateTime(start_time.getValue());
        }
        String end_date = "9999-12-31";
        if (end_time.getValue() != null) {
            end_date = RcUse.formatDateTime(end_time.getValue());
        }
        //
        String myColumn;
        String myWord = "";
        myColumn = (String) colname.getSelectedItem().getValue();
        if (keyword.getValue() != null) {
            myWord = keyword.getValue();
        }
        cdtStr = myColumn + " like " + "'%" + myWord + "%' and (input_date between '" + start_date + "' and '" + end_date + "')" + " and ";
        _needsTotalSizeUpdate = true;
        refreshModel(cdtStr, 0);
    }

    public void onPaging$userPaging(ForwardEvent event) {
        final PagingEvent pe = (PagingEvent) event.getOrigin();
        _startPageNumber = pe.getActivePage();
        refreshModel(cdtStr, _startPageNumber);
    }

    private void refreshModel(String cdtStr, int activePage) {
        userPaging.setPageSize(_pageSize);
        String urStr = (String) session.getAttribute("ur");
        model = new BulletinPagingListModel(urStr, cdtStr, activePage, _pageSize);

        if (_needsTotalSizeUpdate) {
            _totalSize = model.getTotalSize();
            _needsTotalSizeUpdate = false;
        }

        userPaging.setTotalSize(_totalSize);
        userPaging.setActivePage(activePage);

        dataGrid.setModel(model);
    }
}
