/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 * 可以创建服务定位器 J2EE 设计模式的实例。
 * 服务定位器将 JNDI 查找代码封装在一个单独的类中，从而减少了查找代码激增的情况。
 * 此向导不缓存查找实例，它通常用于业务层。
 */
package rcsoft.rc.util;

import java.net.URL;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

/**
 *
 * @author zhourongchao
 */
public class ServiceLocator {

    private InitialContext ic;

    public ServiceLocator() {
        try {
            ic = new InitialContext();
        } catch (NamingException ne) {
            throw new RuntimeException(ne);
        }
    }

    private Object lookup(String jndiName) throws NamingException {
        return ic.lookup(jndiName);
    }

    /**
     * This method obtains the datasource itself for a caller
     * @return the DataSource corresponding to the name parameter
     */
    public DataSource getDataSource(String dataSourceName) throws NamingException {
        return (DataSource) lookup(dataSourceName);
    }

    /**
     * @return the URL value corresponding
     * to the env entry name.
     */
    public URL getUrl(String envName) throws NamingException {
        return (URL) lookup(envName);
    }

    /**
     * @return the boolean value corresponding
     * to the env entry
     */
    public boolean getBoolean(String envName) throws NamingException {
        Boolean bool = (Boolean) lookup(envName);
        return bool.booleanValue();
    }

    /**
     * @return the String value corresponding
     * to the env entry name.
     */
    public String getString(String envName) throws NamingException {
        return (String) lookup(envName);
    }
}
