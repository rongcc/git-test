/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rcsoft.rc.util;

import java.util.Date;

/**
 *
 * @author ZhouRongChao
 */
public class RcUse {

    /**
     * 修剪掉空值，null也被修剪掉。
     * @param str
     * @return 真实有效的字符串。
     */
    public static String trimRealStr(String str) {
        String realStr = "";
        if (str == null) {
            return "";
        }
        realStr = str.trim();
        return realStr;
    }

    /**
     * 转化为"yyyy-MM-dd"格式的日期。
     * @param dt
     * @return 格式化的日期。
     */
    public static String formatDate(Date dt) {
        if (dt == null) {
            return "";
        }
        java.text.DateFormat format1 = new java.text.SimpleDateFormat("yyyy-MM-dd");
        return format1.format(dt);
    }

    /**
     * 转化为"yyyy-MM-dd HH:mm:ss"格式的日期时间。
     * @param dt
     * @return 格式化的日期和时间。
     */
    public static String formatDateTime(Date dt) {
        if (dt == null) {
            return "";
        }
        java.text.DateFormat format1 = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return format1.format(dt);
    }
}
