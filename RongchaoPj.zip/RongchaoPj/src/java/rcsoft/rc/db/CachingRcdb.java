/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rcsoft.rc.db;

import com.mchange.v2.c3p0.DataSources;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import javax.naming.NamingException;
import javax.sql.DataSource;

/**
 *
 * @author zhourongchao
 */
public class CachingRcdb {

    private Map cache;
    private static CachingRcdb me;

    static {
        try {
            me = new CachingRcdb();
        } catch (NamingException se) {
            throw new RuntimeException(se);
        }
    }

    private CachingRcdb() throws NamingException {
        cache = Collections.synchronizedMap(new HashMap());
    }

    public static CachingRcdb getInstance() {
        return me;
    }

    /**
     * 获取rcsoft数据库的数据源。
     * @return
     */
    public DataSource getDs4Rcsoft() {
        return lookupDs("rcsoft");
    }

    /**
     * 获取gwmdrms数据库的数据源。
     * @return
     */
    public DataSource getDs4Drms() {
        return lookupDs("gwmdrms");
    }

    /**
     * 获取gwmcar数据库的数据源。
     * @return
     */
    public DataSource getDs4Car() {
        return lookupDs("gwmcar");
    }

    /**
     * 获取gwm_ts数据库的数据源。
     * @return
     */
    public DataSource getDs4Ts() {
        return lookupDs("gwm_ts");
    }

    /**
     * 获取openfire数据库的数据源。
     * @return
     */
    public DataSource getDs4Openfire() {
        return lookupDs("openfire");
    }

    /**
     * 获取gwmqms数据库的数据源。
     * @return
     */
    public DataSource getDs4Qms() {
        return lookupDs("gwmqms");
    }

    /**
     * 查找数据源。
     * 根据据库名查找对应的数据源，没有就创建它。数据源实例存进实例缓存之中。
     * @param dsName
     * @return
     */
    public DataSource lookupDs(String dbName) {
        DataSource ds = null;
        Object cachedObj = cache.get(dbName);
        if (cachedObj == null) {
            ds = createDs(dbName);
            cache.put(dbName, ds);
        } else {
            ds = (DataSource) cachedObj;
        }
        return ds;
    }

    /**
     * 根据数据库名创建MySQL数据源。
     * @param dbName
     * @return
     */
    private DataSource createDs(String dbName) {
        DataSource pooled = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            // Acquire the DataSource... this is the only c3p0 specific code here
            DataSource unpooled = DataSources.unpooledDataSource(
                    "jdbc:mysql://localhost:3306/" + dbName + "?useUnicode=true&characterEncoding=GBK",
                    "root",
                    "125412");
            //pooled = DataSources.pooledDataSource(unpooled);
            Map overrides = new HashMap();
            overrides.put("maxStatements", "300");
            overrides.put("maxPoolSize", new Integer(50));
            pooled = DataSources.pooledDataSource(unpooled, overrides);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return pooled;
    }

    /**
     * 获得sqlserver数据库的GWMQMS数据源，正式账号。sqlserve数据源没有实例缓存。
     * @return
     */
    public DataSource getDs4Qms_sqlserver() {
        DataSource pooled = null;
        try {
            Class.forName("net.sourceforge.jtds.jdbc.Driver");
            // Acquire the DataSource... this is the only c3p0 specific code here
            DataSource unpooled = DataSources.unpooledDataSource(
                    "jdbc:jtds:sqlserver://10.1.129.16:1433/QMS_MAIN",
                    "root",
                    "125412");
            pooled = DataSources.pooledDataSource(unpooled);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return pooled;
    }
}
