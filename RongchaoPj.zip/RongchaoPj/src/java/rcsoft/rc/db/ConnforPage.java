/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rcsoft.rc.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author zhourongchao
 */
public class ConnforPage {

    String sDBDriver = "com.mysql.jdbc.Driver";
    String sConnStr = "jdbc:mysql://localhost:3306/rcsoft?useUnicode=true&characterEncoding=GBK";
    Connection connect = null;
    ResultSet rs = null;

    public ConnforPage() {
        try {
            Class.forName(sDBDriver);
        } catch (java.lang.ClassNotFoundException e) {
            System.err.println(e.getMessage());
        }
    }

    public ResultSet executeQuery(String sql) {
        try {
            connect = DriverManager.getConnection(sConnStr, "root", "125412");
            Statement stmt = connect.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            rs = stmt.executeQuery(sql);
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
        return rs;
    }

    public int executeUpdate(String sql) {
        int result = 0;
        try {
            connect = DriverManager.getConnection(sConnStr, "root", "125412");
            Statement stmt = connect.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            result = stmt.executeUpdate(sql);
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
        return result;
    }

    /**
     * 执行查询。
     * @param connect
     * @param sql
     * @return
     */
    public ResultSet executeQuery(Connection connect, String sql) {
        try {
            Statement stmt = connect.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            rs = stmt.executeQuery(sql);
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
        return rs;
    }

    /**
     * 执行插入或更新。
     * @param connect
     * @param sql
     * @return
     */
    public int executeUpdate(Connection connect, String sql) {
        int result = 0;
        try {
            Statement stmt = connect.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            result = stmt.executeUpdate(sql);
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
        return result;
    }
}
