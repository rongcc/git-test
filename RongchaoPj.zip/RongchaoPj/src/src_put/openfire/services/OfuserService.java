/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rong.chao.openfire.services;

import javax.sql.DataSource;
import org.jivesoftware.database.DbConnectionManager;
import org.jivesoftware.database.DefaultConnectionProvider;
import org.jivesoftware.openfire.user.DefaultUserProvider;
import org.jivesoftware.openfire.user.User;
import org.jivesoftware.util.InitializationException;
import org.jivesoftware.util.cache.CacheFactory;
import org.nutz.dao.Dao;
import org.nutz.dao.impl.NutDao;
import rong.chao.openfire.dto.Ofuser;

/**
 *
 * @author ZhouRongChao
 */
public class OfuserService {

    DefaultUserProvider userProvider;

    public OfuserService() {
        // 设置数据库连接
        String driver = "com.mysql.jdbc.Driver";
        double connectionTimeout = 0.5;
        String serverURL = "jdbc:mysql://localhost:3306/openfire?useUnicode=true&characterEncoding=GBK";
        String username = "dazhou";
        String password = "125412";
        String testSQL = "SELECT 1 FROM ofuser";
        int minConnections = 1;
        int maxConnections = 5;
        boolean testBeforeUse = true;
        boolean testAfterUse = false;

        DefaultConnectionProvider connectionProvider = new DefaultConnectionProvider();
        connectionProvider.setDriver(driver);
        connectionProvider.setConnectionTimeout(connectionTimeout);
        connectionProvider.setServerURL(serverURL);
        connectionProvider.setUsername(username);
        connectionProvider.setPassword(password);
        connectionProvider.setTestSQL(testSQL);
        connectionProvider.setMinConnections(minConnections);
        connectionProvider.setMaxConnections(maxConnections);
        connectionProvider.setTestBeforeUse(testBeforeUse);
        connectionProvider.setTestAfterUse(testAfterUse);
        connectionProvider.start();

        DbConnectionManager.setConnectionProvider(connectionProvider);
        try {
            CacheFactory.initialize();
        } catch (InitializationException e) {
            e.printStackTrace();
        }
        userProvider = new DefaultUserProvider();
    }

    /**
     * 新增一个openfire用户。
     * @param username
     * @param passwd
     * @param name
     * @param email
     * @return
     */
    public int addUser(String username, String passwd, String name, String email) {
        int di = 0;
        String ofusername = username;
        String ofencryptedPassword = passwd;
        String ofname = name;
        String ofemail = email;
        try {
            User user = userProvider.createUser(ofusername, ofencryptedPassword, ofname, ofemail);
            System.out.println("[" + user.getUID() + "] creat ok!");
            di = 1;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return di;
    }

    /**
     * 删除一个用户。
     * @param username
     * @return
     */
    public int deleteUser(String username) {
        int di = 0;
        String ofusername = username;
        try {
            userProvider.deleteUser(ofusername);
            di = 1;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return di;
    }

    /**
     * 获取用户信息
     * @param ds
     * @param username
     * @return
     */
    public Ofuser fetch(DataSource ds, String username) {
        Ofuser ofuser = null;
        String ofusername = username;
        try {
            Dao dao = new NutDao(ds);
            ofuser = dao.fetch(Ofuser.class, ofusername);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ofuser;
    }

    /**
     * 
     * @param username
     * @return
     */
    public Ofuser loadUser(String username) {
        Ofuser ofuser = null;
        String ofusername = username;
        try {
            User user = userProvider.loadUser(ofusername);
            ofuser.setUsername(user.getUsername());
            ofuser.setName(user.getName());
            ofuser.setEmail(user.getEmail());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ofuser;
    }
}
